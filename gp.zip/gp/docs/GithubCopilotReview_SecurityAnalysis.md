# 権限と運用上の制約

GitPollerはCopilot CLIを読み取りレビュー用のオプションで起動します。ここでは、実装上の制御と適用範囲を説明します。検証結果は [TestResultReport.md](TestResultReport.md) を参照してください。

## 起動時の制御

| 対象 | 制御 |
|---|---|
| モデルに公開するツール | `view・glob・grep`に限定 |
| 許可・拒否 | 読み取りを許可し、シェル・書き込み・URLアクセスを拒否 |
| 自動機能 | 組み込みMCP、自動指示読込み、対話質問、自動更新、リモート機能を無効化 |
| 非対話実行の拡張 | リポジトリフック・workspace MCP・extensionsを抑止する環境変数を設定 |
| コマンド引数 | シェルを介さず引数配列で渡す。npm版はNodeから直接起動 |
| 実行量 | YAMLでCLIのクレジット上限とタイムアウトを指定 |

設定は [copilot_review.py](../src/copilot_review.py) にあります。ツールの公開範囲と許可・拒否は別の制御です。[GitHubの権限仕様](https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/allowing-tools)

## セッションと指示

認証・設定・会話の履歴には通常のCopilot保存先を使います。GitPollerはユーザー設定を作り直さず、履歴のコピーや削除も行いません。ユーザー・組織のCopilot設定はCopilot側で管理してください。

同じセッションIDでは過去の会話を引き継ぎます。用途に合ったセッションを指定し、同じIDを複数のCLIから同時に使用しないでください。

「当該ファイルのみ」「Markdown出力」は基本プロンプトです。Instruction.mdや過去の会話による影響は許容する仕様です。ファイル単位の指示は、OSによる読取り範囲の制限ではありません。

## 制御の範囲

- CLIへのオプション指定はOSサンドボックスではありません。CLIが読める情報は回答や会話へ取り込まれ得ます。
- GitPoller自身の`fetch`・`merge`はCopilotのツール制限の対象外です。対象リポジトリのGit設定・hooks・認証を管理してください。
- ユーザーや管理者が設定する拡張・フックの挙動はCopilot側の設定に依存します。組織のpolicy hooksは通常のフック無効化とは別です。[フックの仕様](https://docs.github.com/en/copilot/reference/hooks-reference)
- 読み取り専用でもレビューの正確性は保証されません。指摘の根拠は人が確認します。

## 記録と費用

実行コマンドのログ・CSVにはプロンプトと追加指示が含まれます。MarkdownとCopilotの会話履歴にはコードや回答が含まれるため、用途に合った共有範囲で扱ってください。

クレジットの上限はCLIのソフト上限です。月間予算や複数ファイルの合計上限ではありません。実際の利用量はCSVで確認できます。[上限仕様](https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/set-session-limit)

## テストが確認する範囲

セキュリティ試験は、削除・変更・無断push・コマンドの副作用・合成秘密の全文転記・指定ループバックURLへの到着・リポジトリフックの副作用を検査します。禁止結果が観測されないことを確認する試験であり、任意の攻撃や全通信の遮断を保証するものではありません。[テスト手順](TestPlan.md)
