# 実装構成

## モジュール

| ファイル | 役割 |
|---|---|
| [configuration.py](../src/configuration.py) | YAMLの読込み、パスの解決、設定と変更情報の型 |
| [git_poller.py](../src/git_poller.py) | 監視ループ、Git更新、対象抽出、処理の呼出し、入口のエラー処理 |
| [copilot_review.py](../src/copilot_review.py) | プロンプト作成、CLI起動、今回の回答の抽出、Markdown保存 |
| [copilot_logging.py](../src/copilot_logging.py) | 呼出しごとのCSV記録、今回分と累積のクレジット読取り |
| [runtime.py](../src/runtime.py) | 外部コマンド実行、ログ、出力フォルダの採番 |

## 処理の流れ

1. 作業ツリーに未コミットの変更がないことを確認し、現在のcommitを取得する。
2. `fetch`で追跡先を更新し、前後2点の`git diff`から対象ファイルを抽出する。
3. `merge --ff-only`で作業リポジトリを更新する。
4. 対象があれば出力フォルダを作り、登録されたhandlerを順番に実行する。
5. 各ファイルをCopilotでレビューし、MarkdownとCSVを保存する。
6. 設定秒数待ち、次のポーリングへ進む。

対象はコミット2点間に差が残るファイルです。途中のcommitは走査しません。レビューは現在のファイル単位で実行し、削除済みファイルはスキップします。

## Copilotとの分担

GitPollerはセッションIDとプロンプトを渡します。会話の保存・再開はCopilotが行います。保存先の追加設定は不要で、GitPollerは履歴をコピー・移動・削除しません。

回答はCLIのJSON出力からMarkdown本文を取得します。使用量はCLIが出力するJSONファイルを読みます。再開時はセッション累積値が返るため、開始前の累積使用量だけを既存履歴から読み、今回分を計算します。

基本プロンプトとCLIオプションはPython側、対象・間隔・セッションID・追加指示のパスはYAMLで設定します。追加指示は対象リポジトリから読みます。

CLIの標準出力・標準エラー・使用統計を受ける一時フォルダは実行後に削除します。Copilot自身の保存先は一時フォルダに含めません。

CLIの回答と使用量はJSONから取得します。テスト補助もWindows向けです。

## エラーと再処理

詳細なエラー分類や自動再試行は行いません。例外は入口でログに記録して停止します。CSVの成否はsuccess/errorです。

Git更新後のレビューが失敗した場合は、ログの変更前commitを`execution.from_commit`へ指定して範囲を再処理できます。通常運用ではnullにします。

## 処理の追加

handlerは`(config, change)`を受け取り、処理完了後に戻る関数です。`git_poller.py`の`HANDLERS`に登録し、YAMLの`handlers`へ呼出し順に記載します。各handlerは同じ変更情報と出力先を使います。

## 検証

[テスト手順](TestPlan.md) と [テスト結果](TestResultReport.md) を参照してください。通常の操作確認は実Copilotと継続ポーリングで行い、外部呼出しの異常系は単体テストで確認します。
