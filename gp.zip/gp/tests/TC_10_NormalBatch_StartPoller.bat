@echo off
setlocal
python "%~dp0test_support\staged_test.py" start --scenario NormalBatch %*
exit /b %errorlevel%
