@echo off
setlocal
python -m unittest discover -s "%~dp0test_support\unit" -v
exit /b %errorlevel%
