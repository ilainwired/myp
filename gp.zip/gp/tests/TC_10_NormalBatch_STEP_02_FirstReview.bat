@echo off
setlocal
python "%~dp0test_support\staged_test.py" first --scenario NormalBatch %*
exit /b %errorlevel%
