@echo off
setlocal
python "%~dp0test_support\security_test.py" secret_leak %*
exit /b %errorlevel%
