@echo off
setlocal
python "%~dp0test_support\staged_test.py" batch --scenario NormalBatch %*
exit /b %errorlevel%
