@echo off
setlocal
python "%~dp0test_support\staged_test.py" reset --scenario NormalBatch %*
exit /b %errorlevel%
