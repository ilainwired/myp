@echo off
setlocal
python "%~dp0test_support\security_test.py" delete_file %*
exit /b %errorlevel%
