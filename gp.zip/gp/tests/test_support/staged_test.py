"""Prepare/push manual test states and run a separate, persistent Git Poller."""
from __future__ import annotations

import argparse
import msvcrt
import shutil
import subprocess
import sys
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from uuid import uuid4

import yaml


PROJECT_PATH = Path(__file__).resolve().parents[2]
OUTPUT_PATH = PROJECT_PATH / "output"
WORKSPACE_PATH = Path(__file__).with_name("workspace")
FIXTURES = Path(__file__).with_name("fixtures")
MARKER = ".gitpoller-testcase"
SCENARIOS = {"Normal": "TC_01_Normal", "NormalBatch": "TC_10_NormalBatch"}


def workspace(scenario: str = "Normal") -> Path:
    if scenario not in SCENARIOS:
        raise ValueError(f"Unknown scenario: {scenario}")
    root = WORKSPACE_PATH.absolute() / scenario
    if root.resolve() != root or root.is_symlink():
        raise RuntimeError(f"Test directory must not be a symlink or junction: {root}")
    return root


@contextmanager
def poller_lock(scenario: str):
    """OS locks are released even if the test process is killed."""
    root = workspace(scenario)
    root.parent.mkdir(parents=True, exist_ok=True)
    with (root.parent / f".{scenario}.poller.lock").open("a+b") as stream:
        if stream.tell() == 0:
            stream.write(b"\0")
            stream.flush()
        stream.seek(0)
        try:
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as error:
            raise RuntimeError(f"Stop the running {scenario} poller before Reset, StartPoller or PollOnce.") from error
        try:
            yield
        finally:
            msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)


def git(cwd: Path, *arguments: object) -> str:
    return subprocess.check_output(
        ["git", "-c", "core.autocrlf=false", "-c", "commit.gpgSign=false",
         "-c", "core.hooksPath=/dev/null",
         *map(str, arguments)],
        cwd=cwd, encoding="utf-8", timeout=60,
    ).strip()


def reset(scenario: str = "Normal", instruction: str = "default") -> Path:
    with poller_lock(scenario):
        return _reset(scenario, instruction)


def write_yaml(path: Path, values: dict) -> None:
    path.write_text(yaml.safe_dump(values, allow_unicode=True, sort_keys=False), encoding="utf-8")


def _reset(scenario: str, instruction: str) -> Path:
    root = workspace(scenario)
    if root.exists():
        if not (root / MARKER).is_file():
            raise RuntimeError(f"Refusing to reset an unmanaged directory: {root}")
        backup = root.with_name(f"{scenario}_backup_{datetime.now():%Y%m%d_%H%M%S_%f}")
        root.rename(backup)
        print(f"Previous test files preserved: {backup}")
    root.mkdir(parents=True)
    (root / MARKER).touch()
    (root / "empty-hooks").mkdir()

    remote = root / "remote.git"
    producer = root / "producer"
    repository = root / "repository"
    git(root, "init", "--bare", "--initial-branch=main", "--template=", remote)
    git(root, "clone", "--template=", remote, producer)
    git(producer, "config", "user.name", "GitPoller Test")
    git(producer, "config", "user.email", "gitpoller-test@example.invalid")
    shutil.copytree(FIXTURES / SCENARIOS[scenario] / "state1", producer, dirs_exist_ok=True)
    shutil.copyfile(FIXTURES / "AI_Instruction.md", producer / "AI_Instruction.md")
    if instruction == "present":
        shutil.copytree(FIXTURES / "TC_01_Normal/instruction/present", producer, dirs_exist_ok=True)
    git(producer, "add", "--", ".")
    git(producer, "commit", "-m", "test: initial state")
    git(producer, "push", "-u", "origin", "main")
    git(root, "clone", "--template=", remote, repository)
    for path in (producer, repository):
        git(path, "config", "core.autocrlf", "false")
        git(path, "config", "core.hooksPath", (root / "empty-hooks").as_posix())

    with (PROJECT_PATH / "configs/default.yaml").open(encoding="utf-8") as file:
        config = yaml.safe_load(file)
    config["repository"].update(name=scenario, path="repository")
    config["output"] = OUTPUT_PATH.as_posix()
    config["execution"] = {"once": False, "from_commit": None}
    config["polling"] = {"interval_seconds": 5, "start": "00:00", "end": "00:00"}
    config["copilot"]["instruction_file"] = "AI_Instruction.md" if instruction == "default" else "rules/AI_Instruction.md"
    config["copilot"]["session_id"] = str(uuid4())
    write_yaml(root / "config.yaml", config)
    print(f"State 1 ready.\nCheck initial files: {repository}\n"
          f"Start {scenario}'s StartPoller.bat in another terminal before the first push.")
    return root


def prepared_settings(scenario: str) -> dict:
    root = workspace(scenario)
    reset_bat = "TC_01_Normal_STEP_01_Reset.bat" if scenario == "Normal" else "TC_10_NormalBatch_STEP_01_Reset.bat"
    if not (root / "config.yaml").is_file():
        raise RuntimeError(f"Run {reset_bat} first.")
    with (root / "config.yaml").open(encoding="utf-8") as file:
        return yaml.safe_load(file)


def run_poller(once: bool = False, scenario: str = "Normal") -> None:
    # Run the production loop in this process so Ctrl+C and process termination
    # stop the poller as well as releasing the test workspace lock.
    sys.path.insert(0, str(PROJECT_PATH / "src"))
    import git_poller
    from configuration import load_config
    from runtime import close_logging, configure_logging

    with poller_lock(scenario):
        root = workspace(scenario)
        values = prepared_settings(scenario)
        values["execution"] = {"once": once, "from_commit": None}
        if once:
            write_yaml(root / "config.once.yaml", values)
        values["repository"]["path"] = (root / values["repository"]["path"]).resolve().as_posix()
        values["output"] = (root / values["output"]).resolve().as_posix()
        # instruction_file stays relative to the watched repository, including
        # after this YAML is copied to output/test-settings.
        mode = "once" if once else "continuous"
        directory = Path(values["output"]) / values["repository"]["name"] / "test-settings" / f"{datetime.now():%Y%m%d_%H%M%S_%f}_{mode}"
        directory.mkdir(parents=True)
        snapshot = directory / "config.yaml"
        write_yaml(snapshot, values)
        config = load_config(snapshot)
        try:
            log_path = configure_logging(config.repository_output_path)
            git_poller.LOGGER.info("Test settings: %s", snapshot)
            print(f"Settings saved: {snapshot}\nLog: {log_path}\n"
                  f"Polling: {mode}, interval={config.polling_interval_seconds:g}s. Stop with Ctrl+C.", flush=True)
            if once:
                git_poller.poll_once(config)
            else:
                git_poller.run(config)
        except Exception:
            git_poller.LOGGER.exception("Test poller failed")
            raise
        finally:
            close_logging()


def commit_and_push(number: int, scenario: str = "Normal", through: int | None = None) -> None:
    root = workspace(scenario)
    prepared_settings(scenario)
    last = number if through is None else through
    if not 1 <= number <= last <= 3:
        raise ValueError("Invalid change range")
    producer = root / "producer"
    expected = "test: initial state" if number == 1 else f"test: change {number - 1}"
    if git(producer, "log", "-1", "--format=%s") != expected:
        raise RuntimeError("Run the scenario's stage scripts in order.")
    if git(producer, "status", "--porcelain"):
        raise RuntimeError(f"Uncommitted changes found: {producer}")
    before = git(producer, "rev-parse", "HEAD")
    if git(root / "repository", "rev-parse", "HEAD") != before:
        raise RuntimeError("Wait for the previous push to be polled and check its output before the next stage.")
    for change_number in range(number, last + 1):
        shutil.copytree(FIXTURES / SCENARIOS[scenario] / f"state{change_number + 1}", producer, dirs_exist_ok=True)
        git(producer, "add", "--", ".")
        git(producer, "commit", "-m", f"test: change {change_number}")
    # The batch case intentionally publishes both commits with one push.
    git(producer, "push", "origin", "main")
    after = git(producer, "rev-parse", "HEAD")
    print(f"Pushed state {number} -> {last + 1}: {before[:7]} -> {after[:7]} ({last - number + 1} commit(s)).\n"
          f"Wait for the running poller, then visually check the new output: {OUTPUT_PATH / scenario}\n"
          "This push script does not run a poll or wait for the review.", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="step", required=True)
    for step in ("reset", "start", "once", "first", "second", "third", "batch"):
        command = subparsers.add_parser(step)
        command.add_argument("--scenario", choices=SCENARIOS, default="Normal")
        if step == "reset":
            command.add_argument("--instruction", choices=("default", "present", "missing"), default="default")
    arguments = parser.parse_args()
    try:
        if arguments.step == "reset":
            reset(arguments.scenario, arguments.instruction)
        elif arguments.step in ("start", "once"):
            run_poller(arguments.step == "once", arguments.scenario)
        else:
            number = {"first": 1, "second": 2, "third": 3, "batch": 2}[arguments.step]
            commit_and_push(number, arguments.scenario, 3 if arguments.step == "batch" else None)
    except KeyboardInterrupt:
        return 0
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    raise SystemExit(main())
