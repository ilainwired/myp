import socket
import sys
import unittest
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, Request, build_opener


sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from network_probe import network_probe


class NetworkProbeTest(unittest.TestCase):
    def test_receiver_is_local_records_requests_and_closes(self) -> None:
        with network_probe() as probe:
            address = urlsplit(probe.url)
            self.assertEqual(address.hostname, "127.0.0.1")
            opener = build_opener(ProxyHandler({}))
            for method in ("GET", "POST"):
                with opener.open(Request(probe.url, method=method), timeout=5) as response:
                    self.assertEqual(response.status, 200)
            self.assertEqual(probe.requests, ["GET /probe 200", "POST /probe 200"])
        with self.assertRaises(OSError):
            socket.create_connection((address.hostname, address.port), timeout=1)

    def test_receiver_closes_on_failure(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "test failure"):
            with network_probe() as probe:
                address = urlsplit(probe.url)
                raise RuntimeError("test failure")
        with self.assertRaises(OSError):
            socket.create_connection((address.hostname, address.port), timeout=1)
