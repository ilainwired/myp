import json
import sys
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT / "src"))

from copilot_logging import previous_nano_aiu, read_credits


class CreditLoggingTest(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)

    def test_structured_cumulative_usage_takes_precedence_over_rounded_text_and_model_totals(self):
        (self.root / "usage.json").write_text(json.dumps({
            "totalNanoAiu": 750_000_003, "totalPremiumRequestCost": 200,
            "modelMetrics": {"one": {"totalNanoAiu": 750_000_003}},
        }), encoding="utf-8")
        (self.root / "stderr.log").write_text("AI Credits 0.75 (17s)\n", encoding="utf-8")
        credits = read_credits(self.root, True, Decimal(250_000_001))
        self.assertEqual(credits["ai_credits"], "0.500000002")
        self.assertEqual(credits["session_ai_credits"], "0.750000003")
        self.assertEqual(credits["credit_source"], "usage.json:totalNanoAiu")

    def test_missing_invalid_and_non_credit_usage_is_unknown_not_zero(self):
        (self.root / "stderr.log").write_text("Remaining AI credits: 900\nTotal premium requests: 1\n", encoding="utf-8")
        for data in ("", "{incomplete", "[]", '{"totalNanoAiu": null}', '{"totalNanoAiu": false}',
                     '{"totalNanoAiu": -1}', '{"totalNanoAiu": "NaN"}', '{"totalNanoAiu": "Infinity"}',
                     '{"totalPremiumRequestCost": 4}', '{"modelMetrics": {"a": {"totalNanoAiu": 5}}}'):
            with self.subTest(data=data):
                (self.root / "usage.json").write_text(data, encoding="utf-8")
                credits = read_credits(self.root, False, None)
                self.assertEqual(credits, {"ai_credits": "", "session_ai_credits": "", "credit_source": ""})
        (self.root / "usage.json").write_text('{"totalNanoAiu": 0}', encoding="utf-8")
        self.assertEqual(read_credits(self.root, False, None)["ai_credits"], "0")

    def test_resumed_unknown_or_decreasing_baseline_does_not_fabricate_a_delta(self):
        (self.root / "usage.json").write_text('{"totalNanoAiu": 500000000}', encoding="utf-8")
        for baseline in (None, Decimal(600_000_000)):
            credits = read_credits(self.root, True, baseline)
            self.assertEqual(credits["ai_credits"], "")
            self.assertEqual(credits["session_ai_credits"], "0.5")

    def test_rounded_text_is_not_used_when_structured_usage_is_missing(self):
        (self.root / "usage.json").write_text("{truncated", encoding="utf-8")
        for line, amount in (("AI Credits 0.27 (17s)", "0.27"),
                             ("Total AI credits: 1,234.50", "1234.50")):
            with self.subTest(line=line):
                (self.root / "stderr.log").write_text(line + "\n", encoding="utf-8")
                self.assertEqual(read_credits(self.root, False, None)["ai_credits"], "")
                self.assertEqual(read_credits(self.root, True, Decimal(0))["credit_source"], "")

    def test_persisted_baseline_requires_a_valid_checkpoint_after_usage(self):
        path = self.root / "events.jsonl"
        def write_events(events):
            path.write_text("\n".join(json.dumps(event) for event in events), encoding="utf-8")
        checkpoint = {"type": "session.usage_checkpoint", "data": {"totalNanoAiu": 250_000_001}}
        later = {"type": "assistant.usage", "data": {"inputTokens": 42}}
        write_events([checkpoint])
        self.assertEqual(previous_nano_aiu(path), Decimal(250_000_001))
        write_events([checkpoint, later])
        self.assertIsNone(previous_nano_aiu(path))
        write_events([checkpoint, later, {"type": "session.shutdown", "data": {"totalNanoAiu": 500_000_002}}])
        self.assertEqual(previous_nano_aiu(path), Decimal(500_000_002))
        write_events([checkpoint, {"type": "session.shutdown", "data": {}}])
        self.assertIsNone(previous_nano_aiu(path))
        write_events([checkpoint, None])
        self.assertIsNone(previous_nano_aiu(path))
