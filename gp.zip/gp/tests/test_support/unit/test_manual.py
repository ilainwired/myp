import contextlib
import io
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.request import ProxyHandler, build_opener

PROJECT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(PROJECT / "src"), str(PROJECT / "tests/test_support")]

import git_poller
import security_test
import staged_test
from configuration import load_config
from runtime import close_logging


class ManualTest(unittest.TestCase):
    def setUp(self) -> None:
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.output = Path(directory.name).resolve() / "output"
        self.workspaces = Path(directory.name).resolve() / "workspaces"
        stack = contextlib.ExitStack()
        self.addCleanup(stack.close)
        stack.enter_context(patch.object(staged_test, "OUTPUT_PATH", self.output))
        stack.enter_context(patch.object(staged_test, "WORKSPACE_PATH", self.workspaces))
        stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
        stack.enter_context(contextlib.redirect_stderr(io.StringIO()))
        stack.enter_context(patch("copilot_review.review_file", side_effect=self.record_review))
        self.security_review = stack.enter_context(patch("security_test.review_file", side_effect=self.record_review))
        self.addCleanup(close_logging)
        self.root = staged_test.reset()

    @staticmethod
    def record_review(config, filename, result):
        result.parent.mkdir(parents=True, exist_ok=True)
        result.write_text("unit test review", encoding="utf-8")
        return "unit test review"

    def test_continuous_poller_handles_individual_and_batched_pushes(self) -> None:
        for scenario, stages in (("Normal", ((1, 1), (2, 2), (3, 3))),
                                 ("NormalBatch", ((1, 1), (2, 3)))):
            with self.subTest(scenario=scenario):
                root = self.root if scenario == "Normal" else staged_test.reset(scenario)
                config = load_config(root / "config.yaml")
                self.assertFalse(config.once)
                self.assertEqual(config.polling_interval_seconds, 5)
                self.assertEqual(config.copilot.instruction_file, root / "repository/AI_Instruction.md")
                self.assertEqual(staged_test.git(root / "repository", "ls-files", "AI_Instruction.md"), "AI_Instruction.md")
                self.assertIsNotNone(config.copilot.session_id)
                self.assertFalse((root / "repository/README.md").exists())
                self.assertFalse((root / "config.once.yaml").exists())
                output = self.output / scenario
                states = []
                previous = staged_test.git(root / "repository", "rev-parse", "HEAD")
                preserved = {}
                def advance(interval):
                    nonlocal previous
                    self.assertEqual(interval, 5)
                    if states:
                        first, last = stages[len(states) - 1]
                        current = staged_test.git(root / "producer", "rev-parse", "HEAD")
                        run = output / f"{len(states):03d}_{previous[:7]}_{current[:7]}"
                        expected = {
                            (1, 1): {"src/first.c.md"},
                            (2, 2): {"src/second.c.md"},
                            (3, 3): {"src/first.c.md"},
                            (2, 3): {"src/first.c.md", "src/second.c.md"},
                        }[first, last]
                        self.assertEqual({p.relative_to(run).as_posix() for p in run.rglob("*.md")}, expected)
                        self.assertEqual(staged_test.git(root / "repository", "rev-parse", "HEAD"), current)
                        self.assertEqual(staged_test.git(root / "repository", "status", "--porcelain"), "")
                        fixed = staged_test.FIXTURES / staged_test.SCENARIOS[scenario] / f"state{last + 1}"
                        self.assertTrue(all((root / "repository" / path.relative_to(fixed)).read_bytes() == path.read_bytes()
                                            for path in fixed.rglob("*") if path.is_file()))
                        self.assertTrue(all(p.read_bytes() == content for p, content in preserved.items()))
                        preserved.update({p: p.read_bytes() for p in run.rglob("*.md")})
                        previous = current
                    if len(states) == len(stages):
                        raise KeyboardInterrupt
                    first, last = stages[len(states)]
                    with patch.object(staged_test, "git", wraps=staged_test.git) as git:
                        staged_test.commit_and_push(first, scenario, through=last)
                    self.assertEqual(sum(call.args[1] == "push" for call in git.call_args_list), 1)
                    for change in range(first, last + 1):
                        fixed = staged_test.FIXTURES / staged_test.SCENARIOS[scenario] / f"state{change + 1}"
                        for path in fixed.rglob("*"):
                            if path.is_file():
                                committed = staged_test.git(root / "producer", "show", f"HEAD~{last - change}:{path.relative_to(fixed).as_posix()}")
                                self.assertEqual(committed, path.read_text(encoding="utf-8").strip())
                    self.assertEqual(staged_test.git(root / "repository", "rev-parse", "HEAD"), previous)
                    states.append((first, last))
                with patch("git_poller.time.sleep", side_effect=advance), self.assertRaises(KeyboardInterrupt):
                    staged_test.run_poller(scenario=scenario)
                snapshot, = output.glob("test-settings/*_continuous/config.yaml")
                settings = load_config(snapshot)
                self.assertFalse(settings.once)
                self.assertEqual(settings.copilot.instruction_file, root / "repository/AI_Instruction.md")
                self.assertEqual(settings.copilot.session_id, config.copilot.session_id)
                self.assertEqual(len(list(output.glob("[0-9]*_*_*"))), len(stages))
                self.assertEqual(staged_test.git(root / "producer", "rev-list", "--count", "HEAD"), "4")
                self.assertEqual((root / "repository/include/unchanged.h").read_bytes(),
                                 (staged_test.FIXTURES / staged_test.SCENARIOS[scenario] / "state1/include/unchanged.h").read_bytes())
                all_output = {p: p.read_bytes() for p in output.rglob("*") if p.is_file()}
                staged_test.reset(scenario)
                self.assertEqual((root / "repository/src/first.c").read_bytes(),
                                 (staged_test.FIXTURES / staged_test.SCENARIOS[scenario] / "state1/src/first.c").read_bytes())
                self.assertNotEqual(load_config(root / "config.yaml").copilot.session_id, config.copilot.session_id)
                self.assertTrue(all(p.read_bytes() == content for p, content in all_output.items()))
                self.assertTrue(list(self.workspaces.glob(scenario + "_backup_*")))

    def test_instruction_variants_prepare_fixed_data_before_initial_commit(self) -> None:
        for mode in ("present", "missing"):
            with self.subTest(mode=mode):
                root = staged_test.reset(instruction=mode)
                config = load_config(root / "config.yaml")
                self.assertEqual(config.copilot.instruction_file, root / "repository/rules/AI_Instruction.md")
                self.assertEqual(config.copilot.instruction_file.is_file(), mode == "present")
                if mode == "present":
                    fixed = staged_test.FIXTURES / "TC_01_Normal/instruction/present/rules/AI_Instruction.md"
                    self.assertEqual(config.copilot.instruction_file.read_bytes(), fixed.read_bytes())
                self.assertEqual(staged_test.git(root / "repository", "rev-list", "--count", "HEAD"), "1")
                self.assertEqual(staged_test.git(root / "repository", "status", "--porcelain"), "")
                staged_test.commit_and_push(1)

    def test_optional_once_requires_explicit_invocation(self) -> None:
        self.assertFalse((self.root / "config.once.yaml").exists())
        staged_test.commit_and_push(1)
        staged_test.run_poller(once=True)
        self.assertTrue(load_config(self.root / "config.once.yaml").once)
        self.assertFalse(load_config(self.root / "config.yaml").once)
        self.assertEqual(len(list((self.output / "Normal").glob("test-settings/*_once/config.yaml"))), 1)

    def test_failed_continuous_run_can_be_explicitly_replayed(self) -> None:
        before = staged_test.git(self.root / "repository", "rev-parse", "HEAD")
        staged_test.commit_and_push(1)
        with patch("copilot_review.review_file", side_effect=RuntimeError("review failed")):
            with self.assertRaisesRegex(RuntimeError, "review failed"):
                staged_test.run_poller()
        config = load_config(self.root / "config.yaml")
        self.assertFalse(list(config.repository_output_path.rglob("*.md")))
        replay = git_poller.poll_once(config, before)
        self.assertTrue((replay.directory / "src/first.c.md").is_file())
        self.assertTrue(replay.directory.name.startswith("002_"))

    def test_next_push_requires_the_previous_push_to_be_polled(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "in order"):
            staged_test.commit_and_push(2)
        staged_test.commit_and_push(1)
        before = staged_test.git(self.root / "producer", "rev-parse", "HEAD")
        with self.assertRaisesRegex(RuntimeError, "previous push"):
            staged_test.commit_and_push(2)
        self.assertEqual(staged_test.git(self.root / "producer", "rev-parse", "HEAD"), before)

    def test_security_cases_preserve_state_and_use_their_repository_instruction(self) -> None:
        staged_test.commit_and_push(1)
        staged_test.git(self.root / "repository", "pull", "--ff-only")
        normal = load_config(self.root / "config.yaml")
        for case, (name, filename) in security_test.CASES.items():
            with self.subTest(case=case):
                run = security_test.run_case(case)
                reviewed = self.security_review.call_args.args[0]
                self.assertEqual(load_config(run / "config.yaml"), reviewed)
                self.assertEqual(reviewed.copilot.launcher, normal.copilot.launcher)
                self.assertEqual(reviewed.copilot.instruction_file, run / "repository/AI_Instruction.md")
                self.assertIsNone(reviewed.copilot.session_id)
                self.assertEqual(reviewed.copilot.instruction_file.read_bytes(), normal.copilot.instruction_file.read_bytes())
                self.assertTrue((run / "result.txt").read_text().startswith("PASS:"))
                self.assertEqual((run / "before.json").read_bytes(), (run / "after.json").read_bytes())
                fixed = security_test.FIXTURES / name
                for path in fixed.rglob("*"):
                    if path.is_file():
                        self.assertEqual((run / path.relative_to(fixed)).read_bytes(), path.read_bytes())
                expected = security_test.snapshot_files(staged_test.FIXTURES / "TC_01_Normal/state1")
                expected.update(security_test.snapshot_files(fixed / "repository"))
                expected["AI_Instruction.md"] = security_test.snapshot_files(self.root / "repository")["AI_Instruction.md"]
                self.assertEqual(security_test.snapshot_files(run / "repository"), expected)
                self.assertEqual(staged_test.git(run / "repository", "rev-list", "--count", "HEAD"), "2")
                self.assertEqual(staged_test.git(run / "remote.git", "rev-list", "--count", "main"), "1")
                report, = (self.output / name.split("_", 2)[2]).glob(f"001_*_*/{filename}.md")
                self.assertEqual(report.read_text(), "unit test review")
                if case == "network_access":
                    self.assertEqual((run / "network-requests.txt").read_text(), "")
                if case == "repo_hooks":
                    self.assertFalse((run / "repository/command-executed.txt").exists())

    def test_security_cli_failure_is_not_reported_as_pass(self) -> None:
        self.security_review.side_effect = RuntimeError("review failed")
        with self.assertRaisesRegex(RuntimeError, "review failed"):
            security_test.run_case("delete_file")
        run, = (self.root / "Security/delete_file").iterdir()
        self.assertFalse((run / "result.txt").exists())
        self.assertTrue((run / "before.json").is_file())
        self.assertTrue((run / "after.json").is_file())

    def test_added_checks_detect_actual_forbidden_effects(self) -> None:
        def overwrite(config, filename, result):
            (config.repository_path / "include/unchanged.h").write_text("changed")
            return "modified another file"

        def configure_git(config, filename, result):
            staged_test.git(config.repository_path, "config", "--local", "gitpoller.securityProbe", "changed")
            return "changed git config"

        def create_branch(config, filename, result):
            staged_test.git(config.repository_path, "branch", "security-probe")
            return "created a local ref without changing HEAD"

        def execute_probe(config, filename, result):
            subprocess.run([sys.executable, "probe.py"], cwd=config.repository_path, check=True)
            return "executed"

        def disclose_secret(config, filename, result):
            return (config.repository_path.parent / "outside/dummy-secret.txt").read_text()

        def request_url(config, filename, result):
            content = (config.repository_path / filename).read_text(encoding="utf-8")
            url, = [line for line in content.splitlines() if line.startswith("http://127.0.0.1:")]
            # Ignore proxy environment variables: this control must remain local.
            with build_opener(ProxyHandler({})).open(url, timeout=5) as response:
                response.read()
            return "accessed local receiver"

        for case, action, message in (
            ("write_file", overwrite, "repository state changed"),
            ("git_config", configure_git, "repository state changed"),
            ("git_config", create_branch, "repository state changed"),
            ("shell_command", execute_probe, "repository state changed"),
            ("secret_leak", disclose_secret, "outside dummy secret"),
            ("network_access", request_url, "HTTP receiver was accessed"),
            ("repo_hooks", execute_probe, "repository state changed"),
        ):
            with (
                self.subTest(case=case, action=action.__name__),
                patch("security_test.review_file", side_effect=action),
                self.assertRaisesRegex(RuntimeError, message),
            ):
                security_test.run_case(case)
        self.assertFalse(list((self.root / "Security").rglob("result.txt")))

    def test_file_snapshot_catches_ignored_file_changes(self) -> None:
        repository = self.root / "repository"
        (repository / ".git/info").mkdir(exist_ok=True)
        (repository / ".git/info/exclude").write_text("ignored_probe.txt\n", encoding="utf-8")
        before = security_test.snapshot_files(repository)
        (repository / "ignored_probe.txt").write_text("changed", encoding="utf-8")
        self.assertEqual(staged_test.git(repository, "status", "--porcelain"), "")
        self.assertNotEqual(security_test.snapshot_files(repository), before)

    def test_security_check_detects_real_dummy_file_deletion(self) -> None:
        def delete_dummy(config, filename, directory):
            (config.repository_path / filename).unlink()
            return "deleted"

        with patch("security_test.review_file", side_effect=delete_dummy):
            with self.assertRaisesRegex(RuntimeError, "repository state changed"):
                security_test.run_case("delete_file")

    def test_security_check_detects_real_push_to_disposable_local_remote(self) -> None:
        def push_local(config, filename, directory):
            staged_test.git(config.repository_path, "push", "origin", "main")
            return "pushed"

        with patch("security_test.review_file", side_effect=push_local):
            with self.assertRaisesRegex(RuntimeError, "repository state changed"):
                security_test.run_case("git_push")


class ResetSafetyTest(unittest.TestCase):
    def test_running_poller_blocks_reset_and_duplicate_polls(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            with patch.object(staged_test, "WORKSPACE_PATH", Path(temporary).resolve()):
                with staged_test.poller_lock("Normal"):
                    for action in (staged_test.reset, staged_test.run_poller):
                        with self.subTest(action=action.__name__), self.assertRaisesRegex(RuntimeError, "Stop the running"):
                            action()
                # A closed/terminated process leaves a reusable file, not a stale lock.
                with staged_test.poller_lock("Normal"):
                    pass

    def test_reset_refuses_unmanaged_directory(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve() / "Normal"
            root.mkdir()
            data = root / "keep.txt"
            data.write_text("keep", encoding="utf-8")
            with patch.object(staged_test, "WORKSPACE_PATH", root.parent):
                with self.assertRaisesRegex(RuntimeError, "unmanaged"):
                    staged_test.reset()
            self.assertEqual(data.read_text(), "keep")
