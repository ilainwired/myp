import sys
import tempfile
import unittest
from copy import deepcopy
from dataclasses import replace
from datetime import time
from pathlib import Path
from unittest.mock import patch
from uuid import UUID


PROJECT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT / "tests/test_support"))

import collect_evidence
import staged_test
from configuration import load_config


class EvidenceTest(unittest.TestCase):
    def test_batch_checks_require_both_files_and_the_state_two_to_four_range(self) -> None:
        config = replace(load_config(PROJECT / "configs/default.yaml"), polling_interval_seconds=5,
                         polling_start=time(0), polling_end=time(0))
        config = replace(config, copilot=replace(config.copilot,
                         instruction_file=config.repository_path / "AI_Instruction.md",
                         session_id=UUID("0cb916db-26aa-40f2-86b5-1ba81b225fd2")))
        files = collect_evidence.file_hashes(staged_test.FIXTURES / "TC_10_NormalBatch/state4")
        files["AI_Instruction.md"] = collect_evidence.hashlib.sha256((staged_test.FIXTURES / "AI_Instruction.md").read_bytes()).hexdigest()
        old_report = {"001_0000000_aaaaaaa/src/first.c.md": "old"}
        before = {"producer": {"commits": 2}, "repository": {"head": "a" * 40}, "reports": old_report}
        after = {
            name: {"commits": 4, "files": files, "head": "c" * 40, "status": ""}
            for name in ("producer", "repository")
        }
        after.update(remote_head="c" * 40, reports={
            **old_report, "002_aaaaaaa_ccccccc/src/first.c.md": "first",
            "002_aaaaaaa_ccccccc/src/second.c.md": "second",
        })
        with patch.object(collect_evidence, "load_config", return_value=config):
            self.assertTrue(all(collect_evidence.normal_checks(4, before, after, "NormalBatch").values()))
            missing = deepcopy(after)
            del missing["reports"]["002_aaaaaaa_ccccccc/src/second.c.md"]
            self.assertFalse(collect_evidence.normal_checks(4, before, missing, "NormalBatch")["only_expected_reports"])
            wrong_range = deepcopy(after)
            wrong_range["reports"] = {name.replace("002_aaaaaaa", "002_bbbbbbb"): digest
                                      for name, digest in after["reports"].items()}
            self.assertFalse(collect_evidence.normal_checks(4, before, wrong_range, "NormalBatch")["expected_review_range"])

    def test_source_capture_does_not_exclude_workspace_parent(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            project = root / "workspace/project"
            expected = (
                "README.md", "requirements.txt", "start.bat", "src/app.py",
                "configs/default.yaml", "tests/test_support/fixtures/input.txt",
            )
            ignored = (
                "src/__pycache__/app.pyc", "tests/test_support/workspace/old.txt",
            )
            for name in (*expected, *ignored):
                path = project / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(name, encoding="utf-8")
            destination = root / "evidence"
            with patch.object(collect_evidence, "PROJECT", project):
                collect_evidence.capture_sources(destination)
            copied = {
                path.relative_to(destination).as_posix(): path.read_text(encoding="utf-8")
                for path in destination.rglob("*") if path.is_file()
            }
            self.assertEqual(copied, {name: name for name in expected})
