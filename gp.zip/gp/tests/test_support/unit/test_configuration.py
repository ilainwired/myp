import contextlib
import io
import sys
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
from uuid import UUID

import yaml


PROJECT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(PROJECT / "src"), str(PROJECT / "tests/test_support")]

import security_test
import staged_test
from configuration import load_config


class ConfigurationTest(unittest.TestCase):
    def test_yaml_paths_and_defaults(self) -> None:
        config = load_config(PROJECT / "configs/default.yaml")
        self.assertEqual(config.repository_path, PROJECT / "repository")
        self.assertEqual(config.output_path, PROJECT / "output")
        self.assertEqual(config.repository_output_path, PROJECT / "output/GitPoller")
        self.assertEqual(config.handlers, ("copilot_review",))
        self.assertFalse(config.once)
        self.assertIsNone(config.from_commit)
        self.assertEqual(config.copilot.max_ai_credits, 100)
        self.assertEqual(config.copilot.launcher, ("copilot",))
        self.assertIsNone(config.copilot.session_id)
        self.assertFalse(hasattr(config.copilot, "prompt"))
        self.assertEqual(config.copilot.instruction_file, PROJECT / "repository/Instruction.md")
        self.assertEqual(config.polling_interval_seconds, 5)
        self.assertFalse(hasattr(config.copilot, "model"))
        self.assertFalse(hasattr(config.copilot, "reasoning_effort"))
        self.assertFalse(hasattr(config.copilot, "command"))
        self.assertFalse(hasattr(config.copilot, "name"))

        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "config.yaml"
            data = yaml.safe_load((PROJECT / "configs/default.yaml").read_text(encoding="utf-8"))
            del data["copilot"]["max_ai_credits"]
            path.write_text(yaml.safe_dump(data), encoding="utf-8")
            config = load_config(path)
            self.assertEqual(config.copilot.max_ai_credits, 100)
            self.assertEqual(config.repository_path, (path.parent / "../repository").resolve())
            data["copilot"]["max_ai_credits"] = 200
            path.write_text(yaml.safe_dump(data), encoding="utf-8")
            self.assertEqual(load_config(path).copilot.max_ai_credits, 200)

    def test_instruction_is_repository_relative_even_when_yaml_is_elsewhere(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            path = root / "settings/config.yaml"
            path.parent.mkdir()
            values = yaml.safe_load((PROJECT / "configs/default.yaml").read_text(encoding="utf-8"))
            values["repository"]["path"] = "../checkout"
            values["copilot"].pop("instruction_file")
            values.pop("polling")
            path.write_text(yaml.safe_dump(values), encoding="utf-8")
            config = load_config(path)
            self.assertEqual(config.copilot.instruction_file, root / "checkout/Instruction.md")
            self.assertEqual(config.polling_interval_seconds, 5)
            values["copilot"]["instruction_file"] = "rules/Instruction.md"
            path.write_text(yaml.safe_dump(values), encoding="utf-8")
            self.assertEqual(load_config(path).copilot.instruction_file, root / "checkout/rules/Instruction.md")
            values["copilot"]["instruction_file"] = None
            path.write_text(yaml.safe_dump(values), encoding="utf-8")
            self.assertIsNone(load_config(path).copilot.instruction_file)

    def test_yaml_launcher_is_an_argument_list_without_template_expansion(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "config.yaml"
            values = yaml.safe_load((PROJECT / "configs/default.yaml").read_text(encoding="utf-8"))
            del values["copilot"]["launcher"]
            path.write_text(yaml.safe_dump(values), encoding="utf-8")
            self.assertEqual(load_config(path).copilot.launcher, ("copilot",))
            launcher = ["C:/Program Files/node.exe", "C:/tools/${literal}/loader.js"]
            values["copilot"]["launcher"] = launcher
            path.write_text(yaml.safe_dump(values), encoding="utf-8")
            self.assertEqual(load_config(path).copilot.launcher, tuple(launcher))
            for invalid in ("copilot", [], [""], [123], None):
                with self.subTest(value=invalid):
                    values["copilot"]["launcher"] = invalid
                    path.write_text(yaml.safe_dump(values), encoding="utf-8")
                    with self.assertRaisesRegex(ValueError, "copilot.launcher"):
                        load_config(path)

    def test_yaml_does_not_construct_python_objects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "config.yaml"
            path.write_text("!!python/object/apply:builtins.list []", encoding="utf-8")
            with self.assertRaises(yaml.YAMLError):
                load_config(path)

    def test_yaml_session_id_accepts_uuid_and_rejects_invalid_values(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "config.yaml"
            values = yaml.safe_load((PROJECT / "configs/default.yaml").read_text(encoding="utf-8"))
            session_id = "0cb916db-26aa-40f2-86b5-1ba81b225fd2"
            values["copilot"]["session_id"] = session_id
            path.write_text(yaml.safe_dump(values), encoding="utf-8")
            self.assertEqual(load_config(path).copilot.session_id, UUID(session_id))
            for invalid in ("", "review-name", "../outside", "--allow-all"):
                with self.subTest(value=invalid):
                    values["copilot"]["session_id"] = invalid
                    path.write_text(yaml.safe_dump(values), encoding="utf-8")
                    with self.assertRaises(ValueError):
                        load_config(path)

    def test_yaml_execution_settings_and_defaults(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "config.yaml"
            values = yaml.safe_load((PROJECT / "configs/default.yaml").read_text(encoding="utf-8"))
            del values["execution"]
            path.write_text(yaml.safe_dump(values), encoding="utf-8")
            self.assertFalse(load_config(path).once)
            self.assertIsNone(load_config(path).from_commit)

            values["execution"] = {"once": True, "from_commit": "0123456"}
            path.write_text(yaml.safe_dump(values), encoding="utf-8")
            config = load_config(path)
            self.assertTrue(config.once)
            self.assertEqual(config.from_commit, "0123456")
            for invalid in ({"once": "false"}, {"from_commit": 1234567}, {"from_commit": ""}):
                with self.subTest(value=invalid):
                    values["execution"] = invalid
                    path.write_text(yaml.safe_dump(values), encoding="utf-8")
                    with self.assertRaises(ValueError):
                        load_config(path)

    def test_repository_name_cannot_escape_output_directory(self) -> None:
        config = load_config(PROJECT / "configs/default.yaml")
        for name in ("", ".", "..", "../other", "a/b", "a\\b", "C:other"):
            with self.subTest(name=name), self.assertRaises(ValueError):
                replace(config, repository_name=name)

    def test_tests_directory_separates_executables_and_support(self) -> None:
        paths = list((PROJECT / "tests").iterdir())
        executables = [path for path in paths if path.is_file()]
        expected = {
            "TC_01_Normal_STEP_01_Reset.bat", "TC_01_Normal_STEP_02_FirstReview.bat",
            "TC_01_Normal_STEP_03_SecondReview.bat", "UnitTests.bat",
            "TC_01_Normal_STEP_04_ThirdReview.bat", "TC_01_Normal_StartPoller.bat",
            "TC_01_Normal_PollOnce.bat", "TC_10_NormalBatch_STEP_01_Reset.bat",
            "TC_10_NormalBatch_STEP_02_FirstReview.bat", "TC_10_NormalBatch_STEP_03_BatchReview.bat",
            "TC_10_NormalBatch_StartPoller.bat", "TC_10_NormalBatch_PollOnce.bat",
        }
        expected.update(
            f"{name}.bat" for name, filename in security_test.CASES.values()
        )
        self.assertEqual({path.name for path in executables}, expected)
        self.assertEqual([path.name for path in paths if path.is_dir()], ["test_support"])
        cases = set(staged_test.SCENARIOS.values()) | {name for name, _ in security_test.CASES.values()}
        self.assertEqual({path.name for path in staged_test.FIXTURES.glob("TC_*") if path.is_dir()}, cases)

    def test_manual_entry_points_catch_errors(self) -> None:
        for module, argument, action in (
            (staged_test, "first", "commit_and_push"),
            (security_test, "delete_file", "run_case"),
        ):
            with (
                self.subTest(module=module.__name__),
                patch.object(sys, "argv", [module.__name__, argument]),
                patch.object(module, action, side_effect=RuntimeError("test failure")),
                contextlib.redirect_stderr(io.StringIO()) as errors,
            ):
                self.assertEqual(module.main(), 1)
                self.assertEqual(errors.getvalue(), "ERROR: test failure\n")
