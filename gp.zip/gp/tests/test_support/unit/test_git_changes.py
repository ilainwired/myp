import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT / "src"))

from git_poller import _changed_files


class GitChangesTest(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.repository = Path(temporary.name)
        self.git("init", "-b", "main")
        self.git("config", "user.name", "GitPoller Test")
        self.git("config", "user.email", "test@example.invalid")
        for name in ("a.c", "b.c", "old.c", "conflict.c", "unchanged.h"):
            self.write(name, "0\n")
        self.before = self.commit("initial")

    def git(self, *arguments):
        return subprocess.check_output(
            ["git", *arguments], cwd=self.repository, stderr=subprocess.DEVNULL,
            timeout=30,
        ).decode("utf-8").strip()

    def write(self, name, content):
        (self.repository / name).write_text(content, encoding="utf-8")

    def commit(self, message):
        self.git("add", "-A")
        self.git("commit", "-m", message)
        return self.git("rev-parse", "HEAD")

    def test_two_endpoints_include_earlier_changes_but_exclude_reverted_files(self):
        self.write("a.c", "1\n")
        self.write("b.c", "2\n")
        self.write("transient.c", "temporary\n")
        self.commit("state 3")
        self.write("a.c", "0\n")
        self.write("日本語 file.c", "3\n")
        (self.repository / "old.c").rename(self.repository / "renamed.c")
        (self.repository / "transient.c").unlink()
        after = self.commit("state 4")
        self.assertEqual(_changed_files(self.repository, self.before, after), [
            "b.c", "old.c", "renamed.c", "日本語 file.c",
        ])
        self.assertEqual(_changed_files(self.repository, after, after), [])
