import contextlib
import csv
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

import yaml
from dataclasses import replace
from datetime import datetime, timedelta
from pathlib import Path, PurePosixPath
from unittest.mock import patch
from uuid import uuid4


PROJECT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT / "src"))

from configuration import Change, load_config
from copilot_review import (
    _copilot_answer, _resolve_copilot_command,
    _review_environment, build_command, review, review_file,
)
from runtime import close_logging, configure_logging, run_command


REAL_SUBPROCESS_RUN = subprocess.run


class CopilotTest(unittest.TestCase):
    def setUp(self) -> None:
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        stack = contextlib.ExitStack()
        self.addCleanup(stack.close)
        stack.enter_context(patch.dict(os.environ, {"COPILOT_HOME": str(self.root / "auth")}))
        self.console = stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
        self.errors = stack.enter_context(contextlib.redirect_stderr(io.StringIO()))
        self.addCleanup(close_logging)
        config = load_config(PROJECT / "configs/default.yaml")
        self.config = replace(
            config, repository_path=self.root, output_path=self.root / "output",
            copilot=replace(
                config.copilot,
                launcher=("copilot-test.exe",),
                instruction_file=None,
            ),
        )
        (self.root / "file.c").write_text("hello\n", encoding="utf-8")
        self.answer = "review answer"
        self.total_nano = 250_000_000
        self.extra_events = []
        self.process_error = None
        self.process = stack.enter_context(patch("runtime.subprocess.run", side_effect=self.complete_process))

    def complete_process(self, command, *, cwd, stdout, stderr, env, **kwargs):
        # Mock only the subprocess boundary; exercise real logging/session handling.
        session_id = command[command.index("--session-id") + 1]
        home = Path(env.get("COPILOT_HOME") or Path.home() / ".copilot")
        events = home / "session-state" / session_id / "events.jsonl"
        events.parent.mkdir(parents=True, exist_ok=True)
        records = [] if events.exists() else [{"type": "session.start", "data": {
            "sessionId": session_id, "context": {"cwd": str(cwd)},
        }}]
        if self.answer is not None:
            records.append({"type": "assistant.message", "data": {"phase": "final_answer", "content": self.answer}})
        records.extend(self.extra_events)
        if self.total_nano is not None:
            usage = {"totalNanoAiu": self.total_nano}
            Path(command[command.index("--usage-output-file") + 1]).write_text(json.dumps(usage) + "\n", encoding="utf-8")
            records.append({"type": "session.shutdown", "data": usage})
            stderr.write(f"AI Credits {self.total_nano / 1e9:.2f}\n".encode())
        with events.open("a", encoding="utf-8") as stream:
            stream.write("\n".join(json.dumps(record) for record in records) + "\n")
        stdout.write(("\n".join(json.dumps(record) for record in records) + "\n").encode("utf-8"))
        if self.process_error:
            raise self.process_error
        return subprocess.CompletedProcess(command, 0)

    def csv_rows(self):
        with (self.config.repository_output_path / "copilot.csv").open(encoding="utf-8-sig", newline="") as file:
            return list(csv.DictReader(file))

    def test_review_logs_command_usage_and_result_without_the_answer(self) -> None:
        directory = self.config.repository_output_path / "001_aaaaaaa_bbbbbbb"
        change = Change("a" * 40, "b" * 40, (PurePosixPath("file.c"),), directory)
        log_path = configure_logging(self.config.repository_output_path)
        review(self.config, change)
        close_logging()
        result_path = directory / "file.c.md"
        answer = result_path.read_text(encoding="utf-8")
        self.assertIn("review answer", answer)
        self.assertNotIn("totalNanoAiu", answer)
        self.assertEqual(list(directory.iterdir()), [result_path])
        self.assertIn("review answer", self.console.getvalue())
        self.assertIn("AI Credits 0.25", self.errors.getvalue())
        log = log_path.read_text(encoding="utf-8")
        self.assertRegex(log, r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}")
        self.assertIn(str(result_path), log)
        self.assertIn('"ai_credits": "0.25"', log)
        for text in ("review answer", "tool output"):
            self.assertNotIn(text, log)
        for option in ("--available-tools=view,glob,grep", "--allow-tool=read", "--deny-tool=shell,write,url"):
            self.assertIn(option, log)
        self.assertNotIn("--model", log)
        self.assertNotIn("--effort", log)
        command = json.loads(next(line.split("Command: ")[1] for line in log.splitlines() if "Command: " in line))
        self.assertFalse(Path(command[command.index("--usage-output-file") + 1]).parent.exists())
        row, = self.csv_rows()
        self.assertEqual(json.loads(row["command"]), command)
        self.assertEqual(row["target_file"], "file.c")
        self.assertEqual(row["ai_credits"], "0.25")
        self.assertEqual(row["session_ai_credits"], "0.25")
        self.assertEqual(row["credit_source"], "usage.json:totalNanoAiu")
        self.assertEqual(row["status"], "success")
        self.assertEqual(row["backend"], "copilot")
        self.assertEqual(Path(row["result_file"]), result_path.resolve())
        self.assertEqual(datetime.fromisoformat(row["started_at"]).utcoffset(), timedelta(hours=9))
        self.assertLessEqual(datetime.fromisoformat(row["started_at"]), datetime.fromisoformat(row["finished_at"]))

    def test_failure_logs_usage_displays_error_and_does_not_save_an_answer(self) -> None:
        result_path = self.root / "failed/file.c.md"
        self.process_error = subprocess.CalledProcessError(2, "copilot")
        with (
            self.assertLogs("GitPoller") as logs,
            self.assertRaises(subprocess.CalledProcessError),
        ):
            review_file(self.config, PurePosixPath("file.c"), result_path)
        self.assertIn("AI Credits 0.25", self.errors.getvalue())
        self.assertIn('"ai_credits": "0.25"', "\n".join(logs.output))
        self.assertFalse(result_path.exists())
        row, = self.csv_rows()
        self.assertEqual(row["status"], "error")
        self.assertEqual(row["ai_credits"], "0.25")

    def test_session_resumes_and_uses_only_the_current_answer(self) -> None:
        session_id = uuid4()
        config = replace(self.config, copilot=replace(
            self.config.copilot, session_id=session_id,
        ))
        events = self.root / "auth/session-state" / str(session_id) / "events.jsonl"
        self.extra_events = [{"type": "session.error", "data": {"message": "test error"}}]
        with self.assertRaises(RuntimeError):
            review_file(config, PurePosixPath("file.c"), self.root / "failed.md")
        self.extra_events = []
        previous = events.read_bytes()
        self.assertIn(b'"type": "session.error"', previous)

        self.answer = "updated answer"
        with self.assertLogs("GitPoller") as logs:
            answer = review_file(config, PurePosixPath("file.c"), self.root / "resumed.md")
        self.assertIn("updated answer", answer)
        self.assertNotIn("review answer", answer)
        self.assertTrue(events.read_bytes().startswith(previous))
        self.assertGreater(events.stat().st_size, len(previous))
        self.assertIn(f"Copilot session: {session_id} (resume)", "\n".join(logs.output))
        command = json.loads(next(line.split("Command: ")[1] for line in logs.output if "Command: " in line))
        self.assertEqual(command[command.index("--session-id") + 1], str(session_id))
        self.assertNotIn("--name", command)
        self.assertFalse(Path(command[command.index("--usage-output-file") + 1]).parent.exists())
        self.assertFalse((config.repository_output_path / "sessions").exists())

    def test_resume_without_a_new_answer_does_not_return_an_old_one(self) -> None:
        config = replace(self.config, copilot=replace(self.config.copilot, session_id=uuid4()))
        review_file(config, PurePosixPath("file.c"), self.root / "first.md")
        self.answer = None
        with self.assertRaisesRegex(RuntimeError, "最終回答"):
            review_file(config, PurePosixPath("file.c"), self.root / "second.md")
        self.assertFalse((self.root / "second.md").exists())
        self.assertEqual([row["status"] for row in self.csv_rows()], ["success", "error"])

    def test_session_history_survives_a_process_failure(self) -> None:
        config = replace(self.config, copilot=replace(self.config.copilot, session_id=uuid4()))
        self.process_error = subprocess.CalledProcessError(2, "copilot")
        with self.assertRaises(subprocess.CalledProcessError):
            review_file(config, PurePosixPath("file.c"), self.root / "failed.md")
        self.process_error = None
        self.assertFalse((self.root / "failed.md").exists())
        with self.assertLogs("GitPoller") as logs:
            review_file(config, PurePosixPath("file.c"), self.root / "resumed.md")
        self.assertIn("(resume)", "\n".join(logs.output))

    def test_unspecified_session_is_new_each_time_and_saved_by_copilot(self) -> None:
        session_ids = []
        for number in (1, 2):
            with self.assertLogs("GitPoller") as logs:
                review_file(self.config, PurePosixPath("file.c"), self.root / f"{number}.md")
            command = json.loads(next(line.split("Command: ")[1] for line in logs.output if "Command: " in line))
            session_ids.append(command[command.index("--session-id") + 1])
            self.assertIn("(new)", "\n".join(logs.output))
        self.assertNotEqual(*session_ids)
        self.assertFalse((self.config.repository_output_path / "sessions").exists())
        for session_id in session_ids:
            self.assertTrue((self.root / "auth/session-state" / session_id / "events.jsonl").is_file())

    def test_existing_copilot_session_is_continued_in_place(self) -> None:
        session_id = uuid4()
        source = self.root / "auth/session-state" / str(session_id)
        source.mkdir(parents=True)
        original = json.dumps({
            "type": "session.start",
            "data": {"sessionId": str(session_id), "context": {"cwd": str(self.root)}},
        }) + '\n{"type":"session.error","data":{"message":"old error"}}\n'
        (source / "events.jsonl").write_text(original, encoding="utf-8")
        (self.root / "auth/mcp-config.json").write_text('{"untrusted":"config"}', encoding="utf-8")
        config = replace(self.config, copilot=replace(self.config.copilot, session_id=session_id))
        with self.assertLogs("GitPoller") as logs:
            answer = review_file(config, PurePosixPath("file.c"), self.root / "imported.md")
        self.assertIn("review answer", answer)
        self.assertIn("(resume)", "\n".join(logs.output))
        updated = (source / "events.jsonl").read_text(encoding="utf-8")
        self.assertTrue(updated.startswith(original))
        self.assertGreater(len(updated), len(original))
        self.assertFalse((config.repository_output_path / "sessions").exists())

    def test_prepared_session_uses_the_target_repository_for_review(self) -> None:
        session_id = uuid4()
        source = self.root / "auth/session-state" / str(session_id)
        source.mkdir(parents=True)
        (source / "events.jsonl").write_text(json.dumps({
            "type": "session.start",
            "data": {"sessionId": str(session_id), "context": {"cwd": str(self.root / "elsewhere")}},
        }) + "\n", encoding="utf-8")
        config = replace(self.config, copilot=replace(self.config.copilot, session_id=session_id))
        review_file(config, PurePosixPath("file.c"), self.root / "other.md")
        command = self.process.call_args.args[0]
        self.assertEqual(command[command.index("-C") + 1], str(self.root.resolve()))
        self.assertEqual(command[command.index("--session-id") + 1], str(session_id))
        self.assertEqual(self.process.call_args.kwargs["cwd"], self.root)

    def test_missing_usage_is_not_estimated(self) -> None:
        self.total_nano = None
        with (
            self.assertLogs("GitPoller") as logs,
        ):
            answer = review_file(self.config, PurePosixPath("file.c"), self.root / "missing/file.c.md")
        self.assertEqual(answer, "review answer")
        self.assertNotIn("Usage:", "\n".join(logs.output))
        self.assertNotIn("credits", self.console.getvalue())
        self.assertNotIn("未取得", self.console.getvalue())
        row, = self.csv_rows()
        self.assertEqual(row["status"], "success")
        self.assertEqual(row["ai_credits"], "")
        self.assertEqual(row["credit_source"], "")
        self.assertEqual(row["backend"], "copilot")

    def test_csv_append_preserves_unicode_commas_quotes_and_multiline_command(self) -> None:
        filename = PurePosixPath("日本語, file.c")
        (self.root / filename).write_text("source", encoding="utf-8")
        instruction = self.root / "Instruction.md"
        text = 'Review "quotes", commas & | %PATH%\nthird line'
        instruction.write_text(text, encoding="utf-8")
        config = replace(self.config, copilot=replace(self.config.copilot, instruction_file=instruction))
        for index in (1, 2):
            review_file(config, filename, self.root / f"{index}.md")
        path = config.repository_output_path / "copilot.csv"
        self.assertTrue(path.read_bytes().startswith(b"\xef\xbb\xbf"))
        self.assertEqual(path.read_bytes().count(b"\xef\xbb\xbf"), 1)
        self.assertEqual(len(path.read_text(encoding="utf-8-sig").splitlines()), 3)
        rows = self.csv_rows()
        self.assertEqual(len(rows), 2)
        for row in rows:
            self.assertEqual(row["target_file"], filename.as_posix())
            command = json.loads(row["command"])
            prompt = command[command.index("--prompt") + 1]
            self.assertEqual(prompt.splitlines()[0], filename.as_posix())
            self.assertTrue(prompt.endswith(text))
        self.assertNotEqual(rows[0]["session_id"], rows[1]["session_id"])

    def test_csv_resumed_session_subtracts_persisted_usage_without_rounding(self) -> None:
        config = replace(self.config, copilot=replace(self.config.copilot, session_id=uuid4()))
        for index in (1, 2):
            self.total_nano = index * 250_000_001
            review_file(config, PurePosixPath("file.c"), self.root / f"{index}.md")
        rows = self.csv_rows()
        self.assertEqual([row["ai_credits"] for row in rows], ["0.250000001", "0.250000001"])
        self.assertEqual([row["session_ai_credits"] for row in rows], ["0.250000001", "0.500000002"])
        self.assertEqual([row["resumed"] for row in rows], ["false", "true"])
        self.assertEqual(rows[0]["session_id"], rows[1]["session_id"])

    def test_csv_formula_like_filename_is_text_and_command_keeps_original(self) -> None:
        filename = PurePosixPath("=1+2.c")
        (self.root / filename).write_text("source", encoding="utf-8")
        review_file(self.config, filename, self.root / "result.md")
        row, = self.csv_rows()
        self.assertEqual(row["target_file"], "'=1+2.c")
        command = json.loads(row["command"])
        self.assertEqual(command[command.index("--prompt") + 1].splitlines()[0], filename.as_posix())

    def test_csv_records_timeout_and_launch_failure(self) -> None:
        for error, status in ((subprocess.TimeoutExpired("copilot", 1), "error"),
                              (FileNotFoundError("copilot"), "error")):
            with self.subTest(status=status), patch("runtime.subprocess.run", side_effect=error):
                with self.assertRaises(type(error)):
                    review_file(self.config, PurePosixPath("file.c"), self.root / "failed.md")
                row = self.csv_rows()[-1]
                self.assertEqual(row["status"], status)
                self.assertEqual(row["ai_credits"], "")
                self.assertFalse((self.root / "failed.md").exists())

    def test_csv_records_interruption(self) -> None:
        with patch("copilot_review.run_command", side_effect=KeyboardInterrupt), self.assertRaises(KeyboardInterrupt):
            review_file(self.config, PurePosixPath("file.c"), self.root / "interrupted.md")
        row, = self.csv_rows()
        self.assertEqual(row["status"], "error")
        self.assertEqual(row["ai_credits"], "")

    def test_csv_write_failure_propagates_to_outer_handler(self) -> None:
        for mode in ("success", "fail"):
            with (
                self.subTest(mode=mode),
                patch.object(self, "process_error", None if mode == "success" else subprocess.CalledProcessError(2, "copilot")),
                patch("copilot_logging.append_row", side_effect=PermissionError("CSV is locked")),
                self.assertRaises(PermissionError),
            ):
                review_file(self.config, PurePosixPath("file.c"), self.root / "result.md")

    def test_review_preserves_nested_paths_and_source_extensions(self) -> None:
        filenames = tuple(map(PurePosixPath, ("src/file.c", "other/file.c", "include/nested/a.h")))
        for filename in filenames:
            source = self.config.repository_path / filename
            source.parent.mkdir(parents=True, exist_ok=True)
            source.write_text(filename.as_posix(), encoding="utf-8")
        change = Change("a", "b", filenames, self.root / "nested")
        review(self.config, change)
        self.assertEqual(
            sorted(path.relative_to(change.directory).as_posix() for path in change.directory.rglob("*.md")),
            ["include/nested/a.h.md", "other/file.c.md", "src/file.c.md"],
        )
        for filename in filenames:
            answer = (change.directory / f"{filename.as_posix()}.md").read_text(encoding="utf-8")
            self.assertEqual(answer, "review answer")
        self.assertEqual([row["target_file"] for row in self.csv_rows()], [name.as_posix() for name in filenames])

    def test_prompt_is_one_argument_and_inserted_values_are_not_reexpanded(self) -> None:
        settings = self.config.copilot
        prompt = 'src/file with spaces.c\nReview "quoted" & | %PATH% ${keep_literal}\n--allow-all --name=injected'
        session_id = str(uuid4())
        command = build_command(
            settings, prompt, session_id, self.root / "usage.json", self.root,
        )
        self.assertEqual(command[:len(settings.launcher)], list(settings.launcher))
        self.assertEqual(command[command.index("--prompt") + 1], prompt)
        self.assertEqual(command[command.index("--session-id") + 1], session_id)
        self.assertEqual(command[command.index("--max-ai-credits") + 1], "100.0")
        self.assertNotIn("--allow-all", command)
        self.assertNotIn("--name=injected", command)

    def test_instruction_file_is_inlined_without_exposing_its_directory(self) -> None:
        instruction = self.root / "instructions.md"
        instruction.write_text("Keep ${literal} unchanged.", encoding="utf-8")
        config = replace(
            self.config,
            copilot=replace(self.config.copilot, instruction_file=instruction),
        )
        with self.assertLogs("GitPoller") as logs:
            answer = review_file(config, PurePosixPath("file.c"), self.root / "inlined/file.c.md")
        command = self.process.call_args.args[0]
        prompt = command[command.index("--prompt") + 1]
        self.assertIn("Keep ${literal} unchanged.", prompt)
        self.assertNotIn("--add-dir", "\n".join(logs.output))

    def test_optional_instruction_at_yaml_path_is_read_on_each_review(self) -> None:
        values = yaml.safe_load((PROJECT / "configs/default.yaml").read_text(encoding="utf-8"))
        values["repository"]["path"] = str(self.root)
        values["output"] = str(self.root / "output")
        values["copilot"]["launcher"] = ["copilot-test.exe"]
        values["copilot"]["instruction_file"] = "review-rules/Instruction.md"
        yaml_path = self.root / "settings/config.yaml"
        yaml_path.parent.mkdir()
        yaml_path.write_text(yaml.safe_dump(values), encoding="utf-8")
        config = load_config(yaml_path)
        instruction = self.root / "review-rules/Instruction.md"
        # Missing instructions must still start Copilot and save its answer.
        for index, content in enumerate((None, "RULE_ONE ${literal}", "RULE_TWO")):
            if content is not None:
                instruction.parent.mkdir(exist_ok=True)
                instruction.write_text(content, encoding="utf-8")
            result = self.root / f"instruction-{index}.md"
            review_file(config, PurePosixPath("file.c"), result)
            command = self.process.call_args.args[0]
            prompt = command[command.index("--prompt") + 1]
            self.assertIn("当該ファイルのみをレビューしてください。", prompt)
            self.assertIn("結果はMarkdownで出力してください。", prompt)
            self.assertEqual(result.read_text(encoding="utf-8"), "review answer")
            if content is not None:
                self.assertIn(content, prompt)
            else:
                self.assertNotIn("RULE_", prompt)
            if index == 2:
                self.assertNotIn("RULE_ONE", prompt)

    def test_command_keeps_review_permissions_and_has_no_session_name(self) -> None:
        settings = replace(self.config.copilot, max_ai_credits=200)
        session_id = str(uuid4())
        usage_file = self.root / "usage file.json"
        command = build_command(settings, "review", session_id, usage_file, self.root)
        self.assertEqual(command[len(settings.launcher):], [
            "-C", str(self.root.resolve()),
            "--prompt", "review",
            "--session-id", session_id,
            "--max-ai-credits", "200",
            "--available-tools=view,glob,grep",
            "--allow-tool=read",
            "--deny-tool=shell,write,url",
            "--disallow-temp-dir",
            "--disable-builtin-mcps",
            "--no-custom-instructions",
            "--no-ask-user",
            "--no-auto-update",
            "--no-remote",
            "--no-remote-export",
            "--no-experimental",
            "--no-eager-powershell-resolution",
            "--output-format=json",
            "--usage-output-file", str(usage_file.resolve()),
        ])
        self.assertNotIn("--name", command)

    def test_copilot_home_and_authentication_are_used_without_copying_settings(self) -> None:
        original = self.root / "original"
        original.mkdir()
        content = '// Copilot configuration\n' + json.dumps({
            "lastLoggedInUser": {"host": "https://github.com", "login": "test", "token": "secret"},
            "loggedInUsers": [{"host": "https://github.com", "login": "test"}],
            "trusted_folders": ["*"], "allowed_tools": ["shell"], "installedPlugins": ["unsafe"],
        })
        (original / "config.json").write_text(content, encoding="utf-8")
        (original / "mcp-config.json").write_text("{}", encoding="utf-8")
        with patch.dict(os.environ, {
            "COPILOT_HOME": str(original), "COPILOT_ALLOW_ALL": "true",
            "COPILOT_CUSTOM_INSTRUCTIONS_DIRS": "unsafe", "COPILOT_GITHUB_TOKEN": "credential",
            "GITHUB_COPILOT_PROMPT_MODE_REPO_HOOKS": "true",
        }):
            env = _review_environment()
            self.assertEqual(os.environ["COPILOT_ALLOW_ALL"], "true")
        self.assertEqual(Path(env["COPILOT_HOME"]), original)
        self.assertEqual(env["COPILOT_GITHUB_TOKEN"], "credential")
        for key in ("REPO_HOOKS", "WORKSPACE_MCP", "EXTENSIONS"):
            self.assertEqual(env[f"GITHUB_COPILOT_PROMPT_MODE_{key}"], "false")
        self.assertFalse((self.root / "fresh").exists())
        self.assertFalse((original / "settings.json").exists())
        self.assertEqual((original / "config.json").read_text(encoding="utf-8"), content)

    def test_no_home_setting_is_required_or_added(self) -> None:
        with patch.dict(os.environ, {}, clear=True), patch("pathlib.Path.home", return_value=self.root):
            self.assertNotIn("COPILOT_HOME", _review_environment())
            review_file(self.config, PurePosixPath("file.c"), self.root / "no-setting.md")
        self.assertEqual((self.root / "no-setting.md").read_text(), "review answer")
        self.assertEqual(self.csv_rows()[0]["ai_credits"], "0.25")

    def test_answer_comes_from_stdout_without_a_history_file(self) -> None:
        with patch("copilot_review.run_command", return_value=json.dumps({
            "type": "assistant.message", "data": {"phase": "final_answer", "content": "# Markdown\n\n**answer**"},
        })):
            answer = review_file(self.config, PurePosixPath("file.c"), self.root / "stdout.md")
        self.assertEqual(answer, "# Markdown\n\n**answer**")
        self.assertFalse((self.root / "auth").exists())

    def test_answer_parser_ignores_usage_and_rejects_cli_errors(self) -> None:
        output = "\n".join(json.dumps(event) for event in [
            {"type": "assistant.message", "data": {"phase": "final_answer", "content": "review"}},
            {"type": "assistant.message", "data": {"phase": "commentary", "content": "later"}},
            {"type": "session.shutdown", "data": {"totalNanoAiu": 1}},
        ])
        self.assertEqual(_copilot_answer(output), "review")
        with self.assertRaises(RuntimeError):
            _copilot_answer(output + '\n{"type":"session.error","data":{"message":"test"}}')
        with self.assertRaises(RuntimeError):
            _copilot_answer('{"type":"session.shutdown","data":{}}')
        with self.assertRaises(json.JSONDecodeError):
            _copilot_answer('invalid JSON')

    def test_deleted_files_do_not_trigger_current_file_review(self) -> None:
        change = Change("a", "b", (PurePosixPath("deleted.c"),), self.root / "run")
        with patch("copilot_review.review_file") as handler:
            review(self.config, change)
        handler.assert_not_called()

    def test_timeout_preserves_raw_bytes_and_closes_stdin(self) -> None:
        self.process.side_effect = REAL_SUBPROCESS_RUN
        script = (
            "import sys,time; "
            "sys.stdout.buffer.write(b'out\\r\\n'+sys.stdin.buffer.read()+b'EOF\\r\\n'); "
            "sys.stdout.buffer.flush(); "
            "sys.stderr.buffer.write(b'err\\r\\n'); sys.stderr.buffer.flush(); time.sleep(30)"
        )
        with self.assertRaises(subprocess.TimeoutExpired):
            run_command(
                [sys.executable, "-c", script], self.root, self.root / "timeout",
                1, os.environ.copy(),
            )
        self.assertEqual((self.root / "timeout/stdout.log").read_bytes(), b"out\r\nEOF\r\n")
        self.assertEqual((self.root / "timeout/stderr.log").read_bytes(), b"err\r\n")

    @unittest.skipUnless(os.name == "nt" and shutil.which("node"), "Windows npm launcher test")
    def test_npm_launcher_preserves_multiline_prompt_and_shell_characters(self) -> None:
        self.process.side_effect = REAL_SUBPROCESS_RUN
        loader = self.root / "node_modules/@github/copilot/npm-loader.js"
        loader.parent.mkdir(parents=True)
        loader.write_text("console.log(JSON.stringify(process.argv.slice(2)));", encoding="utf-8")
        with patch("copilot_review.shutil.which", return_value=str(self.root / "copilot.cmd")):
            command = _resolve_copilot_command(("copilot",))
        prompt = 'file.c\nReview & | %PATH% "quoted"\nthird line'
        output = run_command(
            [*command, "-p", prompt], self.root, self.root / "node",
            10, os.environ.copy(),
        )
        self.assertEqual(json.loads(output), ["-p", prompt])
