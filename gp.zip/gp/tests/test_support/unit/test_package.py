import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[3]


@unittest.skipUnless(os.name == "nt", "Windows packaging batch")
class PackageTest(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve() / "project with spaces"
        (self.root / "tools").mkdir(parents=True)
        shutil.copy2(PROJECT / "tools/clean_workspace.bat", self.root / "tools/clean_workspace.bat")
        self.kept = ("start.bat", "src/git_poller.py", "configs/default.yaml",
                     "repository/Instruction.md", "docs/TestResultReport.md",
                     ".git/config",
                     *(path.relative_to(PROJECT).as_posix()
                       for path in (PROJECT / "tests/test_support/fixtures").rglob("*") if path.is_file()))
        self.generated = ("src/__pycache__/app.pyc", "tests/test_support/__pycache__/test.pyc",
                          "tests/test_support/unit/loose.pyc", "tools/__pycache__/tool.pyc",
                          "output/Normal/copilot.csv", "docs/evidence/run/log.txt",
                          "tests/test_support/workspace/Normal_backup/repository/.git/config")
        for name in (*self.kept, *self.generated):
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(name, encoding="utf-8")

    def run_batch(self, *arguments):
        return subprocess.run(["cmd.exe", "/d", "/c", str(self.root / "tools/clean_workspace.bat"), *arguments],
                              cwd=self.root.parent, capture_output=True, text=True, timeout=30)

    def test_cleanup_removes_only_generated_data_and_is_repeatable(self):
        result = self.run_batch()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(all((self.root / name).read_text(encoding="utf-8") == name for name in self.kept))
        self.assertFalse(any((self.root / name).exists() for name in self.generated))
        self.assertEqual(self.run_batch().returncode, 0)

    def test_nested_junction_does_not_delete_external_contents(self):
        outside = self.root.parent / "outside"
        outside.mkdir()
        sentinel = outside / "keep.txt"
        sentinel.write_text("keep", encoding="utf-8")
        link = self.root / "output/Normal/linked"
        linked = subprocess.run(["cmd.exe", "/d", "/c", "mklink", "/J", str(link), str(outside)],
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(linked.returncode, 0, linked.stderr)
        result = self.run_batch()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(sentinel.read_text(), "keep")

    def test_wrong_project_is_rejected_without_deleting_data(self):
        (self.root / "src/git_poller.py").rename(self.root / "src/kept.py")
        result = self.run_batch()
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(all((self.root / name).is_file() for name in self.generated))
