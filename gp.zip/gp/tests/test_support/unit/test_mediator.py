import contextlib
import io
import sys
import tempfile
import unittest
from dataclasses import replace
from datetime import datetime, time
from pathlib import Path
from unittest.mock import Mock, patch
from uuid import uuid4


PROJECT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT / "src"))

import git_poller
from configuration import load_config
from runtime import close_logging, create_run_directory


class MediatorTest(unittest.TestCase):
    def setUp(self) -> None:
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.config = replace(
            load_config(PROJECT / "configs/default.yaml"),
            repository_path=self.root / "repository", output_path=self.root / "output",
            handlers=("first", "second"),
        )
        stack = contextlib.ExitStack()
        self.addCleanup(stack.close)
        stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
        self.git = stack.enter_context(patch("git_poller._git_text", side_effect=self.git_text))
        self.files = stack.enter_context(patch(
            "git_poller._changed_files", return_value=["src/a.c", "notes.txt", "include/a.h"],
        ))
        self.addCleanup(close_logging)

    @staticmethod
    def git_text(repository, *arguments):
        if arguments == ("rev-parse", "HEAD"):
            return "a" * 40
        if arguments == ("rev-parse", "@{upstream}"):
            return "b" * 40
        if "--verify" in arguments:
            return "c" * 40
        return ""

    def test_registered_handlers_run_in_order_and_share_one_change(self) -> None:
        events, received = [], []

        def first(config, change):
            events.append("first:start")
            received.append(change)
            self.assertEqual(self.git.call_args.args[1:], ("merge", "--ff-only", "b" * 40))
            events.append("first:end")

        def second(config, change):
            self.assertEqual(events, ["first:start", "first:end"])
            received.append(change)
            events.append("second")

        with patch.dict(git_poller.HANDLERS, {"first": first, "second": second}, clear=True):
            change = git_poller.poll_once(self.config)
        self.assertEqual(events, ["first:start", "first:end", "second"])
        self.assertIs(received[0], received[1])
        self.assertEqual([str(path) for path in change.files], ["src/a.c", "include/a.h"])
        self.assertEqual(change.directory, self.config.repository_output_path / "001_aaaaaaa_bbbbbbb")
        self.assertEqual(list(change.directory.iterdir()), [])
        self.assertFalse(list(self.config.output_path.rglob("*.lock")))
        self.assertFalse((self.config.output_path / "queue").exists())

    def test_failure_stops_later_handlers_without_completion_state(self) -> None:
        first, second = Mock(side_effect=RuntimeError("failed")), Mock()
        with patch.dict(git_poller.HANDLERS, {"first": first, "second": second}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "failed"):
                git_poller.poll_once(self.config)
        first.assert_called_once()
        second.assert_not_called()
        self.assertTrue((self.config.repository_output_path / "001_aaaaaaa_bbbbbbb").is_dir())
        self.assertFalse(list(self.config.output_path.rglob("*.lock")))
        with patch.dict(git_poller.HANDLERS, {"first": Mock(), "second": Mock()}, clear=True):
            change = git_poller.poll_once(self.config, "previous-commit")
        self.assertEqual(change.directory.name, "002_ccccccc_bbbbbbb")

    def test_no_matching_diff_calls_no_handlers(self) -> None:
        handler = Mock()
        with patch.dict(git_poller.HANDLERS, {"first": handler, "second": handler}, clear=True):
            for filenames in ([], ["notes.txt"]):
                self.files.return_value = filenames
                self.assertIsNone(git_poller.poll_once(self.config))
        handler.assert_not_called()
        self.assertFalse(self.config.output_path.exists())

    def test_unknown_handler_is_rejected_before_git_operations(self) -> None:
        with patch.dict(git_poller.HANDLERS, {}, clear=True):
            with self.assertRaises(KeyError):
                git_poller.poll_once(self.config)
        self.git.assert_not_called()

    def test_from_commit_explicitly_reprocesses_the_requested_diff(self) -> None:
        with patch.dict(git_poller.HANDLERS, {"first": Mock(), "second": Mock()}, clear=True):
            change = git_poller.poll_once(self.config, "previous-commit")
        self.assertEqual(change.before, "c" * 40)
        self.files.assert_called_once_with(self.config.repository_path, "c" * 40, "b" * 40)

    def test_run_numbers_continue_per_repository_without_overwriting(self) -> None:
        output = self.config.repository_output_path
        first = create_run_directory(output, "a" * 40, "b" * 40)
        (first / "keep.md").write_text("keep", encoding="utf-8")
        (output / "unrelated").mkdir()
        (output / "log.txt").touch()
        for number in (2, 3):
            directory = create_run_directory(output, "a" * 40, "b" * 40)
            self.assertEqual(directory.name, f"{number:03d}_aaaaaaa_bbbbbbb")
        self.assertEqual((first / "keep.md").read_text(), "keep")
        other = replace(self.config, repository_name="Another")
        self.assertEqual(
            create_run_directory(other.repository_output_path, "a" * 40, "b" * 40).name,
            "001_aaaaaaa_bbbbbbb",
        )

    def test_run_number_uses_maximum_and_can_exceed_three_digits(self) -> None:
        output = self.config.repository_output_path
        (output / "999_aaaaaaa_bbbbbbb").mkdir(parents=True)
        self.assertEqual(
            create_run_directory(output, "a" * 40, "b" * 40).name,
            "1000_aaaaaaa_bbbbbbb",
        )

    def test_polling_window_supports_day_night_and_all_day(self) -> None:
        at = lambda hour: datetime(2026, 9, 15, hour, tzinfo=git_poller.JST)
        self.assertTrue(git_poller.polling_is_active(self.config, at(7)))
        self.assertFalse(git_poller.polling_is_active(self.config, at(22)))
        night = replace(self.config, polling_start=time(22), polling_end=time(7))
        self.assertTrue(git_poller.polling_is_active(night, at(23)))
        self.assertFalse(git_poller.polling_is_active(night, at(12)))
        all_day = replace(self.config, polling_start=time(0), polling_end=time(0))
        self.assertTrue(git_poller.polling_is_active(all_day, at(12)))

    def test_main_catches_execution_errors(self) -> None:
        with (
            patch.object(sys, "argv", ["git_poller.py", "--config", "unused"]),
            patch("git_poller.load_config", return_value=replace(self.config, once=True)),
            patch("git_poller.poll_once", side_effect=RuntimeError("test failure")),
            contextlib.redirect_stderr(io.StringIO()) as errors,
        ):
            self.assertEqual(git_poller.main(), 1)
        self.assertIn("ERROR: test failure", errors.getvalue())
        self.assertIn(
            "test failure",
            (self.config.repository_output_path / "log.txt").read_text(encoding="utf-8"),
        )

    def test_yaml_controls_execution_and_session(self) -> None:
        session_id = uuid4()
        for once, from_commit in ((False, None), (True, None), (False, "previous-commit")):
            config = replace(
                self.config, once=once, from_commit=from_commit,
                copilot=replace(self.config.copilot, session_id=session_id),
            )
            with (
                self.subTest(once=once, from_commit=from_commit),
                patch.object(sys, "argv", ["git_poller.py", "--config", "unused"]),
                patch("git_poller.load_config", return_value=config),
                patch("git_poller.poll_once") as poll,
                patch("git_poller.run") as run,
            ):
                self.assertEqual(git_poller.main(), 0)
                if once or from_commit:
                    poll.assert_called_once_with(config, from_commit)
                    run.assert_not_called()
                else:
                    run.assert_called_once_with(config)
                    poll.assert_not_called()

    def test_startup_rejects_settings_before_loading_yaml(self) -> None:
        for arguments in (["--session-id", str(uuid4())], ["--once"], ["--from-commit", "previous"]):
            with (
                self.subTest(arguments=arguments),
                patch.object(sys, "argv", ["git_poller.py", "--config", "unused", *arguments]),
                patch("git_poller.load_config") as load,
                contextlib.redirect_stderr(io.StringIO()),
                self.assertRaises(SystemExit) as error,
            ):
                git_poller.main()
            self.assertEqual(error.exception.code, 2)
            load.assert_not_called()
