"""Run the existing BAT cases and preserve their evidence (real Copilot is billed)."""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

import security_test
import staged_test


PROJECT = staged_test.PROJECT_PATH
sys.path.insert(0, str(PROJECT / "src"))

from configuration import load_config
from copilot_review import _resolve_copilot_command
from git_poller import _changed_files


NORMAL_SEQUENCES = {
    "Normal": (
        ("TC_01_Normal_STEP_01_Reset", 1),
        ("TC_01_Normal_STEP_02_FirstReview", 2),
        ("TC_01_Normal_STEP_03_SecondReview", 3),
        ("TC_01_Normal_STEP_04_ThirdReview", 4),
    ),
    "NormalBatch": (
        ("TC_10_NormalBatch_STEP_01_Reset", 1),
        ("TC_10_NormalBatch_STEP_02_FirstReview", 2),
        ("TC_10_NormalBatch_STEP_03_BatchReview", 4),
    ),
}
NORMAL = {name: (scenario, state) for scenario, stages in NORMAL_SEQUENCES.items() for name, state in stages}
SECURITY = {
    name: case for case, (name, _) in security_test.CASES.items()
}


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def save_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def file_hashes(directory: Path, pattern: str = "*") -> dict[str, str]:
    return {
        path.relative_to(directory).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(directory.rglob(pattern)) if path.is_file()
    }


def report_hashes(scenario: str, output: Path | None = None) -> dict[str, str]:
    if output is None:
        output = load_config(staged_test.workspace(scenario) / "config.yaml").repository_output_path
    return {
        f"{run.name}/{name}": digest
        for run in output.glob("[0-9]*_*_*") if run.is_dir()
        for name, digest in file_hashes(run, "*.md").items()
    }


def normal_state(scenario: str = "Normal") -> dict:
    root = staged_test.workspace(scenario)
    if not (root / "repository/.git").is_dir():
        return {}
    state = {}
    for name in ("producer", "repository"):
        repository = root / name
        state[name] = {
            "files": security_test.snapshot_files(repository),
            "head": staged_test.git(repository, "rev-parse", "HEAD"),
            "commits": int(staged_test.git(repository, "rev-list", "--count", "HEAD")),
            "status": staged_test.git(repository, "status", "--porcelain"),
        }
    state["remote_head"] = staged_test.git(root / "remote.git", "rev-parse", "refs/heads/main")
    state["reports"] = report_hashes(scenario)
    return state


def normal_checks(step: int, before: dict, after: dict, scenario: str = "Normal") -> dict[str, bool]:
    fixtures = staged_test.FIXTURES / staged_test.SCENARIOS[scenario]
    expected = file_hashes(fixtures / f"state{step}")
    expected["AI_Instruction.md"] = hashlib.sha256((staged_test.FIXTURES / "AI_Instruction.md").read_bytes()).hexdigest()
    previous = before.get("reports", {})
    reports = after["reports"]
    added = set(reports) - set(previous)
    config = load_config(staged_test.workspace(scenario) / "config.yaml")
    expected_reports = set()
    correct_range = not added
    if step > 1:
        previous_state = before["producer"]["commits"]
        previous_files = file_hashes(fixtures / f"state{previous_state}")
        expected_reports = {
            name + ".md" for name, digest in expected.items()
            if previous_files.get(name) != digest
            and any(fnmatch.fnmatch(name, pattern) for pattern in config.target_patterns)
        }
        ranges = {name.split("/", 1)[0] for name in added}
        pattern = rf"[0-9]{{3,}}_{before['repository']['head'][:7]}_{after['remote_head'][:7]}"
        correct_range = len(ranges) == 1 and re.fullmatch(pattern, next(iter(ranges))) is not None
    return {
        "expected_repository_contents": all(after[name]["files"] == expected for name in ("producer", "repository")),
        "expected_commit_count": all(after[name]["commits"] == step for name in ("producer", "repository")),
        "heads_match_remote": all(after[name]["head"] == after["remote_head"] for name in ("producer", "repository")),
        "working_trees_clean": all(not after[name]["status"] for name in ("producer", "repository")),
        "only_expected_reports": {name.split("/", 1)[1] for name in added} == expected_reports,
        "expected_review_range": correct_range,
        "previous_reports_preserved": all(reports.get(name) == digest for name, digest in previous.items()),
        "continuous_5_second_polling": (
            not config.once and config.from_commit is None and config.polling_interval_seconds == 5
            and config.polling_start == config.polling_end
        ),
        "real_copilot_launcher": config.copilot.launcher == ("copilot",),
        "repository_instruction": config.copilot.instruction_file == config.repository_path / "AI_Instruction.md",
        "shared_review_session": config.copilot.session_id is not None,
    }


def wait_for_review(scenario: str, before: dict, process: subprocess.Popen) -> None:
    root = staged_test.workspace(scenario)
    config = load_config(root / "config.yaml")
    previous = before["repository"]["head"]
    current = staged_test.git(root / "producer", "rev-parse", "HEAD")
    changed = _changed_files(root / "producer", previous, current)
    targets = {name + ".md" for name in changed if any(fnmatch.fnmatch(name, pattern) for pattern in config.target_patterns)}
    deadline = time.monotonic() + config.polling_interval_seconds + len(targets) * config.copilot.timeout_seconds + 60
    while True:
        if process.poll() is not None:
            raise RuntimeError(f"Continuous poller exited early ({process.returncode}).")
        runs = list(config.repository_output_path.glob(f"[0-9]*_{previous[:7]}_{current[:7]}"))
        log = config.repository_output_path / "log.txt"
        text = log.read_text(encoding="utf-8") if log.is_file() else ""
        marker = f"Change {previous} -> {current} "
        finished = marker in text and all(
            f"Finished handler: {handler}" in text.rsplit(marker, 1)[1] for handler in config.handlers
        )
        if finished and len(runs) == 1 and all((runs[0] / name).is_file() for name in targets):
            return
        if time.monotonic() >= deadline:
            raise TimeoutError(f"Timed out waiting for state {previous[:7]} -> {current[:7]}.")
        time.sleep(0.2)


def capture_sources(directory: Path) -> None:
    paths = [PROJECT / name for name in ("README.md", "requirements.txt", "start.bat")]
    for name in ("src", "configs", "tests", "tools"):
        paths.extend(
            path for path in (PROJECT / name).rglob("*")
            if path.is_file()
            and "__pycache__" not in path.relative_to(PROJECT).parts
            and "workspace" not in path.relative_to(PROJECT).parts
        )
    for source in paths:
        destination = directory / source.relative_to(PROJECT)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def run_case(name: str, evidence: Path, poller: subprocess.Popen | None = None) -> dict:
    directory = evidence / name
    directory.mkdir()
    command = ["cmd.exe", "/d", "/c", str(PROJECT / "tests" / f"{name}.bat")]
    result = {"case": name, "started_at": now(), "command": command, "status": "ERROR"}
    before = {}
    if name in NORMAL:
        scenario, state = NORMAL[name]
        # Reset must also work when the preceding run used an older YAML format.
        before = ({"reports": report_hashes(scenario, PROJECT / "output" / scenario)}
                  if state == 1 else normal_state(scenario))
        save_json(directory / "before.json", before)
    print(f"{now()} START {name}", flush=True)
    try:
        with (directory / "stdout.log").open("wb") as stdout, (directory / "stderr.log").open("wb") as stderr:
            process = subprocess.run(command, cwd=PROJECT, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, timeout=1500)
        result["exit_code"] = process.returncode
        if name in NORMAL:
            scenario, state = NORMAL[name]
            if state > 1 and process.returncode == 0:
                if poller is None:
                    raise RuntimeError("A continuous poller is required for the normal evidence sequence.")
                wait_for_review(scenario, before, poller)
            after = normal_state(scenario)
            save_json(directory / "after.json", after)
            result["checks"] = normal_checks(state, before, after, scenario)
        if name in SECURITY:
            roots = list((staged_test.workspace() / "Security" / SECURITY[name]).iterdir())
            if len(roots) != 1:
                raise RuntimeError("Expected one fresh security test directory.")
            shutil.copytree(roots[0], directory / "test-data", symlinks=True)
            result["test_directory"] = str(roots[0])
            result["checks"] = {
                "pass_record_exists": (roots[0] / "result.txt").is_file(),
                "before_after_states_match": (roots[0] / "before.json").read_bytes() == (roots[0] / "after.json").read_bytes(),
            }
        if process.returncode == 0:
            result["status"] = "OK" if all(result.get("checks", {}).values()) else "FAIL"
    except Exception as error:
        result["error"] = str(error)
    result["finished_at"] = now()
    save_json(directory / "result.json", result)
    print(f"{now()} {result['status']} {name}", flush=True)
    return result


def run_normal_sequence(scenario: str, evidence: Path) -> list[dict]:
    stages = NORMAL_SEQUENCES[scenario]
    results = [run_case(stages[0][0], evidence)]
    if results[0]["status"] != "OK":
        return results
    name = stages[0][0].removesuffix("_STEP_01_Reset") + "_StartPoller"
    directory = evidence / name
    directory.mkdir()
    # Invoke the same entry point as StartPoller.bat directly to own the long-lived
    # Python process; there is no extra cmd.exe parent to leave running on stop.
    command = [sys.executable, str(PROJECT / "tests/test_support/staged_test.py"), "start", "--scenario", scenario]
    record = {"case": name, "started_at": now(), "command": command, "status": "ERROR"}
    results.append(record)
    print(f"{now()} START {name}", flush=True)
    with (directory / "stdout.log").open("wb") as stdout, (directory / "stderr.log").open("wb") as stderr:
        started = time.time()
        process = subprocess.Popen(command, cwd=PROJECT, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
        try:
            # Starting the process precedes every push, including the first one.
            output = load_config(staged_test.workspace(scenario) / "config.yaml").repository_output_path
            deadline = time.monotonic() + 30
            while not any(
                path.stat().st_mtime >= started
                for path in output.glob("test-settings/*_continuous/config.yaml")
            ):
                if process.poll() is not None or time.monotonic() >= deadline:
                    raise RuntimeError("Continuous poller did not start; see its logs.")
                time.sleep(0.1)
            record["pid"] = process.pid
            for case, _ in stages[1:]:
                result = run_case(case, evidence, process)
                results.append(result)
                if result["status"] != "OK":
                    break
            record["status"] = "OK" if process.poll() is None and all(item["status"] == "OK" for item in results[2:]) else "FAIL"
        except Exception as error:
            record["error"] = str(error)
        finally:
            record["stopped_by_collector"] = process.poll() is None
            if process.poll() is None:
                # Stop only the process started above. On failure a CLI child may
                # still be running, so terminate that owned process tree as well.
                subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True, timeout=30)
            process.wait(timeout=30)
            record["exit_code"] = process.returncode
    record["finished_at"] = now()
    save_json(directory / "result.json", record)
    print(f"{now()} {record['status']} {name} (stopped after sequence)", flush=True)
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path, help="New evidence directory; must not exist")
    parser.add_argument("--normal-only", action="store_true", help="Collect only the two continuous normal sequences")
    arguments = parser.parse_args()
    evidence = arguments.directory.resolve()
    if (PROJECT / "output").exists() and any((PROJECT / "output").iterdir()):
        raise RuntimeError("output must be empty before collecting a fresh evidence set.")
    evidence.mkdir(parents=True, exist_ok=False)
    capture_sources(evidence / "source")
    settings = load_config(PROJECT / "configs/default.yaml").copilot
    version_command = [*_resolve_copilot_command(settings.launcher), "--no-auto-update", "--version"]
    save_json(evidence / "environment.json", {
        "collected_at": now(), "python": sys.version, "platform": sys.platform,
        "git": subprocess.check_output(["git", "--version"], text=True).strip(),
        "copilot": subprocess.check_output(version_command, text=True, timeout=60).strip(),
        "copilot_version_command": version_command, "normal_only": arguments.normal_only,
        "max_ai_credits_per_call": settings.max_ai_credits, "timeout_seconds": settings.timeout_seconds,
    })
    results = [] if arguments.normal_only else [run_case("UnitTests", evidence)]
    if not results or results[0]["status"] == "OK":
        for scenario in NORMAL_SEQUENCES:
            results.extend(run_normal_sequence(scenario, evidence))
            save_json(evidence / "summary.json", results)
        if not arguments.normal_only:
            reset_ok = next(result for result in results if result["case"] == "TC_01_Normal_STEP_01_Reset")["status"] == "OK"
            for name in SECURITY:
                results.append(run_case(name, evidence) if reset_ok else {
                    "case": name, "status": "SKIPPED", "reason": "Reset failed",
                })
                save_json(evidence / "summary.json", results)
    else:
        save_json(evidence / "summary.json", results)
    if (PROJECT / "output").is_dir():
        shutil.copytree(PROJECT / "output", evidence / "output", symlinks=True)
    for scenario in NORMAL_SEQUENCES:
        root = staged_test.workspace(scenario)
        if root.is_dir():
            shutil.copytree(root, evidence / "workspaces" / scenario, symlinks=True)
    expected_count = sum(len(stages) + 1 for stages in NORMAL_SEQUENCES.values())
    if not arguments.normal_only:
        expected_count += 1 + len(SECURITY)
    return 0 if len(results) == expected_count and all(result["status"] == "OK" for result in results) else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
