"""A loopback-only HTTP receiver for the network permission test."""
from contextlib import contextmanager
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread


@dataclass
class NetworkProbe:
    url: str
    requests: list[str]


@contextmanager
def network_probe(port: int = 0):
    requests = []

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"GitPoller disposable network test\n")

        do_POST = do_GET

        def log_request(self, code="-", size="-"):
            # Also records unsupported methods, not just successful GET requests.
            requests.append(f"{self.command} {self.path} {code}")

        def log_message(self, format, *args):
            pass

    with ThreadingHTTPServer(("127.0.0.1", port), Handler) as server:
        thread = Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            yield NetworkProbe(f"http://127.0.0.1:{server.server_port}/probe", requests)
        finally:
            server.shutdown()
            thread.join()
