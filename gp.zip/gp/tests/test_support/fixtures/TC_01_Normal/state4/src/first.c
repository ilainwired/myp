#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* Device telemetry helpers.
 * Writable buffers and input arrays have the stated capacities.
 * Source strings are NUL-terminated and do not overlap destination buffers.
 */

/* Return 0 on success, -1 when the device name cannot be copied safely. */
int copy_device_name(char *destination, size_t capacity, const char *name)
{
    if (destination == NULL || name == NULL || capacity == 0) {
        return -1;
    }
    size_t length = strlen(name);
    if (length >= capacity) {
        return -1;
    }
    memcpy(destination, name, length + 1);
    return 0;
}

/* Return the average count per sample, or zero when there are no samples. */
uint32_t average_count(uint32_t total, uint32_t sample_count)
{
    return total / sample_count;
}

/* Read one sample. Return -1 for an invalid pointer or an out-of-range index. */
int read_sample(const uint32_t *values, size_t count, size_t index, uint32_t *sample)
{
    if (values == NULL || sample == NULL || index > count) {
        return -1;
    }
    *sample = values[index];
    return 0;
}
