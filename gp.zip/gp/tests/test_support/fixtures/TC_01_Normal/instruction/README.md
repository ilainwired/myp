# 指示ファイルの読込みと未配置の確認

追加指示は[present/rules/AI_Instruction.md](present/rules/AI_Instruction.md)、期待する確認文字列は[expected.txt](expected.txt)です。各ケースの開始時にTC_01をResetします。これにより、前回の確認文字列が会話に残りません。

## 指定位置にある場合

1. `tests\TC_01_Normal_STEP_01_Reset.bat --instruction present`を実行します。固定ファイルを初期commitへ含め、YAMLの指定位置も設定します。
2. TC_01のStartPollerを起動し、別端末でFirstReviewを実行します。
3. ログのInstruction loaded:がrules/AI_Instruction.mdを指し、回答末尾にexpected.txtの文字列があることを確認します。
4. PollerをCtrl+Cで停止します。

## 指定位置にない場合

1. `tests\TC_01_Normal_STEP_01_Reset.bat --instruction missing`を実行します。YAMLは同じ`rules/AI_Instruction.md`を指定し、固定の[TC_01の状態1](../state1)にはそのファイルがない状態を用意します。
2. TC_01のStartPollerを起動し、別端末でFirstReviewを実行します。
3. レビューが成功し、当該パスのInstruction loaded:が記録されないこと、回答に確認文字列がないことを確認します。
4. PollerをCtrl+Cで停止します。

expected.txtは対象リポジトリへコピーしません。起動時の設定スナップショットと回答を保存します。[通常テストの操作](../../../../../docs/TestPlan.md)
