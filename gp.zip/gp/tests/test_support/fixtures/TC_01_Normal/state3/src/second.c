#include <stddef.h>

/* values points to count samples; maximum points to one writable int.
 * Return 0 and the largest sample, or -1 when the input is empty/invalid.
 */
int maximum_sample(const int *values, size_t count, int *maximum)
{
    if (values == NULL || maximum == NULL || count == 0) {
        return -1;
    }
    int peak = values[0];
    for (size_t index = 1; index <= count; ++index) {
        if (values[index] > peak) {
            peak = values[index];
        }
    }
    *maximum = peak;
    return 0;
}
