# テストデータ一覧

TCごとに、BATと同じ番号・名前のフォルダを用意しています。各BATは対応する固定ファイルをコピーして、Git操作やCopilotの起動を行います。

| TC・BATの名前 | 対応するデータフォルダ |
|---|---|
| TC_01_Normal | [TC_01_Normal](TC_01_Normal/README.md) |
| TC_02_Security_DeleteFile | [TC_02_Security_DeleteFile](TC_02_Security_DeleteFile) |
| TC_03_Security_GitPush | [TC_03_Security_GitPush](TC_03_Security_GitPush) |
| TC_04_Security_WriteFile | [TC_04_Security_WriteFile](TC_04_Security_WriteFile) |
| TC_05_Security_GitConfig | [TC_05_Security_GitConfig](TC_05_Security_GitConfig) |
| TC_06_Security_ShellCommand | [TC_06_Security_ShellCommand](TC_06_Security_ShellCommand) |
| TC_07_Security_SecretLeak | [TC_07_Security_SecretLeak](TC_07_Security_SecretLeak) |
| TC_08_Security_NetworkAccess | [TC_08_Security_NetworkAccess](TC_08_Security_NetworkAccess) |
| TC_09_Security_RepoHooks | [TC_09_Security_RepoHooks](TC_09_Security_RepoHooks) |
| TC_10_NormalBatch | [TC_10_NormalBatch](TC_10_NormalBatch/README.md) |

TC_01とTC_10には、それぞれ状態1〜4を配置しています。各BATは同じTC名のフォルダから読み込みます。操作制限8ケースの期待値は[SecurityTestNotes.md](SecurityTestNotes.md)にまとめています。

共通の指示書は[AI_Instruction.md](AI_Instruction.md)です。操作制限ケースの初期状態はTC_01の状態1を共用します。

補助確認は対応するTC内に置いています。[指示ファイルの配置確認](TC_01_Normal/instruction/README.md)はTC_01、[事前の会話の引継ぎ](TC_10_NormalBatch/session/README.md)はTC_10です。PollOnceの補助BATも各TCの同じデータを使います。

Cコード、誘導文、ダミー秘密、補助スクリプト、フック設定は固定ファイルです。Gitのcommitとハッシュ、セッションID、作業フォルダ名、使用環境に合わせたYAML、ログ・回答・判定結果は実行時に作ります。単体テストの短いJSON・設定値・境界値はコード内に記載します。

操作は[テスト手順](../../../docs/TestPlan.md)、実績は[テスト結果](../../../docs/TestResultReport.md)を参照してください。清掃BATはこのfixturesフォルダを残します。
