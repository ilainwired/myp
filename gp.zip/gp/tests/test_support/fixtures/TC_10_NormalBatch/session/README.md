# 事前の会話を引き継ぐ確認

入力する文章は[preparation.txt](preparation.txt)、期待する確認文字列は[expected.txt](expected.txt)です。レビュー対象には通常テストの状態1〜4を使います。

1. TC_10をResetし、作られたconfig.yamlのcopilot.session_idを確認します。
2. `copilot --session-id <そのUUID>`で普段のCopilotを起動します。
3. preparation.txtの全文を会話へ貼り付け、回答を受けてから対話CLIを終了します。
4. TC_10のStartPoller、FirstReview、BatchReviewを手順どおり実行します。
5. first.cの2回答とsecond.cの1回答、計3回答の末尾にexpected.txtの文字列があることを確認します。

preparation.txtやexpected.txtは対象リポジトリへコピーしません。確認文字列はレビュー用の指示書や対象Cコードにも追記しません。事前の会話を経由して引き継がれたことを確認します。

事前の会話とPollerは同じWindowsユーザー・同じ環境で実行します。既存の方針を試す場合も、同じUUIDを指定します。[実行手順](../../../../../docs/TestPlan.md#セッションの会話を引き継ぐ確認)
