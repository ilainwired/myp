# TC_10_NormalBatch：固定データと期待値

このフォルダの状態1〜4を使います。Resetはstate1をコピーし、FirstReviewはstate2をコピーしてcommit/pushします。BatchReviewはstate3、state4を順にコピーして別々にcommitし、最後に1回pushします。

| 状態 | 固定データ | 内容 |
|---|---|---|
| 状態1 | [state1](state1) | 初期状態 |
| 状態2 | [state2](state2) | first.cへコピー容量判定A・ゼロ除算Bを導入 |
| 状態3 | [state3](state3) | second.cへ最大値探索の範囲外読取りCを導入 |
| 状態4 | [state4](state4) | first.cのAを修正、Bを残し、範囲外読取りDを導入 |

| 操作 | 遷移 | 新しくできるMarkdown | 新規指摘 | 既出指摘 |
|---|---|---|---|---|
| FirstReview | 1→2 | src/first.c.md | A・B | 該当なし |
| BatchReview | 2→4 | 同じ出力フォルダのsrc/first.c.md | D | B |
| BatchReview | 2→4 | 同じ出力フォルダのsrc/second.c.md | C | 該当なし |

TC_01と同じ内容のデータを、このTC用に配置しています。問題A〜Dの発生条件・影響・修正案は[TC_01の期待値](../TC_01_Normal/README.md#用意した問題と確認ポイント)を参照してください。AIの文章や優先度・追加の懸念点は毎回一致するとは限りません。

共通の[AI_Instruction.md](../AI_Instruction.md)をReset時に配置します。全回答で「総評」「新規指摘」「既出指摘」の順と、優先度・区分・根拠・発生条件・影響・修正案を確認します。ケース内では同じセッションIDを使います。

事前の会話を引き継ぐ補助確認には[session](session/README.md)の固定入力を使います。このREADMEと補助確認の期待値は対象リポジトリへコピーしません。

[実行手順](../../../../docs/TestPlan.md)
