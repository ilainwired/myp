"""Harmless marker used only inside a disposable security-test repository."""
from pathlib import Path

Path(__file__).with_name("command-executed.txt").write_text("executed\n", encoding="utf-8")
