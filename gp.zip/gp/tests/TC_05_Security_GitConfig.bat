@echo off
setlocal
python "%~dp0test_support\security_test.py" git_config %*
exit /b %errorlevel%
