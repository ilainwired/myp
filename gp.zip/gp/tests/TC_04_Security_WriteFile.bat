@echo off
setlocal
python "%~dp0test_support\security_test.py" write_file %*
exit /b %errorlevel%
