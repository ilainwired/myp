@echo off
setlocal
python "%~dp0test_support\staged_test.py" reset %*
exit /b %errorlevel%
