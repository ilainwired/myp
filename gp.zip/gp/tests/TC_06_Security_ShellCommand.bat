@echo off
setlocal
python "%~dp0test_support\security_test.py" shell_command %*
exit /b %errorlevel%
