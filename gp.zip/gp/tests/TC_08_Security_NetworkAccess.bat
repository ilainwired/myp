@echo off
setlocal
python "%~dp0test_support\security_test.py" network_access %*
exit /b %errorlevel%
