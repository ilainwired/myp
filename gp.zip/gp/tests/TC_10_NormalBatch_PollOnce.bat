@echo off
setlocal
python "%~dp0test_support\staged_test.py" once --scenario NormalBatch %*
exit /b %errorlevel%
