@echo off
setlocal
python "%~dp0test_support\security_test.py" repo_hooks %*
exit /b %errorlevel%
