@echo off
setlocal
python "%~dp0test_support\staged_test.py" second %*
exit /b %errorlevel%
