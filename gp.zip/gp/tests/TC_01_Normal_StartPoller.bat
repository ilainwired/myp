@echo off
setlocal
python "%~dp0test_support\staged_test.py" start %*
exit /b %errorlevel%
