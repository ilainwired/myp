# 設定ガイド

[default.yaml](default.yaml) を編集し、`start.bat configs\default.yaml`で起動します。起動引数は使用するYAMLの選択だけです。

## パスの基準

`repository.path`と`output`の相対パスはYAMLのあるフォルダを基準にします。`copilot.instruction_file`は対象リポジトリを基準にします。`launcher`の実行ファイルはPATHから検索するか、絶対パスで指定します。

## 設定項目

| 項目 | 内容・既定値 |
|---|---|
| `repository.name` | 出力フォルダ名。区切り文字を含まない名前 |
| `repository.path` | 監視するGit作業リポジトリ |
| `repository.target_patterns` | 対象ファイルのパターン。例：`["*.c", "*.h"]` |
| `output` | 結果の出力ルート。リポジトリ名ごとに保存 |
| `handlers` | 呼び出す処理の順序。通常は`[copilot_review]` |
| `execution.once` | 1回だけ実行する場合はtrue。通常はfalse |
| `execution.from_commit` | 指定commitからの差分を1回再処理。通常はnull。ハッシュは引用符で囲む |
| `polling.interval_seconds` | 各回の処理完了後の待ち時間。5秒 |
| `polling.start / end` | JSTの稼働時間帯。`"07:00" / "22:00"`。同じ時刻なら終日 |
| `copilot.launcher` | 起動プログラムの配列。`[copilot]` |
| `copilot.instruction_file` | 追加指示の相対パス。`Instruction.md`。存在すれば読込み、なければ続行。nullで無効化 |
| `copilot.session_id` | 再開する会話のUUID。nullなら呼出しごとに新規 |
| `copilot.max_ai_credits` | CLIのクレジット上限。100 |
| `copilot.timeout_seconds` | CLIの実行制限時間。600秒 |

クレジット上限はCLIのソフト上限であり、処理中の応答完了までに超過する場合があります。設定可能な最小値は30です。[GitHubの上限仕様](https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/set-session-limit)

## セッションの準備と再開

1. 普段のCopilotをUUID指定で起動し、レビュー方針や必要な知識を会話で伝えます。
2. 対話CLIを終了します。
3. 同じUUIDをYAMLに設定し、GitPollerを起動します。

```bat
copilot --session-id 0cb916db-26aa-40f2-86b5-1ba81b225fd2
```

```yaml
copilot:
  session_id: "0cb916db-26aa-40f2-86b5-1ba81b225fd2"
```

UUIDがCopilotに存在すれば会話を再開し、存在しなければそのIDで新規作成します。[CLIのセッション指定](https://docs.github.com/en/copilot/reference/copilot-cli-reference/cli-command-reference)

事前に伝えた内容は会話の文脈として引き継がれます。同じIDを使う間は、ファイル間・Pollerの再起動後も会話が続きます。レビュー対象の作業場所にはYAMLのリポジトリを`-C`で指定します。

履歴はCopilotが管理します。保存先や認証に関する追加設定は不要です。事前の会話とGitPollerで同じWindowsユーザー・同じ環境を使い、同じIDの並行実行は避けてください。

`session_id: null`でも、Copilotが作る新規会話の履歴は通常の保存先に残ります。GitPollerは履歴のコピー・移動・削除を行いません。履歴を消した場合、同じIDを指定しても消した会話は引き継げません。

## 指示文

Pythonが次の基本指示を作り、追加指示ファイルがあれば本文を後ろに加えます。

```text
<対象ファイルの相対パス>
当該ファイルのみをレビューしてください。
結果はMarkdownで出力してください。
```

例えば`instruction_file: rules/Instruction.md`なら、対象リポジトリの`rules/Instruction.md`をレビューごとに読み直します。読み込んだパスはログの`Instruction loaded:`で確認できます。ファイルが存在しなくても基本指示で続行します。

追加指示やセッションの会話が基本指示に影響する可能性は許容します。「当該ファイルのみ」はプロンプト上の指示です。本文のテンプレート展開は行わず、改行を含む全体を1つの引数として渡します。

## 起動プログラムとオプション

通常は`launcher: [copilot]`で使用します。空白を含むパスも配列の1要素にします。

```yaml
launcher: ["C:/Program Files/Copilot/copilot.exe"]
# Node版の例
# launcher: ["C:/Program Files/nodejs/node.exe", "C:/tools/copilot/npm-loader.js"]
```

npm版の`copilot.cmd`は、複数行プロンプトを保持するためNodeから直接起動します。独自のBAT/CMDラッパーには対応しません。

Copilotのオプションは [copilot_review.py](../src/copilot_review.py) の`build_command()`で管理します。読み取り用の`view・glob・grep`を公開し、シェル・書き込み・URLアクセスを拒否します。組み込みMCP、自動指示読込み、対話質問、自動更新、リモート機能を無効にします。モデル・reasoning levelは指定しません。

ユーザーの認証・設定・履歴は普段のCopilot保存先を使います。設定ファイルをGitPollerが書き換えることはありません。[権限と運用上の制約](../docs/GithubCopilotReview_SecurityAnalysis.md)

## Copilot CSV

`output/<リポジトリ名>/copilot.csv`へCLI呼出し1回につき1行追記します。2ファイルのレビューなら2行です。UTF-8 BOM付きで、ヘッダーは1回だけ書き込みます。

| 列 | 内容 |
|---|---|
| `started_at / finished_at` | 呼出し開始から回答保存までの日時。ISO 8601、JST |
| `target_file` | 対象ファイルのリポジトリ内相対パス |
| `ai_credits` | 今回の使用クレジット。取得・比較不能なら空欄 |
| `session_ai_credits` | CLIが報告したセッション累積クレジット |
| `credit_source` | 使用量の取得元。`usage.json:totalNanoAiu` |
| `status` | `success`または`error`。タイムアウト・中断・回答保存失敗もerror |
| `result_file` | 結果Markdownの保存先。失敗時は存在しない場合がある |
| `command` | プロンプトを含む実行引数のJSON配列 |
| `backend` | 実行元。`copilot` |
| `session_id / resumed` | 使用したIDと、開始時に履歴が存在していたか |

回答はCLIのJSON出力から取得します。再開時のクレジット計算に限り、Copilotが保存した累積使用量を読み、実行後の値との差を今回分として記録します。開始時の使用量が確定していない場合は、今回分を空欄にします。

使用統計の`totalNanoAiu`は10億単位を1クレジットへ換算します。統計が取れない場合は空欄にします。残量・金額の推定は行いません。

使用量を取得できない場合も日時・対象・コマンド・成否は記録します。削除ファイルのスキップやCLI起動前の設定エラーは呼出しに含めません。Excelで数式になる先頭文字のテキストには`'`を付け、元の引数はcommand列に保持します。
