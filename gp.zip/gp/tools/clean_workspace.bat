@echo off
setlocal
REM Stop GitPoller before running. Sources, configuration and reports are kept.
for %%I in ("%~dp0..") do set "PROJECT_ROOT=%%~fI"
if not exist "%PROJECT_ROOT%\src\git_poller.py" goto wrong_project
if not exist "%PROJECT_ROOT%\configs\default.yaml" goto wrong_project
cd /d "%PROJECT_ROOT%" || exit /b 1

REM Fixed targets below the verified project root. No repository is deleted.
if exist "output" rd /s /q "output"
if exist "tests\test_support\workspace" rd /s /q "tests\test_support\workspace"
if exist "docs\evidence" rd /s /q "docs\evidence"
if exist "__pycache__" rd /s /q "__pycache__"
if exist "src\__pycache__" rd /s /q "src\__pycache__"
if exist "tests\__pycache__" rd /s /q "tests\__pycache__"
if exist "tests\test_support\__pycache__" rd /s /q "tests\test_support\__pycache__"
if exist "tests\test_support\unit\__pycache__" rd /s /q "tests\test_support\unit\__pycache__"
if exist "tools\__pycache__" rd /s /q "tools\__pycache__"
if exist ".pytest_cache" rd /s /q ".pytest_cache"
if exist ".mypy_cache" rd /s /q ".mypy_cache"
if exist ".ruff_cache" rd /s /q ".ruff_cache"
for %%D in (. src tests tests\test_support tests\test_support\unit tools) do (
    if exist "%%D\*.pyc" del /q "%%D\*.pyc"
    if exist "%%D\*.pyo" del /q "%%D\*.pyo"
)

set "FAILED=0"
for %%D in (output tests\test_support\workspace docs\evidence __pycache__ src\__pycache__ tests\__pycache__ tests\test_support\__pycache__ tests\test_support\unit\__pycache__ tools\__pycache__ .pytest_cache .mypy_cache .ruff_cache) do if exist "%%D" (
    echo Could not delete: %PROJECT_ROOT%\%%D
    set "FAILED=1"
)
exit /b %FAILED%

:wrong_project
echo GitPoller project root was not found. Nothing was deleted. 1>&2
exit /b 1
