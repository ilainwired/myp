@echo off
setlocal
if not "%~2"=="" (
    echo ERROR: Specify only a YAML path. Put all settings in YAML. 1>&2
    exit /b 2
)
set "CONFIG_PATH=%~1"
if not defined CONFIG_PATH set "CONFIG_PATH=%~dp0configs\default.yaml"
python "%~dp0src\git_poller.py" --config "%CONFIG_PATH%"
exit /b %errorlevel%
