# GitPoller

Gitリポジトリを定期的に更新し、変更されたファイルをCopilot CLIでレビューするWindows向けツールです。結果はMarkdown、使用クレジットはCSVへ保存します。

## はじめに

Python 3.10以降、Git、ログイン済みのCopilot CLIを用意します。監視するリポジトリはclone済みで、追跡先ブランチが設定され、未コミットの変更がない状態にしてください。

```bat
python -m pip install -r requirements.txt
start.bat configs\default.yaml
```

起動前に [configs/default.yaml](configs/default.yaml) の`repository.path`と`repository.name`を対象に合わせて変更します。引数を省略すると、このYAMLを使います。停止はCtrl+Cです。

通常はJSTの07:00～22:00に継続監視し、各回の処理完了後に5秒待ちます。開始・終了時刻を同じにすると終日監視します。同じ作業リポジトリで複数のPollerを起動しないでください。

## レビュー対象と指示

前回と今回のコミット2点間の`git diff --name-only`で対象を抽出します。複数コミットのpushでも、2点間で差が残る対象ファイルをレビューします。途中で変更して元に戻したファイルは対象外です。

対象パターンは既定で`*.c`と`*.h`です。取り込み後の最新版を各ファイル1回レビューし、最終状態で削除されたファイルはスキップします。差分本文をAIへ渡す方式ではありません。

基本指示はGitPoller内にあります。

```text
<対象ファイルの相対パス>
当該ファイルのみをレビューしてください。
結果はMarkdownで出力してください。
```

`copilot.instruction_file`で指定したファイルが対象リポジトリにあれば、本文を後ろに追加します。既定はリポジトリ直下の`Instruction.md`です。なくてもレビューを続けます。例えば`review/Instruction.md`なら対象リポジトリの`review`フォルダから読みます。追加指示によって基本指示が上書きされる可能性は許容します。

## 同じセッションで会話を引き継ぐ

Copilotで事前にレビュー方針や知識を伝え、そのセッションのUUIDをYAMLに指定します。

```yaml
copilot:
  session_id: "0cb916db-26aa-40f2-86b5-1ba81b225fd2"
```

同じIDでは、事前の会話とGitPollerによるレビューが続きます。`null`ならレビューごとに新しいIDを使います。新規・再開とも履歴はCopilotが管理し、GitPollerはコピー・移動・削除しません。

認証と会話の保存先は普段のCopilot環境を使います。保存先の追加設定は不要です。事前の会話とGitPollerは同じWindowsユーザー・同じ環境で実行してください。同じセッションを対話CLIとPollerで同時に使わないでください。具体的な準備手順は [設定ガイド](configs/README.md#セッションの準備と再開) にあります。

## 出力を確認する

```text
output/<リポジトリ名>/log.txt
output/<リポジトリ名>/copilot.csv
output/<リポジトリ名>/001_<変更前Hash7文字>_<変更後Hash7文字>/src/file.c.md
```

出力フォルダの連番はリポジトリごとに続きます。レビュー結果は元の相対パス＋`.md`で保存します。

| 出力 | 内容 |
|---|---|
| Markdown | Copilotの今回の回答 |
| log.txt | 処理状況、前後のcommit、実行コマンド、使用量、結果パス。回答本文は含めない |
| copilot.csv | 呼出しごとの日時、対象ファイル、使用クレジット、成否、結果パス、コマンド、セッションID |

クレジットの一覧はPowerShellで確認できます。

```powershell
Import-Csv .\output\*\copilot.csv |
  Select-Object finished_at, target_file, ai_credits, session_ai_credits, status |
  Format-Table -AutoSize
```

`ai_credits`は今回分、`session_ai_credits`はセッション累積です。取得できない値は空欄で、0とは区別します。金額・残量は推定しません。CSVはExcelで開けるUTF-8 BOM付きです。[列の説明](configs/README.md#copilot-csv)

## エラー時

処理エラーは全体ログへ記録し、Pollerを停止します。自動再試行はしません。レビュー失敗時もGitの更新は完了していることがあります。

必要な場合はログの`Change <変更前> -> <変更後>`を確認し、YAMLの`execution.from_commit`に変更前のcommitを指定して再実行します。指定範囲を1回処理したら終了します。再処理も課金対象です。継続監視へ戻す前に`from_commit: null`へ戻してください。

## テスト

通常試験は、先にPollerを起動し、別の端末でcommit/pushします。各出力を確認してから次へ進めます。

[状態1〜4の固定データと期待値](tests/test_support/fixtures/TC_01_Normal/README.md)を用意しています。各BATは状態フォルダをコピーしてcommit/pushします。共通の`AI_Instruction.md`で「総評」「新規指摘」「既出指摘」を指示し、同じテスト内ではセッションを共有します。

操作制限の8ケースと、会話の引継ぎ・指示ファイルの配置確認にも固定データを用意しています。[全テストデータの一覧](tests/test_support/fixtures/README.md)から入力と期待値を確認できます。

```bat
REM 端末A：初期化し、5秒間隔で監視
tests\TC_01_Normal_STEP_01_Reset.bat
tests\TC_01_Normal_StartPoller.bat
```

```bat
REM 端末B：1本ずつ実行し、その都度outputを確認
tests\TC_01_Normal_STEP_02_FirstReview.bat
tests\TC_01_Normal_STEP_03_SecondReview.bat
tests\TC_01_Normal_STEP_04_ThirdReview.bat
```

複数コミットをまとめるTC_10、設定の保存先、セキュリティ試験は [テスト手順](docs/TestPlan.md) に記載しています。[検証結果](docs/TestResultReport.md) も参照してください。`tests\UnitTests.bat`は外部Copilot呼出しをモックする自動テストです。

## 配布前の清掃

Pollerを停止し、必要な結果を退避してから実行します。

```bat
tools\clean_workspace.bat
```

`output`、`tests/test_support/workspace`、`docs/evidence`、Pythonキャッシュを削除します。ソース、設定、テスト資材、文書は残します。通常のCopilot保存先は対象外です。削除できないディレクトリは画面に表示します。ZIPは作成しません。

## 詳細

- [設定ガイド](configs/README.md)
- [実装構成](docs/CodeReview.md)
- [権限と運用上の制約](docs/GithubCopilotReview_SecurityAnalysis.md)
