from __future__ import annotations

import argparse
import fnmatch
import logging
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath

import copilot_review
from configuration import Change, Config, load_config
from runtime import close_logging, configure_logging, create_run_directory


LOGGER = logging.getLogger("GitPoller")
JST = timezone(timedelta(hours=9), "JST")

# Register a function here, then list its name in YAML's handlers.
# Each function receives (config, change) and must finish before returning.
HANDLERS = {"copilot_review": copilot_review.review}


def poll_once(config: Config, from_commit: str | None = None) -> Change | None:
    handlers = [(name, HANDLERS[name]) for name in config.handlers]
    repository = config.repository_path
    if _git_text(repository, "status", "--porcelain"):
        raise RuntimeError(f"Uncommitted changes found: {repository}")
    current = _git_text(repository, "rev-parse", "HEAD")
    before = (
        _git_text(repository, "rev-parse", "--verify", "--end-of-options", f"{from_commit}^{{commit}}")
        if from_commit else current
    )
    _git_text(repository, "fetch", "--prune")
    after = _git_text(repository, "rev-parse", "@{upstream}")
    filenames = _changed_files(repository, before, after)
    if current != after:
        _git_text(repository, "merge", "--ff-only", after)

    targets = tuple(
        PurePosixPath(filename) for filename in filenames
        if any(fnmatch.fnmatch(filename, pattern) for pattern in config.target_patterns)
    )
    if not targets:
        return None

    directory = create_run_directory(config.repository_output_path, before, after)
    change = Change(before, after, targets, directory)
    LOGGER.info("Change %s -> %s files=%d path=%s", before, after, len(targets), directory)
    LOGGER.info("To rerun these changes, set execution.from_commit in YAML to %s", before)
    print(f"Change {before[:7]} -> {after[:7]}: {len(targets)} file(s)\nResults: {directory}", flush=True)
    for name, handler in handlers:
        LOGGER.info("Start handler: %s", name)
        handler(config, change)
        LOGGER.info("Finished handler: %s", name)
    return change


def run(config: Config) -> None:
    while True:
        if polling_is_active(config, datetime.now(JST)):
            poll_once(config)
        time.sleep(config.polling_interval_seconds)


def polling_is_active(config: Config, current: datetime) -> bool:
    value = current.astimezone(JST).time().replace(tzinfo=None)
    start, end = config.polling_start, config.polling_end
    if start == end:
        return True
    if start < end:
        return start <= value < end
    return value >= start or value < end


def _changed_files(repository: Path, before: str, after: str) -> list[str]:
    output = _git_bytes(
        repository, "diff", "--name-only", "-z", "--no-ext-diff",
        "--no-textconv", "--no-renames", before, after,
    )
    return [
        value.decode("utf-8", errors="surrogateescape")
        for value in output.split(b"\0") if value
    ]


def _git_text(repository: Path, *arguments: str) -> str:
    return _git_bytes(repository, *arguments).decode("utf-8").strip()


def _git_bytes(repository: Path, *arguments: str) -> bytes:
    return subprocess.check_output(["git", *arguments], cwd=repository, timeout=60)


def main() -> int:
    parser = argparse.ArgumentParser(description="差分を検出し、登録された処理を順番に呼び出します")
    parser.add_argument("-c", "--config", type=Path, required=True)
    arguments = parser.parse_args()
    try:
        config = load_config(arguments.config)
        log_path = configure_logging(config.repository_output_path)
        print(f"Log: {log_path}", flush=True)
        if config.once or config.from_commit:
            poll_once(config, config.from_commit)
        else:
            run(config)
    except KeyboardInterrupt:
        return 0
    except Exception as error:
        LOGGER.exception("GitPoller failed")
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    finally:
        close_logging()
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    raise SystemExit(main())
