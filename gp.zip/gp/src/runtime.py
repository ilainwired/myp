from __future__ import annotations

import json
import logging
import re
import subprocess
import sys
from pathlib import Path


LOGGER = logging.getLogger("GitPoller")


def run_command(
    command: list[str],
    cwd: Path,
    directory: Path,
    timeout_seconds: float,
    env: dict[str, str],
) -> str:
    directory.mkdir(parents=True, exist_ok=True)
    stdout_path = directory / "stdout.log"
    stderr_path = directory / "stderr.log"
    LOGGER.info("Command: %s", json.dumps(command, ensure_ascii=False))
    try:
        # Raw files are readable while the child runs, including on failure.
        with stdout_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
            subprocess.run(
                command, cwd=cwd, check=True, stdout=stdout, stderr=stderr,
                stdin=subprocess.DEVNULL, timeout=timeout_seconds, env=env,
            )
    finally:
        if stderr_path.is_file():
            print(stderr_path.read_text(encoding="utf-8", errors="replace"), end="", file=sys.stderr, flush=True)
    return stdout_path.read_text(encoding="utf-8")


def create_run_directory(repository_output: Path, before: str, after: str) -> Path:
    repository_output.mkdir(parents=True, exist_ok=True)
    numbers = [
        int(match[1]) for path in repository_output.iterdir()
        if path.is_dir() and (match := re.fullmatch(r"([0-9]{3,})_[0-9a-f]{7}_[0-9a-f]{7}", path.name))
    ]
    number = max(numbers, default=0) + 1
    directory = repository_output / f"{number:03d}_{before[:7]}_{after[:7]}"
    directory.mkdir()
    return directory


def configure_logging(output_path: Path) -> Path:
    close_logging()
    log_path = output_path / "log.txt"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    handler = logging.FileHandler(log_path, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    LOGGER.addHandler(handler)
    LOGGER.setLevel(logging.INFO)
    LOGGER.propagate = False
    return log_path


def close_logging() -> None:
    for handler in LOGGER.handlers:
        handler.close()
    LOGGER.handlers.clear()
