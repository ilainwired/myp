"""Append one CSV row per Copilot invocation, including unsuccessful reviews."""
from __future__ import annotations

import csv
import json
import logging
import os
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path, PurePosixPath

from configuration import Config


LOGGER = logging.getLogger("GitPoller")
JST = timezone(timedelta(hours=9))
NANO_AIU_PER_CREDIT = Decimal(1_000_000_000)
COLUMNS = (
    "started_at", "finished_at", "target_file", "ai_credits", "session_ai_credits",
    "credit_source", "status", "result_file", "command", "backend", "session_id", "resumed",
)


def previous_nano_aiu(events: Path) -> Decimal | None:
    """Only needed to subtract usage from an existing Copilot conversation."""
    total = None
    for line in events.read_text(encoding="utf-8").splitlines():
        try:
            event = json.loads(line, parse_float=Decimal)
            if event["type"] in ("session.shutdown", "session.usage_checkpoint"):
                total = Decimal(str(event["data"]["totalNanoAiu"]))
            elif event["type"] == "assistant.usage":
                total = None
        except (ValueError, KeyError, TypeError, InvalidOperation):
            total = None
    return total


def read_credits(directory: Path, resumed: bool, before_nano: Decimal | None) -> dict:
    credits = {"ai_credits": "", "session_ai_credits": "", "credit_source": ""}
    try:
        usage = json.loads((directory / "usage.json").read_text(encoding="utf-8"), parse_float=Decimal)
        nano = Decimal(str(usage["totalNanoAiu"]))
    except (OSError, ValueError, KeyError, TypeError, InvalidOperation):
        return credits
    if not nano.is_finite() or nano < 0:
        return credits
    credits["session_ai_credits"] = format(nano / NANO_AIU_PER_CREDIT, "f")
    credits["credit_source"] = "usage.json:totalNanoAiu"
    baseline = before_nano if resumed else Decimal(0)
    if baseline is not None and baseline.is_finite() and 0 <= baseline <= nano:
        credits["ai_credits"] = format((nano - baseline) / NANO_AIU_PER_CREDIT, "f")
    return credits


def append_row(path: Path, row: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=COLUMNS)
        if file.tell() == 0:
            writer.writeheader()
        # Repository filenames are untrusted. Keep Excel from treating text
        # cells as formulas; the command JSON still contains the original path.
        writer.writerow({
            key: "'" + value if isinstance(value, str) and value.startswith(("=", "+", "-", "@", "\t", "\r", "\n")) else value
            for key, value in row.items()
        })


@contextmanager
def log_invocation(
    config: Config, filename: PurePosixPath, result_path: Path, command: list[str],
    directory: Path, session_id: str,
):
    # Copilot chooses its home; no extra setting is required by GitPoller.
    home = Path(os.environ.get("COPILOT_HOME") or Path.home() / ".copilot").expanduser()
    events = home / "session-state" / session_id / "events.jsonl"
    resumed = events.is_file()
    before_nano = previous_nano_aiu(events) if resumed else None
    LOGGER.info("Copilot session: %s (%s)", session_id, "resume" if resumed else "new")
    started_at = datetime.now(JST).isoformat(timespec="milliseconds")
    status = "error"
    try:
        yield
        status = "success"
    finally:
        finished_at = datetime.now(JST).isoformat(timespec="milliseconds")
        path = config.repository_output_path / "copilot.csv"
        credits = read_credits(directory, resumed, before_nano)
        append_row(path, {
            "started_at": started_at,
            "finished_at": finished_at,
            "target_file": filename.as_posix(),
            **credits,
            "status": status,
            "result_file": str(result_path.resolve()),
            "command": json.dumps(command, ensure_ascii=False),
            "backend": "copilot",
            "session_id": session_id,
            "resumed": str(resumed).lower(),
        })
        LOGGER.info("Copilot usage: %s", json.dumps(credits))
        LOGGER.info("Copilot CSV: %s; status=%s file=%s", path, status, filename)
