from __future__ import annotations

import json
import logging
import os
import shutil
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory
from uuid import uuid4

from configuration import Change, Config, CopilotConfig
from copilot_logging import log_invocation
from runtime import run_command


LOGGER = logging.getLogger("GitPoller")


def review(config: Config, change: Change) -> None:
    for filename in change.files:
        if not (config.repository_path / filename).is_file():
            LOGGER.info("Deleted file; current-file review skipped: %s", filename)
            continue
        review_file(config, filename, change.directory / f"{filename.as_posix()}.md")


def review_file(config: Config, filename: PurePosixPath, result_path: Path) -> str:
    if filename.is_absolute() or ".." in filename.parts:
        raise ValueError(f"Invalid review path: {filename}")
    settings = config.copilot
    session_id = str(settings.session_id or uuid4())
    prompt = (
        f"{filename.as_posix()}\n"
        "当該ファイルのみをレビューしてください。\n"
        "結果はMarkdownで出力してください。"
    )
    if settings.instruction_file and settings.instruction_file.is_file():
        # Optional repository instructions may override the base instructions.
        prompt += "\n\n" + settings.instruction_file.read_text(encoding="utf-8")
        LOGGER.info("Instruction loaded: %s", settings.instruction_file)
    LOGGER.info("Result file: %s", result_path)
    with TemporaryDirectory(prefix="gitpoller-copilot-") as temporary:
        directory = Path(temporary)
        command = build_command(
            settings, prompt, session_id, directory / "usage.json", config.repository_path,
        )
        with log_invocation(config, filename, result_path, command, directory, session_id):
            output = run_command(command, config.repository_path, directory, settings.timeout_seconds, _review_environment())
            answer = _copilot_answer(output)
            result_path.parent.mkdir(parents=True, exist_ok=True)
            result_path.write_text(answer, encoding="utf-8")
            print(answer, flush=True)
    LOGGER.info("Review completed: %s", filename)
    return answer


def build_command(
    settings: CopilotConfig, prompt: str, session_id: str, usage_file: Path,
    repository: Path,
) -> list[str]:
    # Copilot options live here. Pass arguments directly, without a shell.
    return [
        *_resolve_copilot_command(settings.launcher),

        # Review input, session and credit limit (values come from YAML).
        "-C", str(repository.resolve()),
        "--prompt", prompt,
        "--session-id", session_id,
        "--max-ai-credits", str(settings.max_ai_credits),

        # Read-only tools. No shell, file changes or URL access.
        "--available-tools=view,glob,grep",
        "--allow-tool=read",
        "--deny-tool=shell,write,url",
        "--disallow-temp-dir",

        # Disable automatic extensions and interactive/background features.
        "--disable-builtin-mcps",
        "--no-custom-instructions",
        "--no-ask-user",
        "--no-auto-update",
        "--no-remote",
        "--no-remote-export",
        "--no-experimental",
        "--no-eager-powershell-resolution",

        # Read this invocation's Markdown from stdout and usage from JSON.
        "--output-format=json",
        "--usage-output-file", str(usage_file.resolve()),
    ]


def _resolve_copilot_command(command: tuple[str, ...]) -> tuple[str, ...]:
    executable = Path(shutil.which(command[0]) or command[0])
    if os.name != "nt" or executable.suffix.lower() not in (".cmd", ".bat"):
        return (str(executable), *command[1:])
    # Windows batch launchers lose multiline prompts and interpret shell syntax.
    # npm's standard launcher can be bypassed by invoking its JS entry directly.
    loader = executable.parent / "node_modules/@github/copilot/npm-loader.js"
    if executable.name.lower() == "copilot.cmd" and loader.is_file():
        bundled_node = executable.with_name("node.exe")
        node = str(bundled_node) if bundled_node.is_file() else "node"
        return (node, str(loader), *command[1:])
    raise ValueError("バッチ経由では起動できません。copilot.exe または node とJSファイルを指定してください")


def _review_environment() -> dict[str, str]:
    return {
        **os.environ,
        "GITHUB_COPILOT_PROMPT_MODE_REPO_HOOKS": "false",
        "GITHUB_COPILOT_PROMPT_MODE_WORKSPACE_MCP": "false",
        "GITHUB_COPILOT_PROMPT_MODE_EXTENSIONS": "false",
        "USE_TGREP": "false",
    }


def _copilot_answer(output: str) -> str:
    last_message = ""
    final_message = ""
    for line in output.splitlines():
        event = json.loads(line)
        if event["type"] == "session.error":
            raise RuntimeError("Copilotがエラーを返しました")
        if event["type"] == "assistant.message":
            data = event["data"]
            last_message = data["content"]
            if data.get("phase") == "final_answer":
                final_message = last_message
    answer = final_message or last_message
    if not answer:
        raise RuntimeError("Copilotの最終回答を取得できませんでした")
    return answer
