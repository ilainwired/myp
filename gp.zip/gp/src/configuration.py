from __future__ import annotations

from dataclasses import dataclass
from datetime import time
from pathlib import Path, PurePosixPath
from uuid import UUID

import yaml


@dataclass(frozen=True)
class CopilotConfig:
    launcher: tuple[str, ...] = ("copilot",)
    instruction_file: Path | None = None
    max_ai_credits: float = 100
    timeout_seconds: float = 600
    session_id: UUID | None = None


@dataclass(frozen=True)
class Config:
    repository_path: Path
    repository_name: str
    output_path: Path
    target_patterns: tuple[str, ...]
    handlers: tuple[str, ...]
    copilot: CopilotConfig
    polling_interval_seconds: float = 5
    polling_start: time = time(7)
    polling_end: time = time(22)
    once: bool = False
    from_commit: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.once, bool):
            raise ValueError("execution.once must be true or false.")
        if self.from_commit is not None and (not isinstance(self.from_commit, str) or not self.from_commit):
            raise ValueError("execution.from_commit must be a commit string or null.")
        if (
            not self.repository_name or self.repository_name in (".", "..")
            or any(char in self.repository_name for char in "/\\:")
        ):
            raise ValueError("repository.name must be a single directory name.")

    @property
    def repository_output_path(self) -> Path:
        return self.output_path / self.repository_name


@dataclass(frozen=True)
class Change:
    before: str
    after: str
    files: tuple[PurePosixPath, ...]
    directory: Path


def load_config(path: Path) -> Config:
    path = path.resolve()
    with path.open(encoding="utf-8") as file:
        values = yaml.safe_load(file)
    repository = values["repository"]
    repository_path = (path.parent / repository["path"]).resolve()
    polling = values.get("polling", {})
    execution = values.get("execution", {})
    copilot = values["copilot"]
    launcher = copilot.get("launcher", ["copilot"])
    if (
        not isinstance(launcher, list) or not launcher
        or any(not isinstance(arg, str) or not arg for arg in launcher)
    ):
        raise ValueError("copilot.launcher must be a nonempty list of executable arguments.")
    instruction = copilot.get("instruction_file", "Instruction.md")
    session_id = copilot.get("session_id")
    return Config(
        repository_path=repository_path,
        repository_name=repository["name"],
        output_path=(path.parent / values["output"]).resolve(),
        target_patterns=tuple(repository["target_patterns"]),
        handlers=tuple(values["handlers"]),
        polling_interval_seconds=float(polling.get("interval_seconds", 5)),
        polling_start=time.fromisoformat(polling.get("start", "07:00")),
        polling_end=time.fromisoformat(polling.get("end", "22:00")),
        once=execution.get("once", False),
        from_commit=execution.get("from_commit"),
        copilot=CopilotConfig(
            launcher=tuple(launcher),
            instruction_file=(repository_path / instruction).resolve() if instruction else None,
            max_ai_credits=float(copilot.get("max_ai_credits", 100)),
            timeout_seconds=float(copilot.get("timeout_seconds", 600)),
            session_id=UUID(session_id) if session_id is not None else None,
        ),
    )
