# AI Instruction 02：確認済みRAM一覧から判定・Excel・証拠を作成

01を未実施なら `AI_Instruction_01.md` を先に読む。会話の記憶に依存せず、以下と保存ファイルを正とする。Excelはopenpyxl、PDFは作らない。

## 1. 入力と承認を固定【独自スクリプト＋AI】

01の `stage01/inventory.json` と**人が確認・訂正したRAM CSV**を使う。グループの再推測は禁止。

```bash
python3 scripts/analyze_project.py 02 \
  --config /path/to/project.json \
  --ram-csv /path/to/RAM一覧_reviewed.csv \
  --review /path/to/human_review.json
```

review JSONは次の形式。ハッシュは `sha256sum ファイル名` または01の `import_ram_review.py` で取得する。

```json
{
  "approved": true,
  "reviewer": "実際に確認した人",
  "reviewed_at": "実際の確認日時",
  "ram_csv_sha256": "確認済みCSVのSHA-256",
  "inventory_sha256": "stage01/inventory.jsonのSHA-256"
}
```

これは内容とハッシュの検査であり、承認者の本人認証ではない。テストは `purpose: test` に限り省略可能：

```bash
python3 scripts/analyze_project.py 02 --config /path/to/test/project.json --test-mode
# 01と02をまとめる場合
python3 scripts/analyze_project.py test --config /path/to/test/project.json
```

省略結果は `TEST_HUMAN_REVIEW_SKIPPED` と表示する。本番の省略は拒否。CSVのRAM欠落・重複・未知RAM、不正番号、レビューのハッシュ不一致、01以降の元入力変更は停止する。

## 2. 6条件の意味【独自スクリプト。AIが意味を確認】

TRUE=要求を満たす、FALSE=違反。**条件1〜3も、SchMで競合を防げればTRUE**。アクセス回数を減らしたように見せず、保護前をraw、保護後をfinalに分ける。

|条件|保護前のパターン|保護反映後のFALSE条件|
|---|---|---|
|1|同じ具体RAM要素へ上下がW|上下Wの要素に保護外の下位Wがある。全下位Wが指定区間内ならTRUE|
|2|上位W、下位が同じ具体要素へR2回以上|下位の最初と最後のRの間に上位Wを入れられる|
|3|上位R、下位が同じ具体要素へW2回以上|下位の最初と最後のWの間に上位Rを入れられる|
|4|グループへ下位R・上位W|グループの下位R区間へ上位のメンバWを入れられる|
|5|グループへ下位W・上位R|グループの下位W区間へ上位のメンバRを入れられる|
|6|グループへ下位W・上位W|グループの下位W区間へ上位のメンバWを入れられる|

条件1は書込み主体と保護の規則であり、単一Wが途中で割れることの証明ではない。条件2〜6の区間は下位の該当アクセスの最初から最後まで。個々の整数R/Wを不可分と仮定するため、該当アクセス1回なら途中へ割り込まない。グループ未所属RAMの4〜6はTRUE（非該当）と注記する。

`g[0]`と`g[1]`へのR各1回を条件2のR2回にしない。[]は表示名。一方、グループの正規RAM名はそのメンバの全配列要素を含む保守的な集合として評価する。インスタンス別グループを必要とする場合は仕様と試験を拡張する。

グループ違反は全メンバへ反映する。複数所属RAMの全体判定はAND。Excelの結合セルは**グループ単位**、`判定データ`にはRAM全体のAND結果を保存する。

## 3. 保護と割込み位置をモデル化【独自スクリプト】

前提は単一コア、異なる優先度の2または3タスク（低・中・高）、各タスク1回実行、抽出経路固定、個々の整数R/W不可分。

設定されたEnter/Exitの区間に下位がいる間、上位は実行を開始しない。上位が同じAPIを呼ぶことは要求しない。関数本体は空でも保護される。上位だけの保護では下位の複数アクセス間への割込みを防げない。

下位のアクセス・Enter・Exitの前後の隙間を列挙し、保護中の隙間を除いた各位置で上位を完走させる。保護中の起動要求の遅延実行は、解除直後の隙間で表せる。Exitして同じAreaへ入り直す間は保護外。同じArea名だけで区間を連結しない。

3段階では `project_analysis/multitask.py` が実行中タスクのスタックを持ち、低→中→高→中→低の入れ子も含め、3タスクの許可された実行順を列挙する。実行中のタスクより低いタスクは再開できず、保護区間内では上位を新たに開始しない。各タスクは1回。低−中、低−高、中−高の各ペアへ時系列を射影し、6条件のRAM別結果をAND集約する。単純に3つの独立解析をしただけで3タスクの配置を検証したとはしない。

results.jsonの `pairs` に各ペアの判定・射影シナリオを保存し、C監視器／Evaの証拠は `pairs/low__middle/model/`、`pairs/low__high/model/`、`pairs/middle__high/model/`。全3タスクの時系列はトップレベルのschedulesに残す。Excelの `優先度ペア判定` に内訳を記載。トップレベルの代表反例はペア名とペア内シナリオIDを持つ。

`stage02/results.json`に保存する内容：

- ram：raw／final（条件1〜6）、所属group、FALSEの代表シナリオID。
- groups／group_results：入力CSVの集合と条件4〜6。
- schedules：許可シナリオ、割込み位置、アクセスとEnter/Exitの時系列、違反。
- ram_csv_sha256：確認済みCSVのハッシュ。
- verification：次節の照合結果。

保護効果は依頼者指定の抽象化。実機のOS Resource、割込み禁止、RTE生成コードの正しさを証明したとは述べない。名称の一次資料：[AUTOSAR RTE R24-11](https://www.autosar.org/fileadmin/standards/R24-11/CP/AUTOSAR_CP_SWS_RTE.pdf)。

## 4. C監視器で照合【独自スクリプト＋Clang＋Frama-C】

02の `project_analysis/evidence.py` は以下を実行する。テストの期待値は読まない。

1. アクセスIRから `model/access_model.c` を生成。イベント、具体要素、グループ、Enter/Exitを入力に、C側の監視器が条件を計算する。PythonのTRUE/FALSEを埋め込んで正解にしない。
2. Clangでビルド・実行し、`model/clang.log`と`native.log`へ保存。シナリオ×RAMの6ビット違反maskをPython結果と比較。
3. 同じCモデルをEva解析する。名前付きACSL **check** `sc_N_ram_M_rule_K`で各条件を評価。FALSEはinvalidになるが、checkは後続状態を制約しない。assertによる枝打切りを避ける。
4. `model/eva.log`のinvalid／unknown、総チェック数、実行時アラームを照合。未知・欠落・件数差異・不一致・アラームがあれば停止。
5. `model/verification.json`と`model/model_map.json`を保存。数値IDから元RAMへたどれる。

これは**抽出IRのアクセスモデル**の検証。元Cを各割込みで直接実行した結果でも、元Cとモデルの完全な等価性証明でもない。01の元C逐次Evaとは分けて説明する。

## 5. AIによる根拠レビュー【AI＋ツール成果物】

|確認|成果物|AIの具体的な作業|
|---|---|---|
|対象・マクロ|compile_commands.json、preprocessed.i|対象TU・-I/-D、マクロ二重評価を確認|
|変数・回数|ast.json、inventory.json|宣言ID、型、ポインタ先、呼出経路とR/Wを元Cと照合|
|グループ|group_proposals.json、AI判断JSON、確認済CSV|AI推測と人の確定を区別し、02が入力を尊重したか確認|
|元C|original_low.log／original_high.log|逐次Evaの入口・到達状態・アラームを確認|
|保護・反例|results.json schedules／witnesses|保護中に上位を入れず、分断区間の隙間を残しているか確認|
|判定整合|native.log、eva.log、verification.json|Python/C/Evaの一致、invalidの意味、unknown／欠落がないことを確認|

ログにない検証をしたと書かない。既存試験PASSを理由に新コードの未対応構文を安全扱いしない。必要な拡張と独立した期待値／失敗試験を追加するか、停止理由を報告する。

## 6. Excel作成と確認【openpyxl＋LibreOffice＋独自スクリプト】

```bash
python3 scripts/export_reports.py --configs /path/to/project.json --output /path/to/report_directory
python3 scripts/verify_excel.py --directory /path/to/report_directory
```

標準は01_RAM一覧_人手確認用.xlsxと02_判定結果.xlsx。スイート集計時は03_テスト結果.xlsxも作る。フルスイートの出力先は `outputs/deliverables`。

1. RAMを列、条件1〜6を行に置く。変数名は**時計回り90度**（textRotation=180）。長い名前は表示上改行し、正規名を判定データへ残す。
2. a,b,c,dが同じグループなら条件4、5、6の各行でそれぞれ4列を結合。条件1〜3は結合しない。
3. 重複集合 `{a,b}` と `{b,c}` は `a,b | b,c` と列を再掲。条件1〜3とR/Wも同じRAMに同じ値を再掲する。
4. 未所属は単独列。4〜6のTRUEには非該当コメントを付ける。
5. 下に公開関数→呼出先→アクセス順を表示し、R1／W1を記入。元コード・展開後・具体要素・位置・保護Area・ASTはアクセス根拠へ保存。
6. TRUEは緑、FALSEは赤。rawとfinalを保存し、判定表は参照数式にする。確認状態、前提、証拠の場所も示す。
7. LibreOfficeでxlsx再計算。数式キャッシュ・参照値・エラー、結合範囲、回転を検査。**PDFへ変換しない**。
8. `qa/*.png`を目視確認。Pillow近似描画なのでExcel本体の完全再現とは言わない。構造検査も併用し、最長の変数名と4列結合を個別に確認。

Excelのグループを編集しただけでは02の結果は更新されない。01のCSVへ戻し、確認ハッシュを更新、02→Excel生成を再実行する。

## 7. 全試験と範囲報告【独自スクリプト＋AI】

Windowsでは `run_all.bat`、WSLでは `bash scripts/run_all.sh`。個別手順：

```bash
python3 tests/run_project_suite.py
python3 tests/test_pipeline_contracts.py
python3 scripts/export_reports.py --suite outputs/project_suite/test_results.json --suite-root . --output outputs/deliverables
python3 scripts/verify_excel.py --directory outputs/deliverables
python3 scripts/summarize_tests.py
```

75プロジェクト：100台8件（最小6条件＋正常対照）、200台20件（マクロ、整数型、構造体配列、複数TU、6件合体、重複グループ等）、300台18件（SchM正常／部分／分断／誤用）、400台11件（低中高、全ペア、入れ子割込み、保護、グループ集約、配置上限、空タスク）、900台18件（呼出し32／64／65、配列4096／4097、構造体16段、マクロ64段、アクセス64／65、複合、解析停止）。

期待値は `tests/project_suite.json` と各プロジェクトの `test_expectation.json`。解析器へ渡さず、テスト実行器だけで比較する。ANALYZEDは全条件TRUEでなく「解析完了」。FALSEが期待どおりでも試験PASS。BLOCKED試験は停止理由も照合する。

10件の追加試験は、examples外への移設、レビュー必須、CSV非再推測、ソース変更検出、3段階の入れ子／保護／列挙上限等。疑似承認JSONには自動試験用と明記し、本物の人の承認として納品しない。

`outputs/deliverables/テスト結果.md`に個別結果、試験上限、ツール成果物の利用経路、保証範囲を残す。一般C、実機SchM、マルチコア、4タスク以上、共有値依存分岐／添字、一般ループ等を未検証のまま安全としない。

## 8. コード確定後のPowerPoint【AI＋プレゼン生成スクリプト】

先に全試験とExcel検証を完了する。`summarize_tests.py`が解析・テスト・Excelコードと試験入力のハッシュを `outputs/deliverables/code_freeze.json` へ記録する。PowerPoint生成時に未変更を照合。解析コードを修正したら試験・Excel検証・freezeをやり直す。

```bash
python3 scripts/build_explanation.py
python3 scripts/render_presentation.py
```

出力は `outputs/deliverables/04_解析フローと代表例.pptx`。TC205（マクロ二重評価）、TC209（複数TU・深い構造体配列）、TC306（SchM保護とグループ）を、入力→Clang成果物→独自処理→AI判断→Frama-C照合→Excelという図で説明する。値と判定は実際のJSON／ログから読む。TC219の候補取下げをAIの判断例として補足してよい。

本セッションで適用したPresentationsスキルに従って作り、全スライドをPNGで目視確認する。PDFは作らない。生成依存と再実行方法は上記スクリプトにも記載する。会話にしかない前提を持ち込まない。

実装環境では指定のartifact-toolパッケージが存在せずセットアップが失敗したため、PptxGenJS 4.0.1による編集可能なPPTX図形を代替に用いる。build_explanation.pyはNode/npmを使い、必要ならこの固定版をユーザーの `.local/share/static-analysis-presentation` にインストールする。描画はpython3-uno経由のLibreOffice GraphicExportFilterから直接PNGへ出力する。依存のインストール先はツール環境で、clean.batによる成果物削除の対象外。PPT作業用の外部一時ディレクトリは自動削除する。

## 9. 削除と再配置【Windowsバッチ＋PowerShell】

```bat
clean.bat -DryRun
clean.bat
clean_temp.bat -DryRun
clean_temp.bat
```

clean.batはoutputs全体（Excel、PPTX、ログ、画像、モデル、freeze）、各example直下の.build、scripts/testsのPythonキャッシュを削除。入力C／ヘッダ／Makefile／project.json／期待値／Instruction／スクリプトは残す。ワークスペース外の実プロジェクト出力は勝手に消さず、別途管理する。

clean_temp.batは `scripts/cleanup_legacy.json` の固定列挙パスだけを削除。一度実行した後も、無いものはスキップできる。旧ファイル名を再利用するときは削除リストから外す。パスはバッチ位置から解決するため、ワークスペースrenameに追従。外部を指すリンクが対象の起点／親にあればスキップして報告する。

失敗パスは `cleanup_remaining.txt`。Excel等を閉じて再実行し、残る場合はAIの最終返答で正確なパスを知らせる。

## 10. 最終報告【AIのみ】

Excel3冊、PPTX、Instruction2冊、テスト結果へリンクする。実測PASS件数、人手省略、対応範囲の限界、削除残骸の有無を簡潔に報告する。一般Cや実機排他を証明したと主張しない。
