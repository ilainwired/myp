# AI Instruction 01：RAM抽出・同時性グループの推測

会話履歴を持たないAI／担当者が再実行するための手順。次工程は同じ場所の `AI_Instruction_02.md`。ユーザーの確定指示は以下を正とする。

## 0. 確定した仕様

- AI + Clang + Frama-CでCプロジェクトを解析する。Excelは **openpyxl**。PDFは作らない。
- 01がRAMと同時性グループをコードから**推測して記入**し、人が確認・訂正する。02はそのCSVを入力とし、グループを再推測しない。
- テスト時だけ人手確認を省略してよい。本番の承認をAIが済ませたと記録しない。
- 構造体、構造体のネスト、各階層の配列、末端の整数メンバ／整数配列に対応する。RAM表示は `g[].b[].c[].values[]`。サイズや添字は表示しないが、解析内部には具体添字を保持する。
- Enter／Exitは**設定可能な保護キーワード**。対応区間を同時性保護として扱う。関数本体は空でもよい。実際のSchM名を設定し、大文字小文字を勝手に変更しない。
- 条件1〜6すべてに排他効果を反映する。保護前のアクセスパターンも別途記録する。
- Excelの変数列見出しは**時計回り90度**。openpyxlでは `Alignment(textRotation=180)`。90を指定すると逆方向になる。
- Excelの条件4、5、6は、それぞれ同じグループの変数列を横結合する。4変数なら4列を各行で結合。重複所属はグループ別に列を再掲する。
- 各exampleはMakefile付きの独立プロジェクト。解析器はexamplesの所在・ファイル名・期待値を知らない。
- PowerPointは**解析コードと全テストを確定した後**、実際の成果物から代表例3件を図で説明する。
- 通常生成物は `clean.bat`、旧版の残骸は一回用の `clean_temp.bat`。消せないパスは利用者に知らせる。

## 1. 環境準備【独自スクリプト＋OS】

Windows + WSL Ubuntuを使用する。検証環境はClang 21.1.8、Frama-C 33.0 Arsenic、Bear 3.1.6、Python 3.14.4、openpyxl 3.1.5。実際のバージョンは各出力先の `tool_versions.json` を読む。別バージョンへ変更した場合は全試験を再実行する。

WSL未導入なら管理者が `wsl --install -d Ubuntu` を行い、再起動と初回ユーザー作成を完了する。その後WSL内で：

```bash
cd /mnt/c/workspace/static_analysis  # 実際の配置場所に置換
bash scripts/install_wsl.sh
```

既に依存が揃っていれば再インストール不要。公式Frama-CインストーラのGUI/AppArmor設定がWSLで失敗する場合、CLIの `frama-c -version` 成功を確認する。GUI設定失敗とCLI解析失敗を混同しない。Excel検証ではLibreOfficeとPillowを使い、PDF変換を行わない。

## 2. 入力設定【AIのみ：プロジェクト情報を読解・記入】

解析対象はローカルにチェックアウト済みのリポジトリ。専用JSONでリポジトリの起点、Makefile、公開関数のタスク割当を指定する。元の「公開関数一覧.txt」に相当する情報は `tasks` に記入する。数値が大きいほど高優先。**低・中・高の3段階**に対応し、2タスクの設定も使える。

設定例（JSONを対象リポジトリ直下へ置く）：

```json
{
  "schema_version": 2,
  "project_id": "MY_PROJECT",
  "purpose": "production",
  "repository": {"path": ".", "description": "local checkout; commit等を必要に応じて記載"},
  "build": {"working_directory": ".", "makefile": "Makefile", "target": "all", "variables": ["MODE=1"]},
  "tasks": [
    {"id": "low", "entry": "public_f1", "priority": 1},
    {"id": "middle", "entry": "public_f2", "priority": 2},
    {"id": "high", "entry": "public_f3", "priority": 3}
  ],
  "exclusive_areas": [
    {"id": "A", "enter": "SchM_Enter_Component_A", "exit": "SchM_Exit_Component_A"}
  ],
  "limits": {"call_depth": 64, "array_extent": 4096, "storage_locations": 20000, "events_per_task": 1024, "schedules": 1100},
  "output_directory": "analysis_output"
}
```

|設定|相対パスの起点|
|---|---|
|repository.path|project.jsonのディレクトリ|
|build.working_directory|repository.path|
|build.makefile|build.working_directory|
|output_directory|project.jsonのディレクトリ|
|ai_group_decisions（任意）|project.jsonのディレクトリ|

Makefileは実際にCをコンパイルする必要がある。Bearは `make -B -f … target` を捕捉する。コンパイララッパー等で捕捉できない場合は停止して原因を解消する。ビルドされないファイルは解析されない。同一ソースの異なる-D構成は別設定・別出力先にする。対象ABIはWSL x86_64 LP64。他のABIに黙って読み替えない。

Enter/Exitのペアを `exclusive_areas` に列挙する。未登録SchM、同じAreaへの二重Enter、Exitの順序違い、Exit欠落は停止。異なるAreaのLIFOネスト、呼出し先をまたぐ区間、マクロ経由は試験済み。

## 3. RAM・アクセス抽出【独自スクリプト＋Clang】

```bash
python3 scripts/analyze_project.py 01 --config /path/to/project.json
```

このコマンドは以下と次節の逐次Evaを実行する。

1. Make + Bearで実ビルドし、`build/compile_commands.json` にコンパイル情報を保存。
2. 捕捉した各TUの-I/-Dを用いてClang -Eを実行し、`clang/tu_NNN/preprocessed.i` を保存。
3. Clang `-Xclang -ast-dump=json` の結果を `ast.json` へ保存。
4. `project_analysis/build.py` が宣言IDを一意化。externを定義へ結び、同名staticを `src/a.c::g` のようにTU別に扱う。
5. `clang_access.py` と `project_analysis/extract.py` が型、メンバ、具体添字、ポインタ、関数呼出しを追い、R/Wと保護区間を抽出。`&g`自体はRと数えない。RMWはRとWに分ける。
6. 行マーカーから元ファイル・行を復元し、元コード、展開後コード、AST参照、呼出経路、Enter/Exitを記録。

結果は `stage01/inventory.json`。`inventory`はRAM、`tasks[].events`はR/W、`trace`は呼出し付き表示順、`steps`はEnter/Exitを含む時系列。`object`は具体要素、`ram`は[]に正規化したID。表示のために具体要素の違いを失わせない。

## 4. 元Cの確認【Frama-C＋AIによるログ確認】

各公開関数を `-main` として全プリプロセス済みTUをFrama-C Evaへ渡す。使用コマンド・戻り値・標準出力／標準エラーを `frama/original_low.log`、`original_middle.log`（3段階の場合）、`original_high.log` へ保存する。

AIは入口、到達範囲、計算状態、アラーム数を確認する。アラームや未完了がある場合は工程を進めない。**元Cの逐次Evaでアラーム0でも、並行性の安全の証明ではない。** アクセス回数やグループをFrama-Cから直接取得したと説明しない。回数と呼出文脈はClang ASTを読む独自スクリプトから得ている。

## 5. グループ推測を記入【AI＋Clang抽出結果。設計意図の推測はAI】

スクリプトは複数RAM由来値の比較、同関数内での同値連続書込みから候補を `stage01/group_proposals.json` に記録し、`stage01/RAM一覧.csv` へ記入する。これはAIレビューの手掛かりであり、設計の確定ではない。

AIは候補・元コード・アクセス順を読み、同時に観測／更新する必要がある集合を推測する。型、名前、隣接、同じ定数という理由だけで原始性要求を断定しない。弱い根拠は弱いと記す。候補の追加／取下げ理由を残す。

修正を再実行可能にするには次のJSONを作り、project.jsonに `"ai_group_decisions": "ai_group_decisions.json"` を追加して01を再実行する。`groups`は**最終候補の完全なリスト**。メンバにはinventoryの正確なIDを使う。

```json
{
  "author": "AI",
  "reason": "コードの比較と一括更新を確認。設計者による確認は別途必要。",
  "groups": [
    {"id": "1", "members": ["g_a", "g_b"]},
    {"id": "2", "members": ["g_b", "g_c"]}
  ]
}
```

全部取り下げるなら `"groups": []`。実例は `examples/TC219/ai_group_decisions.json`。stampとflagを同一グループにする根拠が弱いというAIの判断を保存した。スクリプトが無人でAI APIを呼んでいるわけではない。新プロジェクトの設計意図は、この工程でAIが実際に検討する。

## 6. 確認用CSV／Excel【独自スクリプト＋openpyxl】

CSVはUTF-8 BOM付き、正確に次の3列。

```csv
ファイル名,RAM名,同時性グループ
src/ram.c,g_a,1
src/ram.c,g_b,"1,2"
src/ram.c,g_c,2
src/ram.c,g_table[].child[].value[],-
```

グループは正の整数、複数は半角カンマ、未所属は`-`。定義ファイル名とRAM名の組が識別子。別TUの同名staticは別行。未アクセスのグローバルも残す。

```bash
python3 scripts/export_reports.py --configs /path/to/project.json --output /path/to/report_directory
```

`01_RAM一覧_人手確認用.xlsx`を作る。01段階で同時に生成される02ブックには、まだ判定はない。`RAM一覧`のグループ列が人の訂正対象、`推測根拠`が補助資料。完成後のExcel検証は02を参照。

## 7. 人へ渡す【人手。テスト時のみ省略可】

人がグループを確認・訂正する。CSV直接修正またはExcel編集を選べる。Excelから戻す場合：

```bash
python3 scripts/import_ram_review.py \
  --config /path/to/project.json \
  --workbook /path/to/report_directory/01_RAM一覧_人手確認用.xlsx \
  --output /path/to/RAM一覧_reviewed.csv
```

このコマンドはRAM欠落・追加・重複とグループ書式を検査し、CSVとinventory.jsonのSHA-256を表示する。承認は付けない。人の確認後、`stage01/human_review_template.json`を別名保存し、approved=true、実際のreviewer／reviewed_at、両ハッシュを記入する。AIは確認者や日時を捏造しない。

02へ渡すもの：project.json、stage01/inventory.json、**レビュー済みRAM CSV**、human_review JSON、元C／ヘッダ／Makefile。入力が変わった場合は01からやり直す。

## 8. 再実行と限界【独自スクリプト＋AI】

Windowsで `run_all.bat`、WSLで `bash scripts/run_all.sh`。既存のexample／期待値を入力とする。試験入力の再生成が必要なときだけ `python3 tests/create_project_cases.py` を実行する。これはexampleの編集を上書きする。

解析器が期待値を読むことは禁止。`project.json`と`test_expectation.json`は分離する。結果、検証範囲、PowerPoint、削除方法は02に従う。

対応は有限なC部分集合。基本整数型、typedef、volatile、名前付き構造体、固定長配列、解決可能な1／2重ポインタ、直接呼出し、定数分岐、do-while(0)を扱う。共有状態依存分岐／添字、一般ループ、再帰、関数ポインタ、外部副作用、union、bitfield、匿名メンバ、aggregate初期化等は停止対象。全C対応や実機の安全を無条件に保証しない。

最初に提示されたCの `*1 = 100` や `int*`への`&a1`代入は型／構文上の問題を含む。無効なCを都合よく解釈せず修正を明記する。有効な二重ポインタの最小例はTC201。

一次資料：[Clang AST](https://clang.llvm.org/docs/IntroductionToTheClangAST.html)、[Compilation database](https://clang.llvm.org/docs/JSONCompilationDatabase.html)、[Bear](https://github.com/rizsotto/Bear)、[Frama-C Eva](https://frama-c.com/fc-plugins/eva.html)。
