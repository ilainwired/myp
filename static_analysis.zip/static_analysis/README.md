# C RAM同時性解析：AI + Clang + Frama-C

Makefile付きCプロジェクトからRAMとR/Wを抽出し、SchM Enter/Exitを保護キーワードとして6条件を評価する有限モデルの解析器。01でAIがグループを推測し、人が訂正したCSVを02へ渡す。テストでは人手フェーズを省略する。

- [01：RAM抽出・AI推測・人手確認](AI_Instruction_01.md)
- [02：判定・Excel・証拠・PowerPoint](AI_Instruction_02.md)
- [全試験の設計と期待値](tests/project_suite.json)
- [生成したテスト結果](outputs/deliverables/テスト結果.md)

Windowsで `run_all.bat`、WSLで `bash scripts/run_all.sh`。依存導入は `bash scripts/install_wsl.sh`。出力は `outputs/deliverables`。PDFは作らない。

```text
01_RAM一覧_人手確認用.xlsx
02_判定結果.xlsx
03_テスト結果.xlsx
04_解析フローと代表例.pptx
テスト結果.md
```

75件の独立プロジェクトをexamples/TCxxxへ配置。各々Makefile、project.json、Cソース、独立した期待値を持つ。解析器への入力は設定ファイル。試験入力の再生成は `python3 tests/create_project_cases.py`（example編集を上書きするので必要時のみ）。

通常生成物は `clean.bat`、旧版残骸は `clean_temp.bat`（実行済み、再実行可）。`-DryRun`で対象確認できる。

全6条件に保護を反映し、rawとfinalを分けて記録。Excelの条件4〜6はグループごとに横結合、変数見出しは時計回り90度、重複所属は列を再掲する。

低・中・高の3段階に対応し、2タスク設定も使える。3タスクの入れ子割込みを列挙し、低−中／低−高／中−高を評価してAND集約する。各ペアの結果もExcelへ出力する。

対応は単一コア・各タスク1回・個々の整数アクセス不可分を前提とする有限なC部分集合。一般Cや実機OSの排他を無条件に証明するものではない。未対応や上限超過はTRUEにせず停止する。詳細はInstructionを参照。
