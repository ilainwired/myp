int TC906_g[32][32][32]; void TC906_low(void){TC906_g[0][0][0]=1;} void TC906_high(void){TC906_g[0][0][0]=2;}
