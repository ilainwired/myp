void TC906_low(void);
void TC906_high(void);
int main(void) { TC906_low();  TC906_high(); return 0; }
