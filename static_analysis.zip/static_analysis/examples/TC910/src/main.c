void TC910_low(void);
void TC910_high(void);
int main(void) { TC910_low();  TC910_high(); return 0; }
