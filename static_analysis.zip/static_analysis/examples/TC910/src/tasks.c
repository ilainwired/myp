int TC910_g[2]; void TC910_low(void){TC910_g[2]=1;} void TC910_high(void){TC910_g[0]=2;}
