void TC901_low(void);
void TC901_high(void);
int main(void) { TC901_low();  TC901_high(); return 0; }
