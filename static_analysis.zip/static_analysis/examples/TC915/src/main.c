void TC915_low(void);
void TC915_high(void);
int main(void) { TC915_low();  TC915_high(); return 0; }
