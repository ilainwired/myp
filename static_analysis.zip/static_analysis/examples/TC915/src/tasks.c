#include "SchM_Test.h"
int TC915_g;void TC915_low(void){TC915_g=1;SchM_Exit_Test_A();} void TC915_high(void){TC915_g=2;}
