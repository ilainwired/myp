#include "SchM_Test.h"
int TC317_g; int TC317_low(void){ int a=TC317_g;int b=TC317_g;  return a==b;} void TC317_high(void){SchM_Enter_Test_A(); TC317_g=1; SchM_Exit_Test_A();}