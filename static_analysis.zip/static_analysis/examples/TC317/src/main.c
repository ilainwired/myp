int TC317_low(void);
void TC317_high(void);
int main(void) { TC317_low();  TC317_high(); return 0; }
