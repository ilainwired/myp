#define SET2(p) do { *(p)=1; *(p)=2; } while(0)
int TC204_g; void TC204_low(void){SET2(&TC204_g);} int TC204_high(void){return TC204_g;}
