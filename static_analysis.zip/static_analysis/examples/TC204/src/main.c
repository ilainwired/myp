void TC204_low(void);
int TC204_high(void);
int main(void) { TC204_low();  TC204_high(); return 0; }
