#include "SchM_Test.h"
int TC313_g;void TC313_low(void){SchM_Enter_Test_A();SchM_Enter_Test_B();TC313_g=1;SchM_Exit_Test_A();SchM_Exit_Test_B();} void TC313_high(void){TC313_g=2;}
