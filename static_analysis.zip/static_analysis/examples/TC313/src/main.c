void TC313_low(void);
void TC313_high(void);
int main(void) { TC313_low();  TC313_high(); return 0; }
