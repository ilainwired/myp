void TC908_low(void);
void TC908_high(void);
int main(void) { TC908_low();  TC908_high(); return 0; }
