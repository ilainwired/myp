void TC916_low(void);
void TC916_high(void);
int main(void) { TC916_low();  TC916_high(); return 0; }
