int TC210_g[2]; int TC210_low(void){int a=TC210_g[0];int b=TC210_g[1];return a==b;} void TC210_high(void){TC210_g[0]=1;}
