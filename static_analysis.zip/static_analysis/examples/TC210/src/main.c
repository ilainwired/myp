int TC210_low(void);
void TC210_high(void);
int main(void) { TC210_low();  TC210_high(); return 0; }
