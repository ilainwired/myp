int TC214_g; int TC214_low(void){int TC214_g=1;return TC214_g;} void TC214_high(void){TC214_g=2;}
