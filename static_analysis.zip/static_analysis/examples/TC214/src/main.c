int TC214_low(void);
void TC214_high(void);
int main(void) { TC214_low();  TC214_high(); return 0; }
