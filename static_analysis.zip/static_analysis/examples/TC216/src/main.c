void TC216_low(void);
void TC216_high(void);
int main(void) { TC216_low();  TC216_high(); return 0; }
