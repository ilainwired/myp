int TC216_g; void TC216_low(void){TC216_g+=1;} void TC216_high(void){TC216_g=2;}
