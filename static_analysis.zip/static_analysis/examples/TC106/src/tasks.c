int TC106_g_a,TC106_g_b;
void TC106_low(void){TC106_g_a=1;TC106_g_b=1;}
void TC106_high(void){TC106_g_a=2;TC106_g_b=2;}
