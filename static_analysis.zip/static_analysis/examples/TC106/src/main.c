void TC106_low(void);
void TC106_high(void);
int main(void) { TC106_low();  TC106_high(); return 0; }
