int TC101_g;
void TC101_low(void){TC101_g=1;}
void TC101_high(void){TC101_g=2;}
