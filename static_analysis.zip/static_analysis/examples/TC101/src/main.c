void TC101_low(void);
void TC101_high(void);
int main(void) { TC101_low();  TC101_high(); return 0; }
