void TC218_low(void);
void TC218_high(void);
int main(void) { TC218_low();  TC218_high(); return 0; }
