int TC218_g; void TC218_low(void){if(0){TC218_g=1;}} void TC218_high(void){TC218_g=2;}
