void TC904_low(void);
void TC904_high(void);
int main(void) { TC904_low();  TC904_high(); return 0; }
