int TC904_g[4096]; void TC904_low(void){TC904_g[4095]=1;} void TC904_high(void){TC904_g[4095]=2;}
