typedef unsigned short U16;struct Child {U16 values[3];unsigned char flag;};struct Root {struct Child children[2];long long count;volatile int stamp;};struct Root TC219_g;
void TC219_low(void){TC219_g.children[1].values[2]=7;TC219_g.count=3;TC219_g.stamp=1;TC219_g.children[0].flag=1;}void TC219_high(void){TC219_g.children[1].values[2]=9;TC219_g.count=4;TC219_g.stamp=2;TC219_g.children[0].flag=2;}
