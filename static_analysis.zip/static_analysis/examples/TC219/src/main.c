void TC219_low(void);
void TC219_high(void);
int main(void) { TC219_low();  TC219_high(); return 0; }
