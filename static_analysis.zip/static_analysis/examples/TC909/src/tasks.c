int TC909_g[2],TC909_g_index; void TC909_low(void){TC909_g[TC909_g_index]=1;} void TC909_high(void){TC909_g[0]=2;}
