void TC909_low(void);
void TC909_high(void);
int main(void) { TC909_low();  TC909_high(); return 0; }
