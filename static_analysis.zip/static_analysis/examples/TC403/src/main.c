void TC403_low(void);
void TC403_high(void);
int TC403_middle(void);
int main(void) { TC403_low(); TC403_middle(); TC403_high(); return 0; }
