void TC212_low(void);
void TC212_high(void);
int main(void) { TC212_low();  TC212_high(); return 0; }
