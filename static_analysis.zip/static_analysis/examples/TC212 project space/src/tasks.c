int TC212_g; void TC212_low(void){TC212_g=1;} void TC212_high(void){TC212_g=2;}
