int TC311_low(void);
void TC311_high(void);
int main(void) { TC311_low();  TC311_high(); return 0; }
