static int TC203_g; static void helper(void){TC203_g=2;} void TC203_high(void){helper();}
