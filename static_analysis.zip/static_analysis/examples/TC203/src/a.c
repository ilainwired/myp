static int TC203_g; static void helper(void){TC203_g=1;} void TC203_low(void){helper();}
