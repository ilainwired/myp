void TC203_low(void);
void TC203_high(void);
int main(void) { TC203_low();  TC203_high(); return 0; }
