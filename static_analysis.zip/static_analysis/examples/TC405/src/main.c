int TC405_low(void);
void TC405_high(void);
void TC405_middle(void);
int main(void) { TC405_low(); TC405_middle(); TC405_high(); return 0; }
