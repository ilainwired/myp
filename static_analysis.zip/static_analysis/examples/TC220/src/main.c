void TC220_low(void);
void TC220_high(void);
int main(void) { TC220_low();  TC220_high(); return 0; }
