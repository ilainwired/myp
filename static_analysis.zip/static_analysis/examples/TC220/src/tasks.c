int TC220_g_a,TC220_g_b,TC220_g_c,TC220_g_d;void TC220_low(void){TC220_g_a=1;TC220_g_b=1;TC220_g_c=1;TC220_g_d=1;}void TC220_high(void){TC220_g_a=2;TC220_g_b=2;TC220_g_c=2;TC220_g_d=2;}
