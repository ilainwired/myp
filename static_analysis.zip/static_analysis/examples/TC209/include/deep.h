struct C {int values[2];}; struct B {struct C c[4];}; struct A {struct B b[3];}; extern struct A TC209_g[2];
