int TC209_low(void);
void TC209_high(void);
int main(void) { TC209_low();  TC209_high(); return 0; }
