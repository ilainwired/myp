#include "deep.h"
int TC209_low(void){int a=TC209_g[1].b[2].c[3].values[1];int b=TC209_g[1].b[2].c[3].values[1];return a==b;}
