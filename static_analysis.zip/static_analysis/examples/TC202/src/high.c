#include "ram.h"
void TC202_high(void){TC202_g=1;}
