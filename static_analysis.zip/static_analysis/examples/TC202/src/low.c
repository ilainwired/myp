#include "ram.h"
int TC202_low(void){int a=TC202_g;int b=TC202_g;return a==b;}
