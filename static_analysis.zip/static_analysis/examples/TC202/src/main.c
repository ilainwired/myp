int TC202_low(void);
void TC202_high(void);
int main(void) { TC202_low();  TC202_high(); return 0; }
