void TC903_low(void);
void TC903_high(void);
int main(void) { TC903_low();  TC903_high(); return 0; }
