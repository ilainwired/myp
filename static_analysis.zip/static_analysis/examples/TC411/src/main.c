void TC411_low(void);
void TC411_high(void);
void TC411_middle(void);
int main(void) { TC411_low(); TC411_middle(); TC411_high(); return 0; }
