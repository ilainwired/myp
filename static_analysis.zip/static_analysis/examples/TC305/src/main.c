void TC305_low(void);
int TC305_high(void);
int main(void) { TC305_low();  TC305_high(); return 0; }
