int TC304_low(void);
void TC304_high(void);
int main(void) { TC304_low();  TC304_high(); return 0; }
