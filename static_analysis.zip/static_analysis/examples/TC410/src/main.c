void TC410_low(void);
void TC410_high(void);
void TC410_middle(void);
int main(void) { TC410_low(); TC410_middle(); TC410_high(); return 0; }
