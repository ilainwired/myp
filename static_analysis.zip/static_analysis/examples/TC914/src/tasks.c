int TC914_g;void TC914_low(void){for(int i=0;i<3;i++){TC914_g=i;}} void TC914_high(void){TC914_g=2;}
