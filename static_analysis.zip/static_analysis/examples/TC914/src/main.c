void TC914_low(void);
void TC914_high(void);
int main(void) { TC914_low();  TC914_high(); return 0; }
