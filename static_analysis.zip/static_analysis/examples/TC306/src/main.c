void TC306_low(void);
void TC306_high(void);
int main(void) { TC306_low();  TC306_high(); return 0; }
