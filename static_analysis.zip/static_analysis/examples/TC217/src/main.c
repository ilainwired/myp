void TC217_low(void);
void TC217_high(void);
int main(void) { TC217_low();  TC217_high(); return 0; }
