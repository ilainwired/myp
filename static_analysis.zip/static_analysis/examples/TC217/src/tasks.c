int TC217_g,TC217_g_unused; void TC217_low(void){TC217_g=1;} void TC217_high(void){TC217_g=2;}
