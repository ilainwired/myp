#include "SchM_Test.h"
int TC307_g; int TC307_low(void){SchM_Enter_Test_A(); int a=TC307_g;int b=TC307_g; SchM_Exit_Test_A(); return a==b;} void TC307_high(void){ TC307_g=1; }