int TC307_low(void);
void TC307_high(void);
int main(void) { TC307_low();  TC307_high(); return 0; }
