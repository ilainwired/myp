void TC206_low(void);
void TC206_high(void);
int main(void) { TC206_low();  TC206_high(); return 0; }
