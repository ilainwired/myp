int TC206_g,TC206_g_other; void TC206_low(void){TC206_g=1;} void TC206_high(void){
#if MODE
TC206_g=2;
#else
TC206_g_other=2;
#endif
}
