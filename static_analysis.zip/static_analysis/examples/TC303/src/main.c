void TC303_low(void);
int TC303_high(void);
int main(void) { TC303_low();  TC303_high(); return 0; }
