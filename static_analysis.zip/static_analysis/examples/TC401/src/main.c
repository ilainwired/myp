void TC401_low(void);
void TC401_high(void);
void TC401_middle(void);
int main(void) { TC401_low(); TC401_middle(); TC401_high(); return 0; }
