void TC208_low(void);
void TC208_high(void);
int main(void) { TC208_low();  TC208_high(); return 0; }
