#define N (1u<<4)
#define LAST (N-1)
int TC208_g[N]; void TC208_low(void){TC208_g[LAST]=1;} void TC208_high(void){TC208_g[15]=2;}
