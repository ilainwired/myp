int TC107_low(void);
int TC107_high(void);
int main(void) { TC107_low();  TC107_high(); return 0; }
