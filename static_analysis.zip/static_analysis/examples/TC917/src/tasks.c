struct S16 {int value[2];};
struct S15 {struct S16 child;};
struct S14 {struct S15 child;};
struct S13 {struct S14 child;};
struct S12 {struct S13 child;};
struct S11 {struct S12 child;};
struct S10 {struct S11 child;};
struct S9 {struct S10 child;};
struct S8 {struct S9 child;};
struct S7 {struct S8 child;};
struct S6 {struct S7 child;};
struct S5 {struct S6 child;};
struct S4 {struct S5 child;};
struct S3 {struct S4 child;};
struct S2 {struct S3 child;};
struct S1 {struct S2 child;};
struct S1 TC917_g;void TC917_low(void){TC917_g.child.child.child.child.child.child.child.child.child.child.child.child.child.child.child.value[1]=1;} void TC917_high(void){TC917_g.child.child.child.child.child.child.child.child.child.child.child.child.child.child.child.value[1]=2;}
