void TC917_low(void);
void TC917_high(void);
int main(void) { TC917_low();  TC917_high(); return 0; }
