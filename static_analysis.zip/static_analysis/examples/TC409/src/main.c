int TC409_low(void);
int TC409_high(void);
void TC409_middle(void);
int main(void) { TC409_low(); TC409_middle(); TC409_high(); return 0; }
