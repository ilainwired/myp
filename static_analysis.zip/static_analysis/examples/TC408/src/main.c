void TC408_low(void);
void TC408_high(void);
void TC408_middle(void);
int main(void) { TC408_low(); TC408_middle(); TC408_high(); return 0; }
