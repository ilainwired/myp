#include "SchM_Test.h"
int TC912_g; void TC912_low(void){SchM_Enter_Test_A();TC912_g=1;SchM_Exit_Test_A();} void TC912_high(void){TC912_g=2;}
