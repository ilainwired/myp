void TC912_low(void);
void TC912_high(void);
int main(void) { TC912_low();  TC912_high(); return 0; }
