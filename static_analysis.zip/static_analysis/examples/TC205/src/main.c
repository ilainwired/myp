int TC205_low(void);
void TC205_high(void);
int main(void) { TC205_low();  TC205_high(); return 0; }
