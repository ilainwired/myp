#define TWICE(x) ((x)+(x))
int TC205_g; int TC205_low(void){return TWICE(TC205_g);} void TC205_high(void){TC205_g=1;}
