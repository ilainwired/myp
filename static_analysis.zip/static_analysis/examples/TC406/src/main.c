void TC406_low(void);
void TC406_high(void);
void TC406_middle(void);
int main(void) { TC406_low(); TC406_middle(); TC406_high(); return 0; }
