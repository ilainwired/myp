int TC312_low(void);
void TC312_high(void);
int main(void) { TC312_low();  TC312_high(); return 0; }
