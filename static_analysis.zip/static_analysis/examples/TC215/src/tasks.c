int TC215_g; int TC215_low(void){int a=TC215_g;int b=TC215_g;return a==b;} void TC215_high(void){TC215_g=0;}
