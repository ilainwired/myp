int TC215_low(void);
void TC215_high(void);
int main(void) { TC215_low();  TC215_high(); return 0; }
