void TC905_low(void);
void TC905_high(void);
int main(void) { TC905_low();  TC905_high(); return 0; }
