int TC905_g[4097]; void TC905_low(void){TC905_g[4096]=1;} void TC905_high(void){TC905_g[0]=2;}
