void TC315_low(void);
void TC315_high(void);
int main(void) { TC315_low();  TC315_high(); return 0; }
