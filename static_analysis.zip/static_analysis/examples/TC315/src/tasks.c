#include "SchM_Test.h"
int TC315_g;void TC315_low(void){SchM_Enter_Test_A();SchM_Enter_Test_A();TC315_g=1;SchM_Exit_Test_A();SchM_Exit_Test_A();} void TC315_high(void){TC315_g=2;}
