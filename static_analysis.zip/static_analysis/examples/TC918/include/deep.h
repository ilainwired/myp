struct C {int a,b;}; struct B {struct C c[4];}; struct A {struct B b[3];}; extern struct A TC918_g[2];
