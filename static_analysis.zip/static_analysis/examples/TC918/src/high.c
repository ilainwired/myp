#include "deep.h"
#include "SchM_Test.h"
#define SET(x) do{(x).a=1;(x).b=1;}while(0)
void TC918_high(void){SchM_Enter_Test_A();SET(TC918_g[1].b[2].c[3]);SchM_Exit_Test_A();}
