#include "deep.h"
struct A TC918_g[2];
