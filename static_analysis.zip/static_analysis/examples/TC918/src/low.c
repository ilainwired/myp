#include "deep.h"
#include "SchM_Test.h"
static void f32(void){SchM_Enter_Test_A();int a=TC918_g[1].b[2].c[3].a;int b=TC918_g[1].b[2].c[3].b;(void)(a==b);SchM_Exit_Test_A();}
static void f31(void){f32();}
static void f30(void){f31();}
static void f29(void){f30();}
static void f28(void){f29();}
static void f27(void){f28();}
static void f26(void){f27();}
static void f25(void){f26();}
static void f24(void){f25();}
static void f23(void){f24();}
static void f22(void){f23();}
static void f21(void){f22();}
static void f20(void){f21();}
static void f19(void){f20();}
static void f18(void){f19();}
static void f17(void){f18();}
static void f16(void){f17();}
static void f15(void){f16();}
static void f14(void){f15();}
static void f13(void){f14();}
static void f12(void){f13();}
static void f11(void){f12();}
static void f10(void){f11();}
static void f9(void){f10();}
static void f8(void){f9();}
static void f7(void){f8();}
static void f6(void){f7();}
static void f5(void){f6();}
static void f4(void){f5();}
static void f3(void){f4();}
static void f2(void){f3();}
static void f1(void){f2();}
void TC918_low(void){f1();}
