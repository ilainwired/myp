void TC918_low(void);
void TC918_high(void);
int main(void) { TC918_low();  TC918_high(); return 0; }
