#include "SchM_Test.h"
int TC316_g; void TC316_low(void){SchM_Enter_Test_A(); TC316_g=1; SchM_Exit_Test_A();} void TC316_high(void){ TC316_g=2; }