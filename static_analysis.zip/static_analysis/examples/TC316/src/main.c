void TC316_low(void);
void TC316_high(void);
int main(void) { TC316_low();  TC316_high(); return 0; }
