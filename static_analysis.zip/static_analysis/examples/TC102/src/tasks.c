int TC102_g;
int TC102_low(void){int a=TC102_g;int b=TC102_g;return a==b;}
void TC102_high(void){TC102_g=1;}
