int TC102_low(void);
void TC102_high(void);
int main(void) { TC102_low();  TC102_high(); return 0; }
