#include "SchM_Test.h"
int TC314_g;void TC314_low(void){SchM_Enter_Test_A();TC314_g=1;} void TC314_high(void){TC314_g=2;}
