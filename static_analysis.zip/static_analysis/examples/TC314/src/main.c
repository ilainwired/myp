void TC314_low(void);
void TC314_high(void);
int main(void) { TC314_low();  TC314_high(); return 0; }
