void TC213_low(void);
void TC213_high(void);
int main(void) { TC213_low();  TC213_high(); return 0; }
