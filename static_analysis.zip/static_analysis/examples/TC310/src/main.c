int TC310_low(void);
void TC310_high(void);
int main(void) { TC310_low();  TC310_high(); return 0; }
