int TC104_low(void);
void TC104_high(void);
int main(void) { TC104_low();  TC104_high(); return 0; }
