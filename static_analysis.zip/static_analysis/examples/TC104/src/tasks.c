int TC104_g_a,TC104_g_b;
int TC104_low(void){int a=TC104_g_a;int b=TC104_g_b;return a==b;}
void TC104_high(void){TC104_g_a=1;TC104_g_b=1;}
