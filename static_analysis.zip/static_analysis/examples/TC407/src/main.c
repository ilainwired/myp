int TC407_low(void);
void TC407_high(void);
void TC407_middle(void);
int main(void) { TC407_low(); TC407_middle(); TC407_high(); return 0; }
