void TC907_low(void);
void TC907_high(void);
int main(void) { TC907_low();  TC907_high(); return 0; }
