void TC301_low(void);
void TC301_high(void);
int main(void) { TC301_low();  TC301_high(); return 0; }
