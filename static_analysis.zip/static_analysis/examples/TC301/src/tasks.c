#include "SchM_Test.h"
int TC301_g; void TC301_low(void){SchM_Enter_Test_A(); TC301_g=1; SchM_Exit_Test_A();} void TC301_high(void){SchM_Enter_Test_A(); TC301_g=2; SchM_Exit_Test_A();}