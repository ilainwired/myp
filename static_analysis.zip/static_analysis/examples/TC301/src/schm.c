#include "SchM_Test.h"
void SchM_Enter_Test_A(void) { }
void SchM_Exit_Test_A(void) { }
void SchM_Enter_Test_B(void) { }
void SchM_Exit_Test_B(void) { }
