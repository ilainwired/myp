void TC902_low(void);
void TC902_high(void);
int main(void) { TC902_low();  TC902_high(); return 0; }
