int TC211_g_a,TC211_g_b,TC211_g_c; void TC211_low(void){int a=TC211_g_a;int b=TC211_g_b;int c=TC211_g_c;(void)(a==b);(void)(b==c);} void TC211_high(void){TC211_g_a=1;TC211_g_b=1;TC211_g_c=1;}
