void TC211_low(void);
void TC211_high(void);
int main(void) { TC211_low();  TC211_high(); return 0; }
