int TC913_g,TC913_g_flag;void TC913_low(void){if(TC913_g_flag){TC913_g=1;}} void TC913_high(void){TC913_g=2;}
