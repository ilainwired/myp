void TC913_low(void);
void TC913_high(void);
int main(void) { TC913_low();  TC913_high(); return 0; }
