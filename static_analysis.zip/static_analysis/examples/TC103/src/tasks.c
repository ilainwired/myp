int TC103_g;
void TC103_low(void){TC103_g=1;TC103_g=2;}
int TC103_high(void){return TC103_g;}
