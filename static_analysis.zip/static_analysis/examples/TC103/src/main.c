void TC103_low(void);
int TC103_high(void);
int main(void) { TC103_low();  TC103_high(); return 0; }
