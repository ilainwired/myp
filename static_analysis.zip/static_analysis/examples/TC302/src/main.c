int TC302_low(void);
void TC302_high(void);
int main(void) { TC302_low();  TC302_high(); return 0; }
