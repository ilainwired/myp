int TC404_low(void);
void TC404_high(void);
void TC404_middle(void);
int main(void) { TC404_low(); TC404_middle(); TC404_high(); return 0; }
