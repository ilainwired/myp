void TC108_low(void);
void TC108_high(void);
int main(void) { TC108_low();  TC108_high(); return 0; }
