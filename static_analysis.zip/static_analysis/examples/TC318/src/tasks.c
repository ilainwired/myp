#define ENTER() do { SchM_Enter_Test_A(); } while(0)
#define EXIT() do { SchM_Exit_Test_A(); } while(0)
#include "SchM_Test.h"
int TC318_g_a,TC318_g_b; void TC318_low(void){ENTER(); TC318_g_a=1;TC318_g_b=1; EXIT();} void TC318_high(void){ENTER(); TC318_g_a=2;TC318_g_b=2; EXIT();}