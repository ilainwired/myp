void TC318_low(void);
void TC318_high(void);
int main(void) { TC318_low();  TC318_high(); return 0; }
