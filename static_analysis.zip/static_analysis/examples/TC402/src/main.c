int TC402_low(void);
void TC402_high(void);
void TC402_middle(void);
int main(void) { TC402_low(); TC402_middle(); TC402_high(); return 0; }
