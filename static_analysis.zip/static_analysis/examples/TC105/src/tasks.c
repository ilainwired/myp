int TC105_g_a,TC105_g_b;
void TC105_low(void){TC105_g_a=1;TC105_g_b=1;}
int TC105_high(void){int a=TC105_g_a;int b=TC105_g_b;return a==b;}
