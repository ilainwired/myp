void TC105_low(void);
int TC105_high(void);
int main(void) { TC105_low();  TC105_high(); return 0; }
