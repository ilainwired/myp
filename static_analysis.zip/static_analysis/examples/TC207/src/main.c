void TC207_low(void);
void TC207_high(void);
int main(void) { TC207_low();  TC207_high(); return 0; }
