int TC207_g,TC207_g_other; void TC207_low(void){TC207_g=1;} void TC207_high(void){
#if MODE
TC207_g=2;
#else
TC207_g_other=2;
#endif
}
