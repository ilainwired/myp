int TC309_low(void);
void TC309_high(void);
int main(void) { TC309_low();  TC309_high(); return 0; }
