int TC308_low(void);
void TC308_high(void);
int main(void) { TC308_low();  TC308_high(); return 0; }
