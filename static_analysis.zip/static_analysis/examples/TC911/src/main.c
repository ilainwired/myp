void TC911_low(void);
void TC911_high(void);
int main(void) { TC911_low();  TC911_high(); return 0; }
