extern int TC911_g; void TC911_low(void){TC911_g=1;} void TC911_high(void){TC911_g=2;}
