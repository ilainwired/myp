@echo off
setlocal
rem One-time cleanup of exact legacy paths. Safe to run again: missing paths are skipped.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\clean_artifacts.ps1" -Mode Temp %*
exit /b %ERRORLEVEL%
