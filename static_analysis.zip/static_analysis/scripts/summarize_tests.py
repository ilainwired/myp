"""Reproducible test report and code fingerprint, after the tests complete."""
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
import argparse
from project_analysis.common import read_json,write_json,digest


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--root",type=Path,default=Path(__file__).resolve().parents[1])
    args=p.parse_args()
    root=args.root.resolve()
    report=read_json(root/"outputs/project_suite/test_results.json")
    contracts=read_json(root/"outputs/contract_tests/results.json")
    excel=read_json(root/"outputs/deliverables/qa/verification.json")
    if report["passed"]!=report["total"] or not contracts["success"]:
        raise RuntimeError("Cannot freeze code while tests fail")
    analyzed=[c for c in report["cases"] if c["actual"]["status"]=="ANALYZED"]
    total_schedules=sum(c["actual"]["verification"]["scenarios"] for c in analyzed)
    monitor_scenarios=sum(c["actual"]["verification"].get("pair_scenarios",c["actual"]["verification"]["scenarios"]) for c in analyzed)
    total_checks=sum(c["actual"]["verification"]["requirement_checks"] for c in analyzed)
    total_invalid=sum(c["actual"]["verification"]["eva_invalid_expected"] for c in analyzed)
    lines=["# テスト結果とツール成果物の利用記録", "",
        f"実行結果：**{report['passed']}/{report['total']} PASS**。解析完了{len(analyzed)}件、期待した解析停止{report['total']-len(analyzed)}件。",
        f"追加の受渡し・移設試験：{contracts['tests']}件PASS。各テストの人手確認は省略し、本番の人手承認と区別している。", "",
        f"全体の実行順は{total_schedules}シナリオを列挙。3段階はそこから各ペアへ射影し、重複を除いた{monitor_scenarios}件（2段階の配置を含む）のCアクセス監視器をClangで実行してPython判定と照合した。Frama-C Evaは同じモデル上の{total_checks}件の要求checkと整合し、期待したinvalid {total_invalid}件、unknown 0件。invalidは検出対象の違反であり、解析失敗ではない。各モデルの実行時アラームは0。3タスクのスケジューラそのものをC/Evaで証明したという意味ではない。",
        f"元のCは別途、{sum(c['actual']['metrics']['priority_levels'] for c in analyzed)}タスク起点を逐次Eva解析し、実行時アラーム0を確認。これは元Cの並行動作の証明ではない。",
        f"Excelは3冊・{excel['sheets']}シート・{excel['formulas']}数式を再計算し、参照値・エラーを確認。時計回り90度の見出し{excel['clockwise_headers']}セル、グループ結果の横結合{excel['group_merged_results']}箇所を検査。全シートと各プロジェクトの判定ブロックをPNGで目視確認。PNGはPillowによる近似描画で、Excel本体の回転／結合はOOXMLでも検査。PDFは生成しない。", "",
        "## 試験設計", "",
        "最小ケースで規則を分離し、正常対照を置く。次に構文・型・ビルド構成を変えて同じ規則を検証し、SchMの保護全体／部分／分断を比較する。最後に上限値と上限+1、複合上限、未対応構文で『安全の誤判定を出さず停止すること』を確認する。", "",
        "|区分|件数|狙い|", "|---|---:|---|"]
    counts=Counter(c["category"] for c in report["cases"])
    for cat,count in counts.items():lines.append(f"|{cat}|{count}|期待値との一致と証拠保存|")
    lines += ["", "## 何をどこまで試したか", "",
        "|対象|実測範囲|限界の扱い|", "|---|---|---|",
        "|関数呼出し|32段、64段|65段で停止（設定64）|",
        "|配列長|4096要素の末尾|4097要素で停止（設定4096）|",
        "|構造体|16段のネスト、整数型とtypedefのメンバ配列|union/bitfield/匿名メンバは未対応|",
        "|構造体配列|A[2]→B[3]→C[4]→int[2]、48要素|表示[]でも具体添字を保持|",
        "|アクセス回数|下位64回|65回で停止（当該試験の設定64、標準1024）|",
        "|プリプロセッサ|マクロ64段、二重評価、do-while(0)、-D分岐|ビルド変種は別設定で解析|",
        "|複数TU|最大8 TU、extern、同名static、空白パス、別Makefile|取得されたcompile_commands.jsonを使用|",
        "|複合|32段呼出し＋構造体配列＋マクロ＋SchM＋5 TU|TC918|",
        "|低・中・高|3タスク各1回、全3ペア、低→中→高→中→低|SchM中の割込み禁止とペア別AND集約、配置数上限、空タスクを試験|",
        "|同時性グループ|重複所属、4変数グループ、AI候補取下げ|設計意図は推測、人手訂正を入力にする|", "",
        "## 個別結果", "",
        "|ID|試験|期待|実測|検証|証拠|", "|---|---|---|---|---|---|"]
    for c in report["cases"]:
        lines.append(f"|{c['id']}|{c['title']}|{c['expected']['status']}|{c['actual']['status']}|{'PASS' if c['pass'] else 'FAIL'}|[{c['id']}](../project_suite/{c['id']}/status.json)|")
    lines += ["", "## 成果物から判定までの因果関係", "",
        "1. **Make + Bear**：実際のコンパイルコマンドをbuild/compile_commands.jsonへ記録。解析器が手持ちのexample名から対象を選ぶことはない。",
        "2. **Clang**：捕捉した-I/-Dを使いpreprocessed.iを作り、ast.jsonを出力。独自スクリプトが宣言ID・型・式・関数呼出しを読み、externを同一RAMへ、staticをTU別RAMへ統合。配列の具体添字と表示用[]を分離し、R/W・保護・呼出順・元ソース位置をinventory.jsonへ保存。",
        "3. **AI + Clang抽出結果**：比較関係／連続書込みの候補と元コードを読み、同時性グループを推測。単なる同値の書込みを設計要求と断定しない。TC219ではstampとflagを同一グループにする弱い候補を取り下げ、ai_group_decisions.jsonに根拠を保存。これはAIの判断でありFrama-Cがグループを発見したのではない。",
        "4. **Frama-C（元C）**：各起点を-mainに指定して逐次Evaを実行。original_low.log / original_high.logで到達状態・実行時アラームを確認。逐次アラーム0だけでは並行性の安全と判断しない。",
        "5. **独自スクリプト**：01の確認済みCSVを読み、グループの再推測をせず、各タスク1回の実行位置を列挙。3段階はアクティブタスクのスタックで低→中→高の入れ子を表現し、SchM区間中の新たな割込みを禁止。低−中、低−高、中−高へ射影して評価しAND集約。条件1はアクセス所有の規則、2〜6はアクセス窓への介入を検出。",
        "6. **Clang + Frama-C（アクセスモデル）**：判定済みTRUE/FALSEを書き込むのではなく、アクセスIRから独立したC監視器を生成。Clang実行値、Evaの名前付きcheck、Pythonの判定を照合。モデルが共有しているClang抽出IR自体の完全性や元Cとの等価性を証明したわけではない。",
        "7. **AI**：代表例の元コード・AST抽出・ログ・反例時系列を照合し、支持できる結論と未検証範囲を説明。openpyxlでExcel化し、LibreOfficeで数式再計算、結合・回転・参照値を検査。", "",
        "## 代表例", "",
        "|例|Clang成果物の利用|Frama-C成果物の利用|AIの確認と最終結果|", "|---|---|---|---|",
        "|TC205|TWICE(g)の展開後式からgのLValueToRValueを2回抽出|元Cの逐次アラーム0、モデルで条件2のcheckがinvalidとなる割込み位置を確認|見た目のマクロ呼出し1回をR1と誤読せず、R→上位W→Rを説明。条件2 FALSE|",
        "|TC209|4 TUのextern型を結び、48要素中の同一末端要素へのR2/W1を同定|元の構造体アクセスのアラーム0、モデルの条件2を照合|[]表示が全要素の同一視でないことを確認。条件2 FALSE、グループなし|",
        "|TC306|Enter/Wa/Wb/Exitを各タスクから抽出|元Cの空SchM関数のアラーム0とは別に、保護モデルの全check validを確認|連続ペア更新からグループ1を提案。保護前は条件1・6 FALSE、保護後は全条件TRUE。OS実装の証明はしていない|", "",
        "## 未検証・未対応", "",
        "単一コア、優先度の異なる2または3タスク（低・中・高）、各1回、整数の個々のR/Wを不可分とする有限モデル。4タスク以上、マルチコア、複数回起動の値の変化、共有値で変わる分岐・添字、一般ループ、再帰、関数ポインタ、union、bitfield、匿名構造体、可変長配列、aggregate初期化、外部ライブラリ副作用、実機のワード幅とSchM実装は未検証または停止対象。対象ABIはWSL x86_64 LP64。一般プロジェクトへの無条件の安全保証として使わない。", "",
        "## 一次資料", "",
        "- [Clang AST](https://clang.llvm.org/docs/IntroductionToTheClangAST.html)",
        "- [Compilation database](https://clang.llvm.org/docs/JSONCompilationDatabase.html) / [Bear](https://github.com/rizsotto/Bear)",
        "- [Frama-C Eva](https://frama-c.com/fc-plugins/eva.html)",
        "- [AUTOSAR RTE R24-11](https://www.autosar.org/fileadmin/standards/R24-11/CP/AUTOSAR_CP_SWS_RTE.pdf)：名称の参照。本解析の保護効果はユーザー指定モデルであり、仕様全体の実装証明ではない。", ""]
    output=root/"outputs/deliverables"
    (output/"テスト結果.md").write_text("\n".join(lines),encoding="utf-8")
    frozen={}
    for directory in (root/"scripts",root/"tests",root/"examples"):
        for path in directory.rglob("*"):
            if not path.is_file() or any(p in {".build","__pycache__"} for p in path.parts):continue
            if path.name in {"build_explanation.py","render_presentation.py"}:continue
            frozen[path.relative_to(root).as_posix()]=digest(path)
    write_json(output/"code_freeze.json",{"time_utc":datetime.now(timezone.utc).isoformat(),"files":frozen,
        "tests_passed":report["passed"],"contract_tests":contracts["tests"],"schedules":total_schedules,"checks":total_checks,
        "note":"Analysis, tests and Excel code frozen before creating the explanation deck. Deck-only scripts are excluded."})
    print(f"Report and freeze saved: {len(frozen)} files; {total_schedules} schedules; {total_checks} checks")


if __name__=="__main__":main()
