import argparse
from pathlib import Path
from project_analysis.common import load_project, read_json
from project_analysis.workbooks import report_projects, coverage_book


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--configs",nargs="*",type=Path)
    p.add_argument("--suite",type=Path)
    p.add_argument("--suite-root",type=Path)
    p.add_argument("--output",type=Path,required=True)
    args=p.parse_args()
    configs=list(args.configs or [])
    report=None
    if args.suite:
        report=read_json(args.suite)
        if not args.suite_root:
            p.error("--suite requires --suite-root")
        configs += [args.suite_root/c["config"] for c in report["cases"]]
    if not configs:
        p.error("at least one --configs or --suite is required")
    report_projects([load_project(c) for c in configs],args.output)
    if report:
        coverage_book(report,args.output)
    print("Excel written:",args.output)


if __name__=="__main__":
    main()
