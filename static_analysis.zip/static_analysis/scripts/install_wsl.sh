#!/usr/bin/env bash
# Run inside Ubuntu WSL. Installs the CLI and the reporting/verification tools.
set -euo pipefail
sudo apt-get update
sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    clang gcc make bear curl python3 python3-openpyxl python3-pil fonts-noto-cjk \
    libreoffice-calc libreoffice-impress python3-uno nodejs npm
if ! command -v frama-c >/dev/null 2>&1; then
    task_install_dir="$HOME/static-analysis-tools"
    mkdir -p "$task_install_dir"
    curl -fL --retry 2 https://frama-c.com/download/frama-c-linux-x86-64-33.0-Arsenic.run \
        -o "$task_install_dir/frama-c.run"
    # Official installer prompts once. Its WSL GUI AppArmor step may fail after
    # installing the CLI; accept that only if the CLI actually reports a version.
    printf 'y\n' | sudo sh "$task_install_dir/frama-c.run" --nox11 --noprogress -- --prefix /opt || {
        if ! frama-c -version; then exit 1; fi
    }
fi
clang --version
frama-c -version
python3 -c 'import openpyxl; print("openpyxl", openpyxl.__version__)'
libreoffice --version
