"""Generic project entry point. No example directories or test expectations."""
import argparse
import sys
from pathlib import Path

from clang_access import Unsupported
from project_analysis.common import AnalysisBlocked, load_project, write_json
from project_analysis.pipeline import stage01, stage02


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["01", "02", "test"])
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--ram-csv", type=Path)
    parser.add_argument("--review", type=Path)
    parser.add_argument("--test-mode", action="store_true")
    args = parser.parse_args()
    config = None
    try:
        config = load_project(args.config)
        if args.stage in {"01", "test"}:
            stage01(config)
        if args.stage in {"02", "test"}:
            stage02(config, args.ram_csv, args.review, args.test_mode or args.stage == "test")
        write_json(config["_out"] / "status.json", {"status": "ANALYZED" if args.stage != "01" else "STAGE01_READY"})
        print(config["project_id"], "OK", config["_out"])
        return 0
    except (AnalysisBlocked, Unsupported, OSError, KeyError, ValueError, RecursionError) as error:
        if config:
            (config["_out"] / "stage02/results.json").unlink(missing_ok=True)
            write_json(config["_out"] / "status.json", {"status": "BLOCKED", "reason": str(error)})
        print("BLOCKED:", error, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
