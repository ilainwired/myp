from __future__ import annotations

from collections import Counter
import re

from clang_access import Address, Extractor, Returned, Unsupported, Value


class ProjectExtractor(Extractor):
    def __init__(self, ast, aliases, config):
        self.config, self.limits = config, config["limits"]
        self.api = {}
        self.areas = {}
        for area in config["exclusive_areas"]:
            if area["id"] in self.areas:
                raise Unsupported("invalid or duplicate exclusive-area configuration")
            self.areas[area["id"]] = area
            for mode in ("enter", "exit"):
                if area[mode] in self.api:
                    raise Unsupported("SchM API mapped more than once")
                self.api[area[mode]] = (mode, area["id"])
        super().__init__(ast, "", "")
        self.globals.update(aliases)

    def expand_type(self, path, qtype, node, initial=0):
        if len(self.object_types) >= self.limits["storage_locations"]:
            raise Unsupported("storage_locations limit exceeded")
        return super().expand_type(path, qtype, node, initial)

    def location(self, node):
        return node["_site"]["line"]

    def global_info(self):
        return [{"id": name, "name": name.split("::")[-1], "file": node["_site"]["file"],
                 "line": node["_site"]["line"], "declaration_type": node["type"]["qualType"],
                 "element_count": sum(display == name for display in self.display_names.values())}
                for name, node in self.names.items()]

    def extract_task(self, task):
        self.lock_stack, self.lock_serial, self.steps = [], 0, []
        self.max_depth = 0
        self.task = task
        result = super().extract(task["entry"])
        if self.lock_stack:
            raise Unsupported("SchM_Enter without matching Exit at task return")
        result.update({"id": task["id"], "priority": task["priority"], "steps": self.steps,
                       "max_call_depth": self.max_depth})
        return result

    def access(self, key, mode, node, value):
        if not key.startswith("global:"):
            return
        if key not in self.display_names:
            raise Unsupported("whole aggregate access is not lowered")
        if len(self.events) >= self.limits["events_per_task"]:
            raise Unsupported("events_per_task limit exceeded")
        event = {"kind": "access", "index": len(self.events) + 1,
                 "ram": self.display_names[key], "object": key[7:], "mode": mode,
                 "function": self.stack[-1], "call_path": list(self.stack),
                 "locks": [dict(lock) for lock in self.lock_stack],
                 "value": value.data if isinstance(value.data, int) else None, **node["_site"]}
        self.events.append(event)
        self.trace.append(event)
        self.steps.append(event)

    def call(self, name, args, callsite):
        if name in self.api:
            if args:
                raise Unsupported("configured SchM APIs must have no arguments")
            mode, area = self.api[name]
            if mode == "enter":
                if any(lock["area"] == area for lock in self.lock_stack):
                    raise Unsupported("same exclusive area entered recursively")
                self.lock_serial += 1
                self.lock_stack.append({"area": area, "instance": self.lock_serial})
            else:
                if not self.lock_stack or self.lock_stack[-1]["area"] != area:
                    raise Unsupported("SchM_Exit order or area mismatch")
                self.lock_stack.pop()
            step = {"kind": mode, "area": area, "function": name,
                    "call_path": list(self.stack), **callsite["_site"]}
            self.steps.append(step)
            self.trace.append(step)
            return Value(None)
        if re.match(r"Sch[Mm]_(Enter|Exit)", name) and name not in self.api:
            raise Unsupported("SchM API has no declared contract: " + name)
        if len(self.stack) > self.limits["call_depth"]:
            raise Unsupported("call_depth limit exceeded")
        self.max_depth = max(self.max_depth, len(self.stack))
        return super().call(name, args, callsite)

    def expr(self, node):
        kind, inner = node["kind"], node.get("inner", [])
        if kind == "CallExpr":
            callee = inner[0]
            while callee["kind"] in {"ImplicitCastExpr", "ParenExpr"}:
                callee = callee["inner"][0]
            if callee["kind"] != "DeclRefExpr" or callee["referencedDecl"]["kind"] != "FunctionDecl":
                raise Unsupported("indirect function call")
            before = len(self.events)
            args = [self.expr(arg) for arg in inner[1:]]
            accesses = self.events[before:]
            if len(accesses) > 1 and not (all(e["mode"] == "R" for e in accesses) and len({e["object"] for e in accesses}) == 1):
                raise Unsupported("unsequenced shared accesses in call arguments")
            return self.call(callee["referencedDecl"]["name"], args, node)
        if kind in {"CStyleCastExpr", "ImplicitCastExpr"} and node.get("castKind") in {"IntegralCast", "IntegralToBoolean"}:
            return self.convert(self.expr(inner[0]), node["type"]["qualType"])
        if kind == "CStyleCastExpr" and node.get("castKind") in {"ToVoid", "NoOp"}:
            return self.expr(inner[0])
        if kind == "UnaryOperator" and node["opcode"] in {"-", "+", "!", "~"}:
            value = self.expr(inner[0])
            if not isinstance(value.data, int):
                raise Unsupported("noninteger unary arithmetic")
            data = {"-": lambda: -value.data, "+": lambda: value.data,
                    "!": lambda: int(not value.data), "~": lambda: ~value.data}[node["opcode"]]()
            return Value(data, value.sources)
        if kind == "UnaryOperator" and node["opcode"] in {"++", "--"}:
            key = self.lvalue(inner[0])
            old = self.read(key, inner[0])
            value = self.convert(Value(old.data + (1 if node["opcode"] == "++" else -1), old.sources), node["type"]["qualType"])
            self.memory[key] = value
            self.access(key, "W", inner[0], value)
            return old if node.get("isPostfix") else value
        if kind == "CompoundAssignOperator":
            if node["opcode"] not in {"+=", "-="}:
                raise Unsupported("compound assignment operator is unsupported")
            key = self.lvalue(inner[0])
            a, b = self.read(key, inner[0]), self.expr(inner[1])
            value = self.convert(Value(a.data + b.data if node["opcode"] == "+=" else a.data - b.data, a.sources | b.sources), node["type"]["qualType"])
            self.memory[key] = value
            self.access(key, "W", inner[0], value)
            return value
        if kind == "BinaryOperator" and node["opcode"] in {"+", "-", "*", "<", "<=", ">", ">=", "!=", "&", "|", "^", "<<", ","}:
            a, b = self.expr(inner[0]), self.expr(inner[1])
            if node["opcode"] == ",":
                return b
            if not isinstance(a.data, int) or not isinstance(b.data, int):
                raise Unsupported("unresolved integer expression")
            op = node["opcode"]
            operations = {"+": lambda: a.data + b.data, "-": lambda: a.data - b.data,
                          "*": lambda: a.data * b.data, "<": lambda: int(a.data < b.data),
                          "<=": lambda: int(a.data <= b.data), ">": lambda: int(a.data > b.data),
                          ">=": lambda: int(a.data >= b.data), "!=": lambda: int(a.data != b.data),
                          "&": lambda: a.data & b.data, "|": lambda: a.data | b.data,
                          "^": lambda: a.data ^ b.data, "<<": lambda: a.data << b.data}
            return Value(operations[op](), a.sources | b.sources)
        return super().expr(node)

    def convert(self, value, qtype):
        qtype = self.canonical_type(qtype)
        if qtype not in self.INTEGER_TYPES or not isinstance(value.data, int):
            raise Unsupported("unsupported integer conversion: " + qtype)
        if qtype == "_Bool":
            return Value(int(bool(value.data)), value.sources)
        bits = 8 if "char" in qtype else 16 if "short" in qtype else 64 if "long" in qtype else 32
        number = value.data % (1 << bits)
        if "unsigned" not in qtype and number >= (1 << (bits-1)):
            number -= 1 << bits
        return Value(number, value.sources)

    def ordered_expression(self, node, action):
        before = len(self.events)
        value = action()
        events = self.events[before:]
        if len(events) > 1 and not (all(e["mode"] == "R" for e in events) and len({e["object"] for e in events}) == 1):
            if node["kind"] not in {"CompoundAssignOperator", "UnaryOperator", "CallExpr"} and node.get("opcode") != ",":
                raise Unsupported("multiple shared accesses with unresolved expression sequencing")
        return value

    def statement(self, node):
        kind, inner = node["kind"], node.get("inner", [])
        if kind == "CompoundStmt":
            for child in inner:
                self.statement(child)
        elif kind == "DoStmt":
            condition = self.expr(inner[-1])
            if condition.sources or condition.data != 0:
                raise Unsupported("only do-while(0) macro wrappers are supported")
            self.statement(inner[0])
        elif kind == "IfStmt":
            condition = self.expr(inner[0])
            if condition.sources or not isinstance(condition.data, int):
                raise Unsupported("shared-state branch requires path-sensitive analysis")
            if condition.data:
                self.statement(inner[1])
            elif len(inner) > 2:
                self.statement(inner[2])
        elif kind == "DeclStmt":
            for decl in inner:
                if decl["kind"] != "VarDecl" or decl.get("storageClass") == "static":
                    raise Unsupported("unsupported local declaration")
                qtype = decl["type"]["qualType"]
                if self.canonical_type(qtype) not in self.INTEGER_TYPES and not re.fullmatch(r"(?:struct \w+|\w+) \*{1,2}", qtype):
                    raise Unsupported("unsupported local type: " + qtype)
                key = f"local:{self.next_frame}:{decl['id']}"
                self.frames[-1][decl["id"]] = key
                self.memory[key] = self.ordered_expression(decl["inner"][-1], lambda: self.expr(decl["inner"][-1])) if decl.get("inner") else Value(None)
        elif kind == "ReturnStmt":
            value = self.ordered_expression(inner[0], lambda: self.expr(inner[0])) if inner else Value(None)
            raise Returned(value)
        elif kind in {"BinaryOperator", "CompoundAssignOperator", "UnaryOperator", "CallExpr", "CStyleCastExpr", "ParenExpr"}:
            self.ordered_expression(node, lambda: self.expr(node))
        elif kind == "NullStmt":
            pass
        else:
            raise Unsupported("unsupported statement: " + kind)
