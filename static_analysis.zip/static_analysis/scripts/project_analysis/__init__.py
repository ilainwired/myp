"""Configuration-driven, bounded analysis of C projects."""
