"""Three fixed-priority tasks, each activated once; nested preemption is explicit."""
from copy import deepcopy
import json

from .common import AnalysisBlocked
from .rules import analyze, evaluate_schedule


def enumerate_three(tasks, limit):
    result=[]
    # index=-1 means not activated; an active task is the top of the stack.
    def visit(positions, stack, depths, trace):
        while stack and positions[stack[-1]]==len(tasks[stack[-1]]["steps"]):
            stack=stack[:-1]
        if not stack and all(p>=0 for p in positions):
            if len(result)>=limit:
                raise AnalysisBlocked("schedules limit exceeded for three-task interleavings")
            result.append({"id":len(result),"timeline":trace})
            return
        current=stack[-1] if stack else None
        # An unactivated higher-priority task can start before the next step,
        # except inside any designated protected interval of the current task.
        if current is None or depths[current]==0:
            for i in range(len(tasks)):
                if positions[i]==-1 and (current is None or tasks[i]["priority"]>tasks[current]["priority"]):
                    nxt=list(positions);nxt[i]=0
                    visit(nxt,stack+[i],list(depths),trace)
        if current is not None:
            step=tasks[current]["steps"][positions[current]]
            nxt=list(positions);nxt[current]+=1
            locks=list(depths)
            locks[current]+=1 if step["kind"]=="enter" else -1 if step["kind"]=="exit" else 0
            visit(nxt,list(stack),locks,trace+[{"task":tasks[current]["id"],**step}])
    visit([-1]*3,[],[0]*3,[])
    # Empty task activations can have identical event projections.
    unique={}
    for schedule in result:
        key=json.dumps(schedule["timeline"],sort_keys=True)
        unique.setdefault(key,schedule)
    return [{**s,"id":i} for i,s in enumerate(unique.values())]


def analyze_three(tasks, inventory, groups, limit):
    timelines=enumerate_three(tasks,limit)
    pairs=[]
    for li,hi in [(0,1),(0,2),(1,2)]:
        lower,higher=tasks[li],tasks[hi]
        pair=analyze([lower,higher],inventory,groups,limit)
        pair.update({"id":lower["id"]+"__"+higher["id"],"lower":lower["id"],"higher":higher["id"]})
        projected={}
        for timeline in timelines:
            events=[{**e,"task":"low" if e["task"]==lower["id"] else "high"} for e in timeline["timeline"] if e["task"] in {lower["id"],higher["id"]}]
            key=json.dumps(events,sort_keys=True)
            if key not in projected:
                sequence={"id":len(projected),"project_schedule":timeline["id"],"timeline":events}
                sequence["violations"],_=evaluate_schedule(lower,higher,inventory,groups,sequence)
                projected[key]=sequence
        pair["schedules"]=list(projected.values())
        pair["final_schedule_count"]=len(projected)
        # An independent pair calculation and all legal three-task projections
        # must give the same binary requirements for these fixed access paths.
        for ram in pair["ram"]:
            failed={rule for s in pair["schedules"] for rule in s["violations"][ram["id"]]}
            if ram["final"] != [i not in failed for i in range(1,7)]:
                raise AnalysisBlocked("pair and three-task projection results disagree")
            ram["witnesses"]={str(r):next(s["id"] for s in pair["schedules"] if r in s["violations"][ram["id"]]) for r in failed}
        pairs.append(pair)
    result={"groups":groups,"pairs":pairs,"schedules":timelines,"final_schedule_count":len(timelines),
            "raw_schedule_count":sum(p["raw_schedule_count"] for p in pairs),"ram":[],"group_results":[],
            "task_order":[t["id"] for t in tasks],"model":"three tasks, one activation each, nested priority preemption"}
    for i,ram in enumerate(inventory):
        row=deepcopy(pairs[0]["ram"][i])
        for mode in ("raw","final"):
            row[mode]=[all(pair["ram"][i][mode][r] for pair in pairs) for r in range(6)]
        row["witnesses"]={str(r+1):{"pair":p["id"],"pair_scenario":p["ram"][i]["witnesses"][str(r+1)]}
                          for r in range(6) for p in pairs if not p["ram"][i]["final"][r]}
        result["ram"].append(row)
    for i,group in enumerate(groups):
        result["group_results"].append({**group,**{mode:[all(p["group_results"][i][mode][r] for p in pairs) for r in range(3)] for mode in ("raw","final")}})
    for schedule in timelines:
        merged={r["id"]:set() for r in inventory}
        for li,hi in [(0,1),(0,2),(1,2)]:
            low,high=tasks[li],tasks[hi]
            projection={"timeline":[{**e,"task":"low" if e["task"]==low["id"] else "high"} for e in schedule["timeline"] if e["task"] in {low["id"],high["id"]}]}
            failed,_=evaluate_schedule(low,high,inventory,groups,projection)
            for ram,rules in failed.items():merged[ram].update(rules)
        schedule["violations"]={ram:sorted(rules) for ram,rules in merged.items()}
    return result
