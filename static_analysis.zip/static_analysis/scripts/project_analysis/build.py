"""Capture a real Make build and preprocess each captured translation unit."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import re
import shlex

from .common import AnalysisBlocked, command, digest, read_json, write_json


def compiler_flags(entry):
    args = entry.get("arguments") or shlex.split(entry["command"])
    cwd = Path(entry["directory"])
    source = (cwd / entry["file"]).resolve()
    flags, i = [], 1
    while i < len(args):
        arg = args[i]
        if arg in {"-o", "-MF", "-MT", "-MQ", "-MJ"}:
            i += 2
            continue
        if arg in {"-c", "-MD", "-MMD", "-MP", "-MG"}:
            i += 1
            continue
        if not arg.startswith("-") and (cwd / arg).resolve() == source:
            i += 1
            continue
        if arg.startswith(("-o", "-MF", "-MT", "-MQ", "-MJ")):
            i += 1
            continue
        flags.append(arg)
        i += 1
    return cwd, source, flags


class SourceMap:
    def __init__(self, path, root, cwd):
        self.path, self.root = Path(path), Path(root)
        self.cwd, self.cache = Path(cwd), {}
        self.data = self.path.read_bytes()
        self.rows, offset, source_line, source_file = [], 0, 1, str(path)
        for raw in self.data.splitlines(keepends=True):
            line = raw.decode("utf-8")
            marker = re.match(r'^#\s+(\d+)\s+"([^"]+)"', line)
            if marker:
                source_line, source_file = int(marker[1]), marker[2]
            else:
                self.rows.append((offset, source_file, source_line, line.strip()))
                source_line += 1
            offset += len(raw)
        self.starts = [row[0] for row in self.rows]

    def site(self, offset):
        import bisect
        index = max(0, bisect.bisect_right(self.starts, offset) - 1)
        _, filename, line, expanded = self.rows[index]
        path = Path(filename)
        if not path.is_absolute():
            path = self.cwd / path
        try:
            filename = path.resolve().relative_to(self.root).as_posix()
        except ValueError:
            filename = path.as_posix()
        original = expanded
        if path.is_file():
            if path not in self.cache:
                self.cache[path] = path.read_text(encoding="utf-8").splitlines()
            lines = self.cache[path]
            if 0 < line <= len(lines):
                original = lines[line - 1].strip()
        return {"file": filename, "line": line, "source": original, "expanded": expanded}


def capture(config):
    out, root = config["_out"], config["_root"]
    out.mkdir(parents=True, exist_ok=True)
    database = out / "build/compile_commands.json"
    database.parent.mkdir(parents=True, exist_ok=True)
    build = config["build"]
    argv = ["bear", "--output", str(database), "--", "make", "-B", "-f", str(config["_makefile"]), build.get("target", "all")]
    argv.extend(build.get("variables", []))
    command(argv, config["_build_dir"], out / "build/make.log")
    entries = read_json(database)
    if not entries:
        raise AnalysisBlocked("Make build produced no captured compilation commands")
    units, seen, inputs = [], {}, {str(config["_config"]): digest(config["_config"])}
    for i, entry in enumerate(entries):
        cwd, source, flags = compiler_flags(entry)
        if any(f in {"-m32", "-funsigned-char", "-fshort-enums", "-fshort-wchar", "-target", "--target"} or f.startswith(("--target=", "-march=", "-mcpu=")) for f in flags):
            raise AnalysisBlocked("target/ABI-changing flags need an explicit data model; supported target is x86_64 LP64")
        if source.suffix.lower() != ".c":
            raise AnalysisBlocked("only C translation units are supported")
        if source in seen:
            if flags != seen[source]:
                raise AnalysisBlocked("multiple build variants for one source require separate project configs")
            continue
        seen[source] = flags
        directory = out / "clang" / f"tu_{i:03d}"
        directory.mkdir(parents=True, exist_ok=True)
        pp = directory / "preprocessed.i"
        pre = command(["clang", *flags, "-E", str(source), "-o", str(pp)], cwd, directory / "preprocess.log")
        # Preserve line markers for original file/line attribution, including macro call sites.
        ast = command(["clang", "-std=c11", "-fsyntax-only", "-Xclang", "-ast-dump=json", str(pp)], cwd, directory / "ast.log")
        ast_path = directory / "ast.json"
        ast_path.write_text(ast.stdout, encoding="utf-8")
        smap = SourceMap(pp, root, cwd)
        for _, file, _, _ in smap.rows:
            dependency = Path(file)
            if not dependency.is_absolute():
                dependency = cwd / dependency
            if dependency.is_file():
                inputs[str(dependency.resolve())] = digest(dependency)
        units.append({"tu": source.relative_to(root).as_posix(), "ast": json.loads(ast.stdout),
                      "map": smap, "preprocessed": pp, "artifact": str(ast_path.relative_to(out)), "flags": flags})
    for pattern in ("*Makefile*", "*.mk"):
        for path in root.rglob(pattern):
            if path.is_file():
                inputs[str(path.resolve())] = digest(path)
    write_json(out / "build/inputs.json", inputs)
    write_json(out / "build/units.json", [{k: str(v) if isinstance(v, Path) else v for k, v in unit.items() if k not in {"ast", "map"}} for unit in units])
    return units, inputs


def link_ast(units):
    """Link external symbol identities; namespace TU-private names and types."""
    merged = {"kind": "TranslationUnitDecl", "inner": []}
    global_aliases, definitions = {}, {}
    for ui, unit in enumerate(units):
        ast = copy.deepcopy(unit["ast"])
        nodes = ast["inner"]
        private = {n["name"] for n in nodes if n.get("name") and n.get("storageClass") == "static" and n["kind"] in {"VarDecl", "FunctionDecl"}}
        rename = {name: unit["tu"] + "::" + name for name in private}
        types = {}
        for node in nodes:
            if node["kind"] in {"RecordDecl", "TypedefDecl"} and node.get("name") and not node.get("isImplicit"):
                types[node["name"]] = f"TU{ui}_{node['name']}"

        def walk(node):
            if not isinstance(node, dict):
                return
            if "id" in node:
                node["id"] = f"tu{ui}:{node['id']}"
            if node.get("kind") in {"VarDecl", "FunctionDecl"} and node.get("name") in rename:
                node["name"] = rename[node["name"]]
            if node.get("kind") in {"RecordDecl", "TypedefDecl"} and node.get("name") in types:
                node["name"] = types[node["name"]]
            if "qualType" in node:
                for key in ("qualType", "desugaredQualType"):
                    if key in node:
                        for old, new in types.items():
                            node[key] = re.sub(r"\b" + re.escape(old) + r"\b", new, node[key])
            if node.get("range", {}).get("begin", {}).get("offset") is not None:
                node["_site"] = unit["map"].site(node["range"]["begin"]["offset"])
                node["_site"]["translation_unit"] = unit["tu"]
                node["_site"]["ast"] = unit["artifact"]
            for key, value in list(node.items()):
                if key.startswith("_"):
                    continue
                if isinstance(value, dict):
                    walk(value)
                elif isinstance(value, list):
                    for child in value:
                        walk(child)

        walk(ast)
        for node in ast["inner"]:
            if node["kind"] == "VarDecl":
                global_aliases[node["id"]] = node["name"]
                if node.get("storageClass") == "extern":
                    continue
                if node["name"] in definitions:
                    raise AnalysisBlocked("multiple global definitions: " + node["name"])
                definitions[node["name"]] = node
            merged["inner"].append(node)
    missing = set(global_aliases.values()) - set(definitions)
    if missing:
        raise AnalysisBlocked("extern has no definition: " + ", ".join(sorted(missing)))
    return merged, global_aliases
