from pathlib import Path
import shutil
import subprocess

from .build import capture, link_ast
from .common import AnalysisBlocked, digest, read_json, write_json
from .extract import ProjectExtractor
from .evidence import original_eva, verify_model
from .rules import analyze, propose_groups, write_ram, read_ram
from .multitask import analyze_three


def stage01(config):
    out = config["_out"]
    # Never leave a previous successful verdict beside a new failed run.
    for name in ("stage01/inventory.json", "stage01/ai_group_decisions.json", "stage02/results.json"):
        (out / name).unlink(missing_ok=True)
    units, inputs = capture(config)
    ast, aliases = link_ast(units)
    extractor = ProjectExtractor(ast, aliases, config)
    inventory = extractor.global_info()
    tasks = [extractor.extract_task(t) for t in config["_tasks"]]
    evidence = original_eva(config, units)
    groups = propose_groups(tasks)
    target = out / "stage01"
    target.mkdir(parents=True, exist_ok=True)
    data = {"schema_version": 2, "project_id": config["project_id"], "inventory": inventory,
            "tasks": tasks, "inputs": inputs, "original_eva": evidence,
            "metrics": {"ram_count": len(inventory), "group_count": len(groups),
                "translation_units": len(units), "storage_elements": len(extractor.initial),
                "max_call_depth": max(t["max_call_depth"] for t in tasks),
                "low_accesses": len(tasks[0]["events"]), "high_accesses": len(tasks[-1]["events"]),
                "priority_levels": len(tasks), "middle_accesses": len(tasks[1]["events"]) if len(tasks)==3 else 0}}
    write_json(target / "group_proposals.json", {"status": "AI_REVIEW_REQUIRED", "groups": groups,
               "note": "Deterministic code heuristics are inputs to the AI review, not proof of design intent."})
    if config.get("ai_group_decisions"):
        decisions_path = (config["_config"].parent / config["ai_group_decisions"]).resolve()
        decisions = read_json(decisions_path)
        if not decisions.get("reason") or not decisions.get("author"):
            raise AnalysisBlocked("AI group decisions require author and reason")
        groups = decisions["groups"]
        ids = {r["id"] for r in inventory}
        if any(not set(g["members"]) <= ids for g in groups):
            raise AnalysisBlocked("AI group decisions include unknown RAM")
        inputs[str(decisions_path)] = digest(decisions_path)
        write_json(target / "ai_group_decisions.json", decisions)
    data["metrics"]["group_count"] = len(groups)
    write_json(target / "inventory.json", data)
    write_ram(target / "RAM一覧.csv", inventory, groups)
    write_json(target / "human_review_template.json", {"approved": False, "reviewer": "", "reviewed_at": "",
               "ram_csv_sha256": "", "inventory_sha256": digest(target / "inventory.json")})
    versions = {}
    for tool, flag in [("clang", "--version"), ("frama-c", "-version"), ("bear", "--version"), ("make", "--version")]:
        versions[tool] = subprocess.check_output([tool, flag], text=True).splitlines()[0]
    write_json(out / "tool_versions.json", versions)
    return data


def stage02(config, csv_path=None, review=None, test_mode=False):
    out = config["_out"]
    target = out / "stage02"
    target.mkdir(parents=True, exist_ok=True)
    (target / "results.json").unlink(missing_ok=True)
    inventory_path = out / "stage01/inventory.json"
    data = read_json(inventory_path)
    for name, sha in data["inputs"].items():
        if not Path(name).is_file() or digest(name) != sha:
            raise AnalysisBlocked("stage01 input changed; rerun stage01: " + name)
    if data["project_id"] != config["project_id"] or str(config["_config"]) not in data["inputs"]:
        raise AnalysisBlocked("stage01 belongs to a different project/configuration")
    csv_path = Path(csv_path or out / "stage01/RAM一覧.csv").resolve()
    if test_mode:
        if config.get("purpose") != "test":
            raise AnalysisBlocked("human review may only be skipped for purpose=test")
        review_status = "TEST_HUMAN_REVIEW_SKIPPED"
    else:
        if review is None:
            raise AnalysisBlocked("production stage02 requires the human review JSON")
        approval = read_json(review)
        if approval.get("approved") is not True or not approval.get("reviewer") or not approval.get("reviewed_at"):
            raise AnalysisBlocked("human review is not complete")
        if approval.get("ram_csv_sha256") != digest(csv_path) or approval.get("inventory_sha256") != digest(inventory_path):
            raise AnalysisBlocked("human review hashes do not match inputs")
        review_status = "HUMAN_REVIEWED"
    groups = read_ram(csv_path, data["inventory"])
    evaluator=analyze_three if len(data["tasks"])==3 else analyze
    result = evaluator(data["tasks"], data["inventory"], groups, config["limits"]["schedules"])
    result.update({"schema_version": 2, "project_id": config["project_id"], "status": "ANALYZED",
                   "review_status": review_status, "ram_csv_sha256": digest(csv_path), "metrics": data["metrics"]})
    result["metrics"]["group_count"] = len(groups)
    if len(data["tasks"])==2:
        result["verification"] = verify_model(config, data["tasks"], data["inventory"], result)
    else:
        verified=[]
        by_id={t["id"]:t for t in data["tasks"]}
        for pair in result["pairs"]:
            pair_config={**config,"_out":out/"pairs"/pair["id"]}
            record=verify_model(pair_config,[by_id[pair["lower"]],by_id[pair["higher"]]],data["inventory"],pair)
            pair["verification"]=record
            verified.append(record)
        result["verification"]={"native_matches_python":True,"eva_matches_native":True,"scenarios":len(result["schedules"]),
            "pair_scenarios":sum(v["scenarios"] for v in verified),"requirement_checks":sum(v["requirement_checks"] for v in verified),
            "eva_invalid_expected":sum(v["eva_invalid_expected"] for v in verified),"eva_unknown":0,"runtime_alarms":0,
            "scope":"pair projections of enumerated three-task schedules; not original-source equivalence", "pair_count":3}
    shutil.copyfile(csv_path, target / "RAM一覧_input.csv")
    write_json(target / "results.json", result)
    return result
