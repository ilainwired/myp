"""openpyxl reports. Analysis stays in auditable JSON; Excel cells reference it."""
from pathlib import Path
import textwrap
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter as letter
from openpyxl.formatting.rule import CellIsRule

from .common import read_json, write_json

BLUE = "18344D"
LIGHT = "EAF1F7"
GREEN = "DBEEE1"
RED = "F9DCD8"


def sheet(book, name, headers, widths):
    ws = book.create_sheet(name)
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "B2"
    ws.append(headers)
    for index, width in enumerate(widths, 1):
        ws.column_dimensions[letter(index)].width = width
    for cell in ws[1]:
        cell.fill = PatternFill("solid", fgColor=BLUE)
        cell.font = Font(name="Noto Sans CJK JP", size=10, color="FFFFFF", bold=True)
        cell.alignment = Alignment(wrap_text=True, vertical="center")
    ws.row_dimensions[1].height = 32
    return ws


def finish(book, path):
    for ws in book:
        for row in ws:
            for cell in row:
                if cell.row == 1 or cell.value is None:
                    continue
                if cell.font.name != "Noto Sans CJK JP":
                    cell.font = Font(name="Noto Sans CJK JP", size=10, color="203648")
                if cell.alignment.textRotation != 180:
                    cell.alignment = Alignment(wrap_text=True, vertical="center")
        if ws.title != "判定表":
            ws.auto_filter.ref = ws.dimensions
            for row in range(2, ws.max_row+1):
                ws.row_dimensions[row].height = 48
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.orientation = "landscape"
        ws.page_setup.paperSize = ws.PAPERSIZE_A3
        ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = 1, 0
    path.parent.mkdir(parents=True, exist_ok=True)
    book.save(path)


def report_projects(configs, output):
    output = Path(output)
    first, second = Workbook(), Workbook()
    first.remove(first.active)
    second.remove(second.active)
    guide1 = sheet(first, "確認手順", ["手順", "実施内容"], [26, 100])
    for row in [
        ("状態", "AI推測を含む確認用一覧。テストでは人手確認を省略。"),
        ("01", "AI_Instruction_01.mdに従い、RAM一覧と推測根拠を確認。"),
        ("人手確認", "同時性グループを修正。数字、複数なら1,2、なしは -。配列は[]表記。"),
        ("受渡し", "各プロジェクトのstage01/RAM一覧.csvが02の入力。Excel修正時はimport_ram_review.pyでCSVに戻す。"),
        ("02", "本番は修正CSVのSHA-256とinventory.jsonのSHA-256をreview JSONに記録。"),
        ("入力固定", "02はグループを再推測しない。コード・ヘッダ・設定・Makefile変更時は01をやり直す。")]:
        guide1.append(row)
    ram_ws = sheet(first, "RAM一覧", ["プロジェクト", "ファイル名", "RAM名", "同時性グループ", "具体要素数"], [18, 30, 85, 23, 15])
    proposal_ws = sheet(first, "推測根拠", ["プロジェクト", "候補ID", "メンバ", "信頼度", "根拠／AI判断"], [18, 14, 65, 15, 95])
    guide = sheet(second, "見方", ["項目", "内容"], [29, 110])
    for row in [
        ("TRUE / FALSE", "TRUE=要求を満たす、FALSE=違反。全6条件にSchM保護を反映。対象グループなしの4〜6はTRUE（非該当）。"),
        ("保護の前提", "設定したEnter/Exitは保護キーワード。下位の区間内へ上位は割り込めない。空関数でもこの指定を採用。実OSの排他機構は検証対象外。"),
        ("判定単位", "条件1〜3は具体的な配列要素ごとに評価して[]列へ集約。4〜6はグループ全体。"),
        ("セル結合", "同じグループの条件4、5、6は各行で横結合。重複所属RAMはグループ別ブロックに列を再掲。"),
        ("変数名", "時計回り90度。長い名前は表示上だけ改行。正規RAM名は判定データに保存。"),
        ("アクセス", "呼出順にR1/W1を表示。元ソース位置・マクロ展開後文字列・ASTはアクセス根拠へ。"),
        ("原始性の範囲", "単一コア・2または3タスク（低・中・高）・各1回実行・整数の個々のアクセスを不可分と仮定。一般C全体や実機レースの証明ではない。"),
        ("3段階優先度", "低−中、低−高、中−高の全ペアを評価してAND集約。優先度ペア判定に内訳。3タスクの入れ子割込みを列挙し、ペアへの射影をC/Evaで検証。"),
        ("Frama-C", "元Cの各タスクを逐次Eva解析。別途、抽出アクセスモデルをClangで実行し、EvaのACSL checkとPython判定を照合。"),
        ("AI", "グループ候補の設計意図を推測・修正し、ログと判定の整合をレビュー。ツールが設計意図を証明したとは扱わない。")]:
        guide.append(row)
    matrix = sheet(second, "判定表", ["タスク／判定", "RAM（以下、横方向）"], [63, 13])
    matrix.freeze_panes = "B2"
    raw_ws = sheet(second, "判定データ", ["プロジェクト", "RAM", *[f"保護前{i}" for i in range(1,7)], *[f"最終{i}" for i in range(1,7)]], [18, 76] + [12]*12)
    group_ws = sheet(second, "グループ判定", ["プロジェクト", "グループ", "メンバ", "保護前4", "保護前5", "保護前6", "最終4", "最終5", "最終6"], [18, 15, 75]+[12]*6)
    access_ws = sheet(second, "アクセス根拠", ["プロジェクト", "タスク", "順序", "関数", "RAM", "具体要素", "R/W", "保護Area", "元ソース位置", "元コード", "展開後", "AST"], [18,15,10,40,58,64,9,16,32,80,80,42])
    evidence_ws = sheet(second, "ツール根拠", ["プロジェクト", "確認状態", "TU数", "シナリオ数", "C/Python一致", "Eva/C一致", "チェック数", "証拠ルート"], [18,36,12,18,19,18,18,70])
    pair_ws = sheet(second,"優先度ペア判定",["プロジェクト","下位→上位","RAM",*[f"条件{i}" for i in range(1,7)]],[18,27,76]+[12]*6)
    previews, header_cells, merged_results = [], [], []
    for config in configs:
        out, cid = config["_out"], config["project_id"]
        data_path = out / "stage01/inventory.json"
        if not data_path.exists():
            continue
        data = read_json(data_path)
        import csv
        with (out / "stage01/RAM一覧.csv").open(encoding="utf-8-sig") as handle:
            csv_rows = list(csv.DictReader(handle))
        sizes = {(r["file"],r["name"]):r["element_count"] for r in data["inventory"]}
        for r in csv_rows:
            ram_ws.append([cid,r["ファイル名"],r["RAM名"],r["同時性グループ"],sizes[r["ファイル名"],r["RAM名"]]])
            ram_ws.cell(ram_ws.max_row,4).font = Font(name="Noto Sans CJK JP",size=10,color="0066AA")
        for g in read_json(out / "stage01/group_proposals.json")["groups"]:
            proposal_ws.append([cid,g["id"],", ".join(g["members"]),g["confidence"],g["basis"]])
        decision_path = out / "stage01/ai_group_decisions.json"
        if decision_path.exists():
            decision = read_json(decision_path)
            proposal_ws.append([cid,"AI修正","最終候補はRAM一覧を参照","AI",decision["reason"]])
        result_path = out / "stage02/results.json"
        if not result_path.exists():
            continue
        result = read_json(result_path)
        for pair in result.get("pairs",[{"id":data["tasks"][0]["id"]+"__"+data["tasks"][-1]["id"],"ram":result["ram"]}]):
            for r in pair["ram"]:
                pair_ws.append([cid,pair["id"],r["id"],*r["final"]])
        ram_rows, group_rows = {}, {}
        for r in result["ram"]:
            raw_ws.append([cid,r["id"],*r["raw"],*r["final"]])
            ram_rows[r["id"]] = raw_ws.max_row
        for g in result["group_results"]:
            group_ws.append([cid,g["id"],", ".join(g["members"]),*g["raw"],*g["final"]])
            group_rows[g["id"]] = group_ws.max_row
        columns = [(g["id"],r) for g in result["groups"] for r in g["members"]]
        grouped = {r for _,r in columns}
        columns += [("-",r["id"]) for r in result["ram"] if r["id"] not in grouped]
        top = matrix.max_row + 2
        last = max(2,len(columns)+1)
        matrix.merge_cells(start_row=top,start_column=1,end_row=top,end_column=last)
        title = matrix.cell(top,1,cid + "  |  " + result["review_status"])
        title.fill = PatternFill("solid",fgColor=BLUE)
        title.font = Font(name="Noto Sans CJK JP",size=12,bold=True,color="FFFFFF")
        matrix.row_dimensions[top].height=30
        matrix.cell(top+1,1,"同時性グループ")
        matrix.cell(top+2,1,"RAM名（時計回り90度）")
        longest=max((min(len(ram),65) for _,ram in columns),default=10)
        matrix.row_dimensions[top+2].height=min(390,max(100,longest*5.5+25))
        for offset,(group,ram) in enumerate(columns,2):
            matrix.column_dimensions[letter(offset)].width=13
            matrix.cell(top+1,offset,group)
            cell=matrix.cell(top+2,offset,"\n".join(textwrap.wrap(ram,width=65,break_long_words=True,break_on_hyphens=False)))
            cell.alignment=Alignment(textRotation=180,vertical="center",horizontal="center",wrap_text=True)
            cell.font=Font(name="Noto Sans CJK JP",size=10,color=BLUE)
            cell.fill=PatternFill("solid",fgColor=LIGHT)
            header_cells.append(cell.coordinate)
            for rule in range(1,7):
                row=top+2+rule
                matrix.cell(row,1,"判定条件"+str(rule))
                if rule<=3 or group=="-":
                    matrix.cell(row,offset,f"='判定データ'!{letter(8+rule)}{ram_rows[ram]}")
                else:
                    matrix.cell(row,offset,f"='グループ判定'!{letter(3+rule)}{group_rows[group]}")
                if rule>=4 and group=="-":
                    matrix.cell(row,offset).comment=Comment("非該当：同時性グループ未所属", "AI")
                matrix.row_dimensions[row].height=25
        for g in result["groups"]:
            indices=[i for i,(group,_) in enumerate(columns,2) if group==g["id"]]
            if len(indices)>1:
                for rule in range(4,7):
                    row=top+2+rule
                    matrix.merge_cells(start_row=row,start_column=min(indices),end_row=row,end_column=max(indices))
                    merged_results.append({"project":cid,"group":g["id"],"rule":rule,"range":f"{letter(min(indices))}{row}:{letter(max(indices))}{row}"})
        matrix.conditional_formatting.add(f"B{top+3}:{letter(last)}{top+8}",CellIsRule(operator="equal",formula=["TRUE"],fill=PatternFill("solid",fgColor=GREEN)))
        matrix.conditional_formatting.add(f"B{top+3}:{letter(last)}{top+8}",CellIsRule(operator="equal",formula=["FALSE"],fill=PatternFill("solid",fgColor=RED)))
        guide.append([cid,"判定表へ移動"])
        guide.cell(guide.max_row,2).hyperlink=f"#'判定表'!A{top}"
        previews.append({"project":cid,"sheet":"判定表","min_row":top,"max_row":top+8,"max_col":last})
        matrix.cell(top+10,1,"呼出し／アクセス順")
        for task in data["tasks"]:
            for item in task["trace"]:
                row=matrix.max_row+1
                if item["kind"]=="call":
                    label="  "*min(item["depth"],12)+item["function"]
                    if item["depth"]>12:
                        label=f"[深さ{item['depth']}] "+item["function"]
                    matrix.cell(row,1,label)
                elif item["kind"]=="access":
                    locks=",".join(l["area"] for l in item["locks"]) or "-"
                    matrix.cell(row,1,f"  {task['id']} #{item['index']} {item['file']}:{item['line']} [保護:{locks}]")
                    for ci,(_,ram) in enumerate(columns,2):
                        if ram==item["ram"]:
                            matrix.cell(row,ci,item["mode"]+"1")
                    access_ws.append([cid,task["id"],item["index"],item["function"],item["ram"],item["object"],item["mode"],locks,
                                      f"{item['file']}:{item['line']}",item["source"],item["expanded"],item["ast"]])
                else:
                    matrix.cell(row,1,"  "+item["function"]+"  ["+item["kind"]+"]")
                matrix.row_dimensions[row].height=30
        v=result["verification"]
        evidence_ws.append([cid,result["review_status"],result["metrics"]["translation_units"],v["scenarios"],v["native_matches_python"],v["eva_matches_native"],v["requirement_checks"],str(out)])
    finish(first,output/"01_RAM一覧_人手確認用.xlsx")
    finish(second,output/"02_判定結果.xlsx")
    write_json(output/"excel_layout.json",{"previews":previews,"rotated_headers":header_cells,"merged_results":merged_results})
    return [output/"01_RAM一覧_人手確認用.xlsx",output/"02_判定結果.xlsx"]


def coverage_book(report, output):
    book=Workbook()
    book.remove(book.active)
    ws=sheet(book,"試験結果",["ID","区分","試験内容","検証観点","期待","実測","PASS","理由／差異","TU","RAM","要素数","呼出深さ","シナリオ"],[15,24,34,66,18,18,12,78,10,10,12,14,16])
    for case in report["cases"]:
        actual=case["actual"]
        m=actual.get("metrics",{})
        ws.append([case["id"],case["category"],case["title"],case["purpose"],case["expected"]["status"],actual["status"],case["pass"],
                   "; ".join(case["errors"]) or actual.get("reason", "期待判定と一致"),m.get("translation_units"),m.get("ram_count"),m.get("storage_elements"),m.get("max_call_depth"),actual.get("verification",{}).get("scenarios")])
    summary=sheet(book,"範囲と限界",["項目","内容"],[36,112])
    summary.append(["合格件数",f"=COUNTIF('試験結果'!G2:G{ws.max_row},TRUE)"])
    summary.append(["試験件数",f"=COUNTA('試験結果'!A2:A{ws.max_row})"])
    for row in [
        ("分類", "100台=最小仕様、200台=構成・複合、300台=SchM、400台=低中高、900台=限界・停止。"),
        ("成功の意味", "ANALYZEDは解析完了。FALSE検出も試験の期待どおりならPASS。BLOCKEDは期待した解析停止。"),
        ("実施上限", "呼出深さ64（65停止）、マクロ64段、構造体16段、配列4096（4097停止）、下位64アクセス（設定64、65停止）。"),
        ("複合", "32段呼出し＋A/B/C構造体配列＋SchM＋マクロ＋5 TU。最小6件統合は8 TU。"),
        ("未対応", "共有値依存の分岐・添字、一般ループ、再帰、関数ポインタ、union、bitfield、全C、マルチコア、4タスク以上。黙ってTRUEにせず停止。"),
        ("保証の境界", "整数の各R/Wは不可分と仮定。設計上の同時性グループと実機SchM実装の正しさは人手確認。"),
        ("独立性", "期待値はtest_expectation.json。解析器は読まない。C監視器とPython判定の一致をEvaとネイティブ実行で照合。"),
        ("PDF", "生成しない。Excelの構造・数式・PNGプレビューで確認。")]:
        summary.append(row)
    finish(book,Path(output)/"03_テスト結果.xlsx")
