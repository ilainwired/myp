from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess


class AnalysisBlocked(ValueError):
    pass


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(argv, cwd, log, allow_failure=False, timeout=180):
    result = subprocess.run([str(a) for a in argv], cwd=cwd, text=True, capture_output=True, timeout=timeout)
    log = Path(log)
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(json.dumps({"argv": list(map(str, argv)), "cwd": str(cwd), "exit_code": result.returncode}, ensure_ascii=False)
                   + "\nSTDOUT:\n" + result.stdout + "\nSTDERR:\n" + result.stderr, encoding="utf-8")
    if result.returncode and not allow_failure:
        raise AnalysisBlocked(f"command failed ({result.returncode}): {log.name}")
    return result


def load_project(config_path):
    path = Path(config_path).resolve()
    data = read_json(path)
    if data.get("schema_version") != 2:
        raise AnalysisBlocked("schema_version must be 2")
    data["_config"] = path
    data["_root"] = (path.parent / data["repository"]["path"]).resolve()
    data["_out"] = (path.parent / data["output_directory"]).resolve()
    if not data["_root"].is_dir():
        raise AnalysisBlocked("repository.path must name an existing local checkout")
    build = data["build"]
    data["_build_dir"] = (data["_root"] / build.get("working_directory", ".")).resolve()
    makefile = (data["_build_dir"] / build["makefile"]).resolve()
    if not makefile.is_file():
        raise AnalysisBlocked("configured Makefile does not exist")
    data["_makefile"] = makefile
    entries = data["tasks"]
    if len(entries) not in {2, 3} or len({t["priority"] for t in entries}) != len(entries) or len({t["id"] for t in entries}) != len(entries):
        raise AnalysisBlocked("requires two or three tasks with distinct priorities and IDs")
    data["_tasks"] = sorted(entries, key=lambda t: t["priority"])
    data.setdefault("limits", {})
    for key, value in {"call_depth": 64, "array_extent": 4096, "storage_locations": 20000,
                       "events_per_task": 1024, "schedules": 1100}.items():
        data["limits"].setdefault(key, value)
    data.setdefault("exclusive_areas", [])
    return data
