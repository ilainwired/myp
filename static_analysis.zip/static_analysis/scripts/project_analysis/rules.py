"""Six requirements over explicit, bounded single-core task access traces.

SchM names are configured protection keywords: no high-task execution in a
low-task Enter/Exit interval. This is a user-specified abstraction, not a proof
of the generated OS implementation. Array display names never replace object IDs.
"""
from collections import Counter
import csv
import re

from .common import AnalysisBlocked


def propose_groups(tasks):
    candidates = {}
    for task in tasks:
        for comparison in task["comparison_groups"]:
            members = tuple(comparison["members"])
            candidates.setdefault(members, {"members": list(members), "confidence": "medium",
                "basis": "複数RAM由来の値を比較。設計意図は人手確認が必要。", "evidence": []})["evidence"].append(comparison)
    covered = {r for group in candidates for r in group}
    for task in tasks:
        run = []
        def flush():
            members = tuple(sorted({e["ram"] for e in run}))
            if len(members) > 1 and not set(members) <= covered:
                candidates.setdefault(members, {"members": list(members), "confidence": "low",
                    "basis": "同じ関数で同値を連続して書込む。単なる隣接の可能性があり人手確認が必要。",
                    "evidence": [{"function": run[0]["function"], "line": run[0]["line"]}]})
        for event in task["events"]:
            if event["mode"] != "W" or (run and (event["function"], event["value"]) != (run[-1]["function"], run[-1]["value"])):
                flush()
                run = []
            if event["mode"] == "W":
                run.append(event)
        flush()
    return [{"id": str(i), **candidate} for i, (_, candidate) in enumerate(sorted(candidates.items()), 1)]


def write_ram(path, inventory, groups):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["ファイル名", "RAM名", "同時性グループ"])
        for ram in inventory:
            membership = [g["id"] for g in groups if ram["id"] in g["members"]]
            writer.writerow([ram["file"], ram["name"], ",".join(membership) or "-"])


def read_ram(path, inventory):
    lookup = {(r["file"], r["name"]): r["id"] for r in inventory}
    if len(lookup) != len(inventory):
        raise AnalysisBlocked("RAM file/name identity is not unique")
    groups, seen = {}, set()
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != ["ファイル名", "RAM名", "同時性グループ"]:
            raise AnalysisBlocked("RAM CSV must have the exact three documented columns")
        for row in reader:
            key = (row["ファイル名"], row["RAM名"])
            if key not in lookup or key in seen:
                raise AnalysisBlocked("RAM CSV has unknown or duplicate RAM")
            seen.add(key)
            text = row["同時性グループ"].strip()
            if text != "-":
                if not re.fullmatch(r"[1-9][0-9]*(?:,[1-9][0-9]*)*", text):
                    raise AnalysisBlocked("group IDs must be positive integers separated by commas, or '-'")
                for group in text.split(","):
                    groups.setdefault(group, set()).add(lookup[key])
    if seen != set(lookup):
        raise AnalysisBlocked("RAM CSV is missing inventory rows")
    return [{"id": g, "members": sorted(members)} for g, members in sorted(groups.items(), key=lambda p: int(p[0]))]


def schedules(low, high, limit, protected=True):
    steps = low["steps"]
    legal, depth = [], 0
    for gap in range(len(steps) + 1):
        if not protected or depth == 0:
            legal.append(gap)
        if gap < len(steps):
            depth += 1 if steps[gap]["kind"] == "enter" else -1 if steps[gap]["kind"] == "exit" else 0
    if len(legal) > limit:
        raise AnalysisBlocked("schedules limit exceeded")
    result = []
    for gap in legal:
        trace = [("low", e) for e in steps[:gap]] + [("high", e) for e in high["steps"]] + [("low", e) for e in steps[gap:]]
        result.append({"id": len(result), "low_step_gap": gap,
                       "timeline": [{"task": task, **e} for task, e in trace]})
    return result


def evaluate_schedule(low, high, inventory, groups, schedule, protected=True):
    failed = {r["id"]: set() for r in inventory}
    group_failed = {g["id"]: set() for g in groups}
    for a in low["events"]:
        if a["mode"] == "W" and (not protected or not a["locks"]):
            if any(b["object"] == a["object"] and b["mode"] == "W" for b in high["events"]):
                failed[a["ram"]].add(1)
    total = Counter((e["object"], e["mode"]) for e in low["events"])
    seen = Counter()
    group_total = Counter((g["id"], e["mode"]) for g in groups for e in low["events"] if e["ram"] in g["members"])
    group_seen = Counter()
    for event in schedule["timeline"]:
        if event["kind"] != "access":
            continue
        key = (event["object"], event["mode"])
        if event["task"] == "low":
            seen[key] += 1
            for group in groups:
                if event["ram"] in group["members"]:
                    group_seen[group["id"], event["mode"]] += 1
        else:
            low_mode, rule = ("R", 2) if event["mode"] == "W" else ("W", 3)
            k = (event["object"], low_mode)
            if 0 < seen[k] < total[k]:
                failed[event["ram"]].add(rule)
            for group in groups:
                if event["ram"] not in group["members"]:
                    continue
                for low_mode, high_mode, rule in [("R", "W", 4), ("W", "R", 5), ("W", "W", 6)]:
                    k = (group["id"], low_mode)
                    if event["mode"] == high_mode and 0 < group_seen[k] < group_total[k]:
                        group_failed[group["id"]].add(rule)
                        for member in group["members"]:
                            failed[member].add(rule)
    return ({key: sorted(value) for key, value in failed.items()},
            {key: sorted(value) for key, value in group_failed.items()})


def analyze(tasks, inventory, groups, limit):
    low, high = tasks
    output = {"groups": groups, "ram": [], "schedules": []}
    aggregates, group_aggregates, witnesses = {}, {}, {}
    for label, protected in [("raw", False), ("final", True)]:
        aggregate = {r["id"]: set() for r in inventory}
        group_aggregate = {g["id"]: set() for g in groups}
        traces = schedules(low, high, limit, protected)
        for trace in traces:
            failed, group_failed = evaluate_schedule(low, high, inventory, groups, trace, protected)
            for ram, rules in failed.items():
                aggregate[ram].update(rules)
                for rule in rules:
                    witnesses.setdefault((label, ram, rule), trace["id"])
            for group, rules in group_failed.items():
                group_aggregate[group].update(rules)
            trace["violations"] = failed
        aggregates[label], group_aggregates[label] = aggregate, group_aggregate
        output[label + "_schedule_count"] = len(traces)
        if protected:
            output["schedules"] = traces
    for ram in inventory:
        row = dict(ram)
        for label in ("raw", "final"):
            row[label] = [rule not in aggregates[label][ram["id"]] for rule in range(1, 7)]
        row["witnesses"] = {str(rule): witnesses[("final", ram["id"], rule)] for rule in aggregates["final"][ram["id"]]}
        row["groups"] = [g["id"] for g in groups if ram["id"] in g["members"]]
        output["ram"].append(row)
    output["group_results"] = [{**g, **{label: [rule not in group_aggregates[label][g["id"]] for rule in range(4, 7)]
                                      for label in ("raw", "final")}} for g in groups]
    return output
