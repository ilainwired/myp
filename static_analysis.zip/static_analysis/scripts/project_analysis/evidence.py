"""Independent executable C monitor and Frama-C Eva checks of the access model.

The model is derived from the extracted access IR, not from expected verdicts.
It is not a source-equivalence proof and does not model C memory interleavings.
"""
import re
from .common import AnalysisBlocked, command, write_json


def original_eva(config, units):
    records = []
    for task in config["_tasks"]:
        path = config["_out"] / "frama" / ("original_" + task["id"] + ".log")
        result = command(["frama-c", "-machdep", "x86_64", "-eva", "-eva-slevel", "10000", "-main", task["entry"],
                          *[u["preprocessed"] for u in units]], config["_root"], path)
        if not re.search(r"\b0 alarms generated", result.stdout):
            raise AnalysisBlocked("Frama-C original task has alarms or incomplete summary: " + path.name)
        if re.search(r"\[.*(?:error|abort)\]", result.stdout + result.stderr, re.I):
            raise AnalysisBlocked("Frama-C original task diagnostic: " + path.name)
        records.append({"entry": task["entry"], "runtime_alarms": 0, "log": str(path.relative_to(config["_out"]))})
    return records


def verify_model(config, tasks, inventory, result):
    out = config["_out"] / "model"
    out.mkdir(parents=True, exist_ok=True)
    rids = [r["id"] for r in inventory]
    objects = sorted({e["object"] for t in tasks for e in t["events"]})
    groups = result["groups"]
    nr, no, ng = max(1, len(rids)), max(1, len(objects)), max(1, len(groups))
    lines = ["/* Generated access model. See model_map.json; original C is analyzed separately. */",
             "#ifndef __FRAMAC__\n#include <stdio.h>\n#endif",
             f"static int seen[{no}][2],total[{no}][2],gs[{ng}][2],gt[{ng}][2],hw[{no}],bad[{nr}],depth;",
             f"static const int member[{ng}][{nr}]={{" + ",".join("{" + ",".join(str(int(r in g["members"])) for r in rids) + "}" for g in groups) + ("" if groups else "{0}") + "};",
             f"static void reset(void){{int i,j;depth=0;for(i=0;i<{no};i++){{hw[i]=0;for(j=0;j<2;j++)seen[i][j]=total[i][j]=0;}}for(i=0;i<{ng};i++)for(j=0;j<2;j++)gs[i][j]=gt[i][j]=0;for(i=0;i<{nr};i++)bad[i]=0;}}",
             f"static void count_low(int o,int r,int m){{int g;total[o][m]++;for(g=0;g<{len(groups)};g++)if(member[g][r])gt[g][m]++;}}",
             f"static void low(int o,int r,int m){{int g;if(m==1 && hw[o] && depth==0)bad[r]|=1;seen[o][m]++;for(g=0;g<{len(groups)};g++)if(member[g][r])gs[g][m]++;}}",
             "static void high(int o,int r,int m){int g,j,mask;",
             "/*@ check legal_preemption: depth == 0; */",
             "if(m==1 && seen[o][0]>0 && seen[o][0]<total[o][0])bad[r]|=2;",
             "if(m==0 && seen[o][1]>0 && seen[o][1]<total[o][1])bad[r]|=4;",
             f"for(g=0;g<{len(groups)};g++)if(member[g][r]){{mask=0;if(m==1 && gs[g][0]>0 && gs[g][0]<gt[g][0])mask|=8;if(gs[g][1]>0 && gs[g][1]<gt[g][1])mask|=m==0?16:32;for(j=0;j<{len(rids)};j++)if(member[g][j])bad[j]|=mask;}}}}"]
    expected, labels = {}, []
    for scenario in result["schedules"]:
        sid = scenario["id"]
        lines += [f"static void sc_{sid}(void){{reset();"]
        for event in tasks[0]["events"]:
            lines.append(f"count_low({objects.index(event['object'])},{rids.index(event['ram'])},{int(event['mode']=='W')});")
        for event in tasks[1]["events"]:
            if event["mode"] == "W":
                lines.append(f"hw[{objects.index(event['object'])}]=1;")
        for event in scenario["timeline"]:
            if event["kind"] == "access":
                lines.append(f"{event['task']}({objects.index(event['object'])},{rids.index(event['ram'])},{int(event['mode']=='W')});")
            elif event["task"] == "low":
                lines.append("depth++;" if event["kind"] == "enter" else "depth--;")
        for ri, ram in enumerate(rids):
            expected[f"{sid}:{ri}"] = sum(1 << (r-1) for r in scenario["violations"][ram])
            for rule in range(1, 7):
                label = f"sc_{sid}_ram_{ri}_rule_{rule}"
                labels.append(label)
                lines.append(f"/*@ check {label}: (bad[{ri}] & {1 << (rule-1)}) == 0; */")
            lines += ["#ifndef __FRAMAC__", f'printf("{sid}:{ri}=%d\\n",bad[{ri}]);', "#endif"]
        lines.append("}")
    lines += ["int main(void){" + "".join(f"sc_{s['id']}();" for s in result["schedules"]) + "return 0;}"]
    source = out / "access_model.c"
    source.write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_json(out / "model_map.json", {"RAM": rids, "objects": objects, "groups": groups,
        "input": "stage02/results.json: schedules; extracted from clang AST", "model": "single activation, atomic int access, designated Enter/Exit regions"})
    command(["clang", "-std=c11", "-O0", str(source), "-o", str(out / "access_model")], out, out / "clang.log")
    native = command([str(out / "access_model")], out, out / "native.log")
    actual = {key: int(value) for key, value in (line.split("=") for line in native.stdout.splitlines())}
    if actual != expected:
        raise AnalysisBlocked("C monitor disagrees with Python rules")
    eva = command(["frama-c", "-eva", "-eva-slevel", "100000", str(source)], out, out / "eva.log", timeout=300)
    output = eva.stdout + eva.stderr
    # Invalid ACSL 'check' annotations do not constrain later states, unlike assertions.
    invalid = set(re.findall(r"(?:check|assertion)\s+'?(sc_\d+_ram_\d+_rule_\d+)'?[^\n]*status invalid", output))
    unknown = re.findall(r"(?:check|assertion)\s+[^\n]*status unknown", output)
    expected_invalid = {f"sc_{sid}_ram_{ri}_rule_{rule}" for key, mask in expected.items()
                        for sid, ri in [key.split(":")] for rule in range(1, 7) if mask & (1 << (rule-1))}
    summary = re.search(r"Assertions\s+(\d+)\s+valid\s+(\d+)\s+unknown\s+(\d+)\s+invalid", output)
    if invalid != expected_invalid or unknown or not re.search(r"\b0 alarms generated", output):
        raise AnalysisBlocked("Frama-C model check mismatch/unknown; inspect model/eva.log")
    reached_preemption_check=1 if tasks[1]["events"] else 0
    if not summary or int(summary[2]) or int(summary[3]) != len(expected_invalid) or sum(map(int, summary.groups())) != len(labels) + reached_preemption_check:
        raise AnalysisBlocked("Frama-C model annotation accounting mismatch; inspect model/eva.log")
    record = {"native_matches_python": True, "eva_matches_native": True,
              "scenarios": len(result["schedules"]), "requirement_checks": len(labels),
              "eva_invalid_expected": len(invalid), "eva_unknown": 0, "runtime_alarms": 0,
              "scope": "access model, not original-source concurrency equivalence",
              "artifacts": ["model/access_model.c", "model/model_map.json", "model/clang.log", "model/native.log", "model/eva.log"]}
    write_json(out / "verification.json", record)
    return record
