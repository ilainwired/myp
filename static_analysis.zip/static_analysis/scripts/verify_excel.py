"""Recalculate with LibreOffice, validate cached formulas and render PNGs (no PDF)."""
import argparse
from pathlib import Path
import shutil
import subprocess
import textwrap
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from PIL import Image, ImageDraw, ImageFont
from project_analysis.common import read_json,write_json

FONT="/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"


def render(ws,values,target,min_row=1,max_row=12,max_col=6):
    font=ImageFont.truetype(FONT,14)
    small=ImageFont.truetype(FONT,13)
    cols=[0]
    for c in range(1,max_col+1):
        cols.append(cols[-1]+int(min(ws.column_dimensions[get_column_letter(c)].width or 13,75)*8))
    rows=[0]
    for r in range(min_row,max_row+1):
        rows.append(rows[-1]+int((ws.row_dimensions[r].height or 22)*1.33))
    image=Image.new("RGB",(cols[-1]+2,rows[-1]+2),"white")
    draw=ImageDraw.Draw(image)
    merged={}
    for region in ws.merged_cells.ranges:
        if region.max_row<min_row or region.min_row>max_row:continue
        for r in range(region.min_row,region.max_row+1):
            for c in range(region.min_col,region.max_col+1):
                merged[r,c]=region
    for r in range(min_row,max_row+1):
        for c in range(1,max_col+1):
            region=merged.get((r,c))
            if region and (r,c)!=(region.min_row,region.min_col):continue
            endc=min(max_col,region.max_col if region else c)
            x,y=cols[c-1],rows[r-min_row]
            width,height=cols[endc]-x,rows[r-min_row+1]-y
            cell=ws.cell(r,c)
            value=values.cell(r,c).value
            if value is None:continue
            fg=cell.fill.fgColor
            background="#"+fg.rgb[-6:] if cell.fill.patternType=="solid" and fg.type=="rgb" else "#FFFFFF"
            if isinstance(value,bool):background="#DBEEE1" if value else "#F9DCD8"
            draw.rectangle((x,y,x+width,y+height),fill=background)
            color="#FFFFFF" if background=="#18344D" else "#203648"
            text="TRUE" if value is True else "FALSE" if value is False else str(value)
            if cell.alignment.textRotation==180:
                layer=Image.new("RGB",(height-10,width-10),background)
                painter=ImageDraw.Draw(layer)
                painter.multiline_text((5,4),text,font=small,fill=color,spacing=2)
                layer=layer.rotate(-90,expand=True)
                image.paste(layer,(x+5,y+5))
            else:
                lines=[]
                for paragraph in text.splitlines():
                    line=""
                    for ch in paragraph:
                        if draw.textlength(line+ch,font=font)>width-12:
                            lines.append(line);line=ch
                        else:line+=ch
                    lines.append(line)
                for i,line in enumerate(lines[:max(1,(height-6)//21)]):
                    draw.text((x+6,y+3+i*21),line,font=font,fill=color)
            draw.line((x,y+height,x+width,y+height),fill="#DDE5EB")
    target.parent.mkdir(parents=True,exist_ok=True)
    image.save(target)


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--directory",type=Path,required=True)
    args=p.parse_args()
    folder=args.directory.resolve()
    qa=folder/"qa"
    recalc=qa/"recalculated"
    recalc.mkdir(parents=True,exist_ok=True)
    profile=qa/"lo_profile"
    books=sorted(folder.glob("*.xlsx"))
    command=["libreoffice","-env:UserInstallation="+profile.as_uri(),"--headless","--convert-to","xlsx","--outdir",str(recalc),*map(str,books)]
    run=subprocess.run(command,text=True,capture_output=True,timeout=180)
    (qa/"recalculation.log").write_text(run.stdout+run.stderr,encoding="utf-8")
    if run.returncode:raise RuntimeError("LibreOffice recalc failed")
    report={"formulas":0,"sheets":0,"previews":[],"renderer":"Pillow approximation of cell geometry; actual OOXML rotations/merges and LibreOffice formula caches verified separately", "workbooks":[]}
    for path in books:
        rendered=recalc/path.name
        if not rendered.exists():raise RuntimeError("missing recalculated workbook")
        # Keep openpyxl's exact layout/rotation metadata. Transfer formula caches
        # from LibreOffice only by using its recalculated workbook when compatible.
        before=load_workbook(path)
        after=load_workbook(rendered)
        for ws in before:
            if set(map(str,ws.merged_cells.ranges))!=set(map(str,after[ws.title].merged_cells.ranges)):
                raise AssertionError("recalc changed merged ranges")
            for row in ws:
                for cell in row:
                    if cell.alignment.textRotation==180 and after[ws.title][cell.coordinate].alignment.textRotation!=180:
                        raise AssertionError("recalc changed clockwise rotation")
        shutil.copy2(rendered,path)
        formulas=load_workbook(path,data_only=False)
        values=load_workbook(path,data_only=True)
        for ws in formulas:
            report["sheets"]+=1
            for row in ws:
                for cell in row:
                    cached=values[ws.title][cell.coordinate]
                    if cached.data_type=="e":raise AssertionError("Excel error: "+str(cached.value))
                    if cell.data_type=="f":
                        report["formulas"]+=1
                        if cached.value is None:raise AssertionError("missing formula cache")
                        if cell.value.startswith("='"):
                            reference=cell.value[2:]
                            name,address=reference.split("'!")
                            if cached.value!=values[name][address].value:raise AssertionError("reference formula mismatch")
            preview=qa/(path.stem+"_"+ws.title+".png")
            render(ws,values[ws.title],preview,max_row=min(ws.max_row,12),max_col=min(ws.max_column,6))
            report["previews"].append(str(preview.relative_to(folder)))
        report["workbooks"].append(path.name)
    layout=read_json(folder/"excel_layout.json")
    forms=load_workbook(folder/"02_判定結果.xlsx")
    vals=load_workbook(folder/"02_判定結果.xlsx",data_only=True)
    ws=forms["判定表"]
    for addr in layout["rotated_headers"]:
        assert ws[addr].alignment.textRotation==180,addr
    for item in layout["merged_results"]:
        assert item["range"] in {str(r) for r in ws.merged_cells.ranges}
    for item in layout["previews"]:
        path=qa/(item["project"]+"_matrix.png")
        render(ws,vals["判定表"],path,item["min_row"],item["max_row"],item["max_col"])
        report["previews"].append(str(path.relative_to(folder)))
    # One contact sheet covers every matrix block; detailed PNGs remain available.
    thumbs=[]
    for name in report["previews"]:
        im=Image.open(folder/name)
        im.thumbnail((430,320))
        tile=Image.new("RGB",(450,350),"#EEF2F6")
        tile.paste(im,((450-im.width)//2,25))
        ImageDraw.Draw(tile).text((8,5),Path(name).stem,font=ImageFont.truetype(FONT,12),fill="black")
        thumbs.append(tile)
    contact=Image.new("RGB",(450*5,350*((len(thumbs)+4)//5)),"white")
    for i,tile in enumerate(thumbs):contact.paste(tile,((i%5)*450,(i//5)*350))
    contact.save(qa/"all_sheets_contact.png")
    report["clockwise_headers"]=len(layout["rotated_headers"])
    report["group_merged_results"]=len(layout["merged_results"])
    write_json(qa/"verification.json",report)
    print({k:v for k,v in report.items() if k not in {"previews","workbooks"}})


if __name__=="__main__":main()
