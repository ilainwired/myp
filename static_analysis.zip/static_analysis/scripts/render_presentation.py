"""Render final PPTX with LibreOffice UNO directly to PNG. Never create a PDF.

Requires libreoffice-impress, python3-uno and Pillow (install_wsl.sh).
"""
from pathlib import Path
import socket
import subprocess
import tempfile
import time
import zipfile
import xml.etree.ElementTree as ET
from PIL import Image,ImageDraw,ImageFont
import uno
from project_analysis.common import write_json,read_json

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"outputs/deliverables"


def prop(name,value):
    item=uno.createUnoStruct("com.sun.star.beans.PropertyValue")
    item.Name=name
    item.Value=value
    return item


def main():
    pptx=OUT/"04_解析フローと代表例.pptx"
    target=OUT/"qa/presentation"
    target.mkdir(parents=True,exist_ok=True)
    with socket.socket() as server:
        server.bind(("127.0.0.1",0))
        port=server.getsockname()[1]
    with tempfile.TemporaryDirectory(prefix="static-analysis-impress-") as temporary:
        profile=Path(temporary)/"profile"
        log=(target/"libreoffice.log").open("w",encoding="utf-8")
        process=subprocess.Popen(["soffice","-env:UserInstallation="+profile.as_uri(),"--headless","--nologo","--nodefault","--nofirststartwizard",
                                  f"--accept=socket,host=127.0.0.1,port={port};urp;StarOffice.ComponentContext"],stdout=log,stderr=log)
        document=None
        try:
            local=uno.getComponentContext()
            resolver=local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver",local)
            context=None
            for _ in range(80):
                try:
                    context=resolver.resolve(f"uno:socket,host=127.0.0.1,port={port};urp;StarOffice.ComponentContext")
                    break
                except Exception:time.sleep(.25)
            if context is None:raise RuntimeError("LibreOffice UNO connection failed")
            manager=context.ServiceManager
            desktop=manager.createInstanceWithContext("com.sun.star.frame.Desktop",context)
            document=desktop.loadComponentFromURL(uno.systemPathToFileUrl(str(pptx)),"_blank",0,(prop("Hidden",True),prop("ReadOnly",True)))
            pages=document.getDrawPages()
            for i in range(pages.getCount()):
                export=manager.createInstanceWithContext("com.sun.star.drawing.GraphicExportFilter",context)
                export.setSourceDocument(pages.getByIndex(i))
                ok=export.filter((prop("URL",uno.systemPathToFileUrl(str(target/f"slide-{i+1:02d}.png"))),prop("MediaType","image/png"),
                                  prop("FilterData",(prop("PixelWidth",1600),prop("PixelHeight",900),prop("Translucent",False)))))
                if not ok:raise RuntimeError("PNG export failed")
            count=pages.getCount()
        finally:
            if document is not None:document.close(True)
            process.terminate()
            try:process.wait(timeout=15)
            except subprocess.TimeoutExpired:process.kill();process.wait()
            log.close()
    thumbnails=[]
    for path in sorted(target.glob("slide-*.png")):
        image=Image.open(path).convert("RGB")
        image.thumbnail((640,360))
        tile=Image.new("RGB",(660,392),"#EBEEF1")
        tile.paste(image,(10,24))
        ImageDraw.Draw(tile).text((10,5),path.stem,fill="black")
        thumbnails.append(tile)
    contact=Image.new("RGB",(1320,392*((len(thumbnails)+1)//2)),"white")
    for i,tile in enumerate(thumbnails):contact.paste(tile,((i%2)*660,(i//2)*392))
    contact.save(target/"contact.png")
    ns={"a":"http://schemas.openxmlformats.org/drawingml/2006/main"}
    with zipfile.ZipFile(pptx) as package:
        slides=[n for n in package.namelist() if n.startswith("ppt/slides/slide") and n.endswith(".xml")]
        assert len(slides)==count
        for name in slides:
            xml=ET.fromstring(package.read(name))
            for run in xml.findall(".//a:rPr",ns):
                if run.get("sz") is not None and int(run.get("sz"))<1600:
                    raise AssertionError("Text below 16pt: "+name)
    layout=read_json(OUT/"qa/presentation_layout.json")
    assert not layout["warnings"]
    write_json(target/"verification.json",{"slides":count,"rendered":len(thumbnails),"all_text_at_least_16pt":True,"layout_warnings":0,"pdf_generated":False,
        "visual_review":"PNG files ready for AI/human inspection"})
    print(f"Rendered {count} slides directly to PNG; structural checks passed.")


if __name__=="__main__":main()
