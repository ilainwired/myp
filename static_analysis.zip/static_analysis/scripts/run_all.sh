#!/usr/bin/env bash
set -euo pipefail
task_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$task_root"
python3 tests/run_project_suite.py
python3 tests/test_pipeline_contracts.py
python3 scripts/export_reports.py --suite outputs/project_suite/test_results.json --suite-root . --output outputs/deliverables
python3 scripts/verify_excel.py --directory outputs/deliverables
python3 scripts/summarize_tests.py
# This final stage must verify the code fingerprint before producing slides.
if [[ -f scripts/build_explanation.py ]]; then
    python3 scripts/build_explanation.py
    python3 scripts/render_presentation.py
fi
