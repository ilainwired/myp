"""Fail-closed Clang AST reader for the straight-line demonstration subset.

This is deliberately not a general C interpreter or a concurrency checker.
Pointers refer to storage locations, so taking &g does not read g.
"""
from __future__ import annotations

from dataclasses import dataclass
import re


class Unsupported(ValueError):
    pass


@dataclass(frozen=True)
class Address:
    key: str


@dataclass
class Value:
    data: int | Address | None
    sources: frozenset[str] = frozenset()


class Returned(Exception):
    def __init__(self, value):
        self.value = value


class Extractor:
    INTEGER_TYPES = {"int", "unsigned int", "short", "unsigned short", "long", "unsigned long",
                     "long long", "unsigned long long", "char", "signed char", "unsigned char", "_Bool"}
    def __init__(self, ast, source, filename):
        self.ast, self.source, self.filename = ast, source, filename
        self.functions, self.globals, self.names, self.initial = {}, {}, {}, {}
        self.records, self.aliases, self.object_types, self.display_names = {}, {}, {}, {}
        for node in ast.get("inner", []):
            if node["kind"] == "RecordDecl" and node.get("completeDefinition") and node.get("name"):
                self.records[node.get("tagUsed", "struct") + " " + node["name"]] = node
            elif node["kind"] == "TypedefDecl":
                self.aliases[node["name"]] = node["type"]["qualType"]
        for node in ast.get("inner", []):
            if node["kind"] == "FunctionDecl":
                if any(c["kind"] == "CompoundStmt" for c in node.get("inner", [])):
                    self.functions[node["name"]] = node
            elif node["kind"] == "VarDecl":
                if node.get("storageClass") == "extern":
                    raise Unsupported("extern globals require translation-unit linking")
                name = node["name"]
                self.globals[node["id"]] = name
                initial = node.get("inner", [])
                if initial and initial[-1]["kind"] != "IntegerLiteral":
                    raise Unsupported("non-literal global initializer")
                qtype = node["type"].get("desugaredQualType", node["type"]["qualType"])
                self.expand_type(name, qtype, node, int(initial[-1]["value"]) if initial else 0)

    def canonical_type(self, qtype):
        qtype = re.sub(r"\b(?:const|volatile|restrict)\s*", "", qtype).strip()
        visited = set()
        while qtype in self.aliases:
            if qtype in visited:
                raise Unsupported("recursive type alias")
            visited.add(qtype)
            qtype = self.aliases[qtype]
            qtype = re.sub(r"\b(?:const|volatile|restrict)\s*", "", qtype).strip()
        return qtype

    def array_type(self, qtype):
        qtype = self.canonical_type(qtype)
        match = re.fullmatch(r"(.+?)\[(\d+)\](.*)", qtype)
        if not match:
            return None
        return int(match[2]), match[1].strip() + match[3]

    def expand_type(self, path, qtype, node, initial=0):
        qtype = self.canonical_type(qtype)
        key = "global:" + path
        self.object_types[key] = qtype
        array = self.array_type(qtype)
        if array:
            size, item_type = array
            limits = getattr(self, "limits", {})
            if size <= 0 or size > limits.get("array_extent", 4096) or len(self.object_types) > limits.get("storage_locations", 10000):
                raise Unsupported("array size outside the bounded demonstration limit")
            for i in range(size):
                self.expand_type(f"{path}[{i}]", item_type, node)
        elif qtype in self.records:
            record = self.records[qtype]
            if record.get("tagUsed") != "struct":
                raise Unsupported("union overlap needs an explicit storage model")
            for field in record.get("inner", []):
                if field["kind"] != "FieldDecl" or not field.get("name") or field.get("isBitfield"):
                    raise Unsupported("anonymous members and bit fields require additional layout analysis")
                fieldtype = field["type"].get("desugaredQualType", field["type"]["qualType"])
                self.expand_type(path + "." + field["name"], fieldtype, node)
        elif qtype in self.INTEGER_TYPES:
            display = re.sub(r"\[\d+\]", "[]", path)
            self.names.setdefault(display, node)
            self.display_names[key] = display
            self.initial[path] = initial
        else:
            raise Unsupported("unsupported global/field type: " + qtype)

    def location(self, node):
        begin = node.get("range", {}).get("begin", node.get("loc", {}))
        if "expansionLoc" in begin or "spellingLoc" in begin:
            raise Unsupported("macro expansion requires source mapping")
        offset = begin.get("offset")
        if offset is None:
            raise Unsupported("missing source offset")
        return self.source.encode("utf-8")[:offset].count(b"\n") + 1

    def global_info(self):
        return [{"name": n, "type": "int", "line": self.location(node),
                 "declaration_type": node["type"]["qualType"],
                 "locations": [key[7:] for key, display in self.display_names.items() if display == n],
                 "initial": self.initial.get(n, 0)} for n, node in self.names.items()]

    def extract(self, entry):
        self.memory = {"global:" + n: Value(v) for n, v in self.initial.items()}
        self.frames, self.stack, self.events, self.trace, self.comparisons = [], [], [], [], []
        self.next_frame = 0
        self.entry = entry
        result = self.call(entry, [], None)
        return {"entry": entry, "events": self.events, "trace": self.trace,
                "comparison_groups": self.comparisons,
                "return_value": result.data if isinstance(result.data, int) else None,
                "final_values": {n: self.memory["global:" + n].data for n in self.initial}}

    def key(self, decl):
        did = decl["id"]
        if did in self.globals:
            return "global:" + self.globals[did]
        for frame in reversed(self.frames):
            if did in frame:
                return frame[did]
        raise Unsupported("unresolved declaration: " + decl.get("name", did))

    def lvalue(self, node):
        kind = node["kind"]
        if kind == "DeclRefExpr":
            return self.key(node["referencedDecl"])
        if kind == "ParenExpr":
            return self.lvalue(node["inner"][0])
        if kind == "MemberExpr":
            if node.get("isArrow"):
                pointer = self.expr(node["inner"][0]).data
                if not isinstance(pointer, Address):
                    raise Unsupported("unresolved record pointer")
                base = pointer.key
            else:
                base = self.lvalue(node["inner"][0])
            key = base + "." + node["name"]
            if key not in self.object_types:
                raise Unsupported("unresolved member: " + key)
            return key
        if kind == "ArraySubscriptExpr":
            base = self.expr(node["inner"][0]).data
            index = self.expr(node["inner"][1])
            if not isinstance(base, Address) or not isinstance(index.data, int) or index.sources:
                raise Unsupported("array index must be a resolved, task-local integer")
            array = self.array_type(self.object_types.get(base.key, ""))
            if array is None:
                # An int* at a particular array element can be indexed without
                # losing its parent array bounds; arbitrary pointer arithmetic is unsupported.
                match = re.fullmatch(r"(.+)\[(\d+)\]", base.key)
                if not match:
                    raise Unsupported("subscript on a non-array pointer")
                array = self.array_type(self.object_types.get(match[1], ""))
                base_index, parent = int(match[2]), match[1]
            else:
                base_index, parent = 0, base.key
            actual = base_index + index.data
            if array is None or actual < 0 or actual >= array[0]:
                raise Unsupported("array index out of bounds")
            return f"{parent}[{actual}]"
        if kind == "UnaryOperator" and node["opcode"] == "*":
            pointer = self.expr(node["inner"][0]).data
            if not isinstance(pointer, Address):
                raise Unsupported("unresolved/null pointer dereference")
            return pointer.key
        raise Unsupported("unsupported lvalue: " + kind)

    def access(self, key, mode, node, value):
        if key.startswith("global:"):
            if key not in self.display_names:
                raise Unsupported("whole-record/array access requires lowering to scalar elements")
            event = {"index": len(self.events) + 1, "ram": self.display_names[key], "object": key[7:], "mode": mode,
                     "function": self.stack[-1], "call_path": list(self.stack),
                     "file": self.filename, "line": self.location(node),
                     "value": value.data if isinstance(value.data, int) else None}
            event["source"] = self.source.splitlines()[event["line"] - 1].strip()
            self.events.append(event)
            self.trace.append({"kind": "access", **event})

    def read(self, key, node):
        if key not in self.memory or self.memory[key].data is None:
            raise Unsupported("read of uninitialized storage")
        value = self.memory[key]
        self.access(key, "R", node, value)
        return Value(value.data, frozenset({self.display_names[key]}) if key.startswith("global:") else value.sources)

    def expr(self, node):
        kind, inner = node["kind"], node.get("inner", [])
        if kind == "IntegerLiteral":
            return Value(int(node["value"]))
        if kind == "ParenExpr":
            return self.expr(inner[0])
        if kind == "ImplicitCastExpr":
            cast = node["castKind"]
            if cast == "LValueToRValue":
                return self.read(self.lvalue(inner[0]), inner[0])
            if cast == "ArrayToPointerDecay":
                return Value(Address(self.lvalue(inner[0])))
            if cast == "NoOp":
                return self.expr(inner[0])
            raise Unsupported("unsupported cast: " + cast)
        if kind in {"DeclRefExpr", "MemberExpr", "ArraySubscriptExpr"}:
            return self.read(self.lvalue(node), node)
        if kind == "UnaryOperator":
            op = node["opcode"]
            if op == "&":
                return Value(Address(self.lvalue(inner[0])))
            if op == "*":
                return self.read(self.lvalue(node), node)
            raise Unsupported("unsupported unary operator: " + op)
        if kind == "BinaryOperator":
            op = node["opcode"]
            if op == "=":
                # Restrict each statement to one shared access in source order.
                value = self.expr(inner[1])
                key = self.lvalue(inner[0])
                self.memory[key] = value
                self.access(key, "W", inner[0], value)
                return value
            if op == "==":
                a, b = self.expr(inner[0]), self.expr(inner[1])
                sources = a.sources | b.sources
                if len(sources) > 1:
                    self.comparisons.append({"members": sorted(sources),
                                             "function": self.stack[-1],
                                             "line": self.location(node)})
                return Value(int(a.data == b.data), sources)
            raise Unsupported("unsupported binary operator: " + op)
        if kind == "CallExpr":
            callee = inner[0]
            while callee["kind"] in {"ImplicitCastExpr", "ParenExpr"}:
                callee = callee["inner"][0]
            if callee["kind"] != "DeclRefExpr" or callee["referencedDecl"]["kind"] != "FunctionDecl":
                raise Unsupported("indirect function call")
            args = [self.expr(arg) for arg in inner[1:]]
            return self.call(callee["referencedDecl"]["name"], args, node)
        raise Unsupported("unsupported expression: " + kind)

    def statement(self, node):
        kind = node["kind"]
        if kind == "CompoundStmt":
            for child in node.get("inner", []):
                before = len(self.events)
                self.statement(child)
                # Calls may contain several sequenced statements; ordinary expressions may not.
                if child["kind"] not in {"CallExpr", "CompoundStmt", "DeclStmt", "ReturnStmt"}:
                    if len(self.events) - before > 1:
                        raise Unsupported("multiple shared accesses in one expression need sequencing analysis")
        elif kind == "DeclStmt":
            for decl in node["inner"]:
                if decl["kind"] != "VarDecl" or decl.get("storageClass") == "static":
                    raise Unsupported("unsupported local declaration")
                qtype = decl["type"]["qualType"]
                if not re.fullmatch(r"int(?: \*\*?)?", qtype) and not re.fullmatch(r"(?:struct \w+|\w+) \*{1,2}", qtype):
                    raise Unsupported("unsupported local type: " + qtype)
                key = f"local:{self.next_frame}:{decl['id']}"
                self.frames[-1][decl["id"]] = key
                before = len(self.events)
                self.memory[key] = self.expr(decl["inner"][-1]) if decl.get("inner") else Value(None)
                if len(self.events) - before > 1:
                    raise Unsupported("multiple accesses in initializer")
        elif kind == "ReturnStmt":
            before = len(self.events)
            value = self.expr(node["inner"][0]) if node.get("inner") else Value(None)
            if len(self.events) - before > 1:
                raise Unsupported("multiple accesses in return expression")
            raise Returned(value)
        elif kind == "NullStmt":
            pass
        elif kind in {"BinaryOperator", "CallExpr"}:
            self.expr(node)
        else:
            raise Unsupported("unsupported statement (no safe result emitted): " + kind)

    def call(self, name, args, callsite):
        if name in self.stack:
            raise Unsupported("recursion")
        if name not in self.functions:
            raise Unsupported("external function has no access model: " + name)
        function = self.functions[name]
        params = [c for c in function.get("inner", []) if c["kind"] == "ParmVarDecl"]
        if len(params) != len(args):
            raise Unsupported("argument mismatch")
        self.next_frame += 1
        frame = {}
        for param, arg in zip(params, args):
            key = f"param:{self.next_frame}:{param['id']}"
            frame[param["id"]] = key
            self.memory[key] = arg
        self.frames.append(frame)
        self.stack.append(name)
        self.trace.append({"kind": "call", "function": name, "depth": len(self.stack) - 1,
                           "line": self.location(callsite or function)})
        value = Value(None)
        try:
            body = next(c for c in function["inner"] if c["kind"] == "CompoundStmt")
            self.statement(body)
        except Returned as returned:
            value = returned.value
        self.stack.pop()
        self.frames.pop()
        return value
