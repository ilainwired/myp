"""Build the explanation only after code_freeze.json verifies unchanged analysis.

Requires WSL node/npm. Uses PptxGenJS 4.0.1 because the supplied artifact-tool
workspace setup failed: the bundled package/package.json is missing. The user
authorized installing required tools; no python-pptx is used. Editable native
PowerPoint shapes implement the specifically requested diagrams. JS source is
run in an external temporary workspace, removed on completion. Dependencies
remain installed under ~/.local/share/static-analysis-presentation.
"""
from pathlib import Path
import json
import os
import subprocess
import tempfile

from project_analysis.common import read_json,write_json,digest

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"outputs/deliverables"

JS=r'''
import fs from 'node:fs';
import path from 'node:path';
import pptxgen from 'pptxgenjs';
const d=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const p=new pptxgen();
p.layout='LAYOUT_WIDE'; p.author='Static analysis project';
p.subject='Clang, Frama-C and AI evidence after verified code freeze';
p.title='RAM同時性解析の成果物と判定根拠'; p.company=''; p.lang='ja-JP';
p.theme={headFontFace:'Noto Sans CJK JP',bodyFontFace:'Noto Sans CJK JP',lang:'ja-JP'};
const W=13.333333,H=7.5, ink='15222D', muted='53606B', gray='F0F2F4', line='BFC8CF', blue='235B83', red='A13F2F', green='287347';
const layout=[],sources=[];
let s,n=0,boxes=[];
function text(t,x,y,w,h,size=20,opt={}){
  s.addText(t,{x,y,w,h,fontFace:'Noto Sans CJK JP',fontSize:size,color:ink,margin:0,breakLine:false,paraSpaceAfterPt:5,...opt});
  boxes.push({text:typeof t==='string'?t:'rich text',x,y,w,h,size});
}
function rule(x1,y1,x2,y2,color=line,width=1){s.addShape(p.ShapeType.line,{x:x1,y:y1,w:x2-x1,h:y2-y1,line:{color,width}});}
function arrow(x1,y1,x2,y2,color=blue){s.addShape(p.ShapeType.line,{x:x1,y:y1,w:x2-x1,h:y2-y1,line:{color,width:2,beginArrowType:'none',endArrowType:'triangle'}});}
function rect(x,y,w,h,fill=gray){s.addShape(p.ShapeType.rect,{x,y,w,h,line:{color:fill,transparency:100},fill:{color:fill}});}
function node(head,body,x,y,w=3.6,h=1.32,color=gray){
  rect(x,y,w,h,color);text(head,x+.16,y+.13,w-.32,.38,24,{bold:true});text(body,x+.16,y+.60,w-.32,h-.67,16);
}
function begin(title,kicker='解析の根拠'){
  if(s)layout.push({slide:n,boxes});
  s=p.addSlide();n++;boxes=[];s.background={color:'FFFFFF'};
  text(kicker,.55,.25,11.8,.3,16,{color:muted});
  text(title,.55,.83,12.25,.69,35,{bold:true});
  rule(.55,6.97,12.78,6.97);
  text('AI + Clang + Frama-C',.55,7.12,10,.24,16,{color:muted});
  text(String(n),12.18,7.12,.6,.24,16,{color:muted,align:'right'});
  return s;
}
function note(lines){s.addNotes(lines.join('\n'));sources.push({slide:n,sources:lines});}
function links(cid,items,y=6.55){
  let x=.55;
  for(const [label,relative] of items){
    text(label,x,y,2.4,.28,16,{color:blue,hyperlink:{url:'../project_suite/'+cid+'/'+relative}});x+=2.55;
  }
}

begin('RAM同時性を根拠まで追う','検証済みコードの解析記録');
text('ClangとFrama-Cの成果物を\n判定とAIの判断へつなぐ',.55,2.00,12.0,1.70,50,{bold:true});
text('代表例  TC205 ／ TC209 ／ TC306',.58,4.13,11.8,.48,24,{color:blue});
text('AIの推測、人の確認、スクリプトの計算を区別する',.58,4.98,11.7,.65,24);
text(`解析コード固定後に作成  ·  ${d.freeze.tests_passed}ケース + ${d.freeze.contract_tests}受渡し試験 PASS`,.58,6.04,11.8,.38,20,{color:muted});
note(['目的：C開発者が、どのツール出力をどの工程が使い、何を根拠に判定したか再追跡できるようにする。', 'code_freeze.json: '+d.freeze.time_utc]);

begin('コードから判定まで成果物でつなぐ','全体像  |  01 → 人手確認 → 02');
arrow(4.15,2.52,4.85,2.52);arrow(8.45,2.52,9.15,2.52);
arrow(10.95,3.20,10.95,4.12);arrow(9.15,4.78,8.45,4.78);arrow(4.85,4.78,4.15,4.78);
node('Make + Bear','実際の対象TU・-I・-D\ncompile_commands.json',.55,1.88);
node('Clang','展開後Cと型・式の木\npreprocessed.i / ast.json',4.85,1.88);
node('独自スクリプト','RAM・R/W・添字・SchM\ninventory.json',9.15,1.88);
node('02の判定と検証','割込み配置 → C監視器 → Eva\nresults.json → Excel',.55,4.12);
node('人の確認・訂正','01のCSVを02の入力に固定\nテストでは確認を省略',4.85,4.12);
node('AIによる推測','比較・更新の意味を読む\n同時性グループを記入',9.15,4.12);
text('元Cの逐次Eva解析は01で別途実行。アラーム0だけで並行性の安全とはしない。',.55,5.96,12.2,.54,20);
note(['実装: scripts/project_analysis/build.py, extract.py, pipeline.py, rules.py, evidence.py','手順: ../../AI_Instruction_01.md, ../../AI_Instruction_02.md']);

begin('2種類のFrama-C解析を区別する','ツールの担当と結論の範囲');
arrow(4.1,2.33,5.0,2.33);arrow(8.5,2.33,9.1,2.33);
arrow(4.1,4.38,5.0,4.38);arrow(8.5,4.38,9.1,4.38);
node('元のC','Clangで前処理済みの全TU',.55,1.70,3.55,1.30);
node('Frama-C Eva','各公開関数を-mainに指定',5.0,1.70,3.50,1.30);
node('逐次の健全性','計算状態・実行時アラーム\noriginal_low / high.log',9.1,1.70,3.68,1.30);
node('アクセスIR','R/W・グループ・保護区間',.55,3.74,3.55,1.30);
node('Cアクセス監視器','Clangで実行 + Evaでcheck',5.0,3.74,3.50,1.30);
node('判定の整合','Python / C / Evaを比較\nmodel/verification.json',9.1,3.74,3.68,1.30);
text('AIは両方のログと元コードを照合し、モデルの前提を説明する。',.55,5.55,12.2,.48,24,{bold:true});
text('抽出IRと元Cの完全な等価性や、実機SchMの実装までは証明していない。',.55,6.20,12.2,.42,20,{color:muted});
note(['Frama-C Eva: https://frama-c.com/fc-plugins/eva.html','元Cとアクセスモデルは別の証拠。モデル側で期待値JSONを使用していない。']);

begin('マクロ1回から読込み2回を抽出する','代表例1  |  TC205');
text('#define TWICE(x) ((x)+(x))\nreturn TWICE(TC205_g);',.55,1.86,7.8,.92,22,{fontFace:'Noto Sans Mono CJK JP'});
arrow(4.1,3.62,4.85,3.62);arrow(8.45,3.62,9.15,3.62);
node('Clang -E','((TC205_g)+(TC205_g))',.55,3.0,3.55,1.23);
node('Clang AST','LValueToRValue が2か所\n同じVarDeclを参照',4.85,3.0,3.60,1.23);
node('抽出結果',`下位 R${d.TC205.lowR} ／ 上位 W${d.TC205.highW}\n同じ具体要素 TC205_g`,9.15,3.0,3.6,1.23);
arrow(3.0,5.21,4.68,5.21,red);arrow(7.45,5.21,9.04,5.21,red);
node('下位 R1','1回目の読込み',.55,4.64,2.45,1.14);
node('上位 W1','読込み間に割込み',4.68,4.64,2.77,1.14,'F7E7E2');
node('下位 R2','2回目の読込み',9.04,4.64,3.7,1.14);
text('AIの確認：マクロの見た目でR1にせず、展開式とこの反例を照合。条件2 FALSE。',.55,6.02,12.2,.43,20,{color:red});
links('TC205',[['元CのEva','frama/original_low.log'],['AST → R/W','stage01/inventory.json'],['反例のEva','model/eva.log'],['最終結果','stage02/results.json']]);
note(['元コード: ../../examples/TC205/src/tasks.c','Clang前処理: ../project_suite/TC205/clang/tu_001/preprocessed.i','モデル: sc_1_ram_0_rule_2 invalid。3配置×6条件=18check、invalid 1、unknown 0。','AIはマクロ二重評価とR/W抽出・反例の一致を確認した。']);

begin('1つの反例を3つの結果で照合する','代表例1の検証  |  TC205');
text('シナリオ1：下位R → 上位W → 下位R',.55,1.87,12.2,.51,26,{bold:true});
arrow(4.10,3.54,4.85,3.54);arrow(8.45,3.54,9.15,3.54);
node('Pythonの条件計算','RAM 0 の条件2 = FALSE\nresults.json',.55,2.81,3.55,1.58);
node('Clangの実行結果','native.log:  1:0=2\n違反maskのbit1 → 条件2',4.85,2.81,3.60,1.58);
node('Frama-Cのcheck','sc_1_ram_0_rule_2\nstatus invalid',9.15,2.81,3.60,1.58);
text('AIは、同じ配置・同じRAM・同じ条件の結果であることを確認する。',.55,4.91,12.2,.66,25,{bold:true});
text('3配置 × 6条件 = 18 check。invalid 1件は想定した違反、unknownは0件。\n元Cの逐次Evaがアラーム0でも、この読込み間の介入は別途検出される。',.55,5.81,12.2,.79,20);
note(['実際のログ: ../project_suite/TC205/model/native.log, model/eva.log','mask=2は二進数000010、条件2がFALSE。値が偶然同じかどうかではなくアクセスによる介入を判定。','original_low.logの0 alarmsは逐次の実行時異常についての結果。並行性の結論へ飛躍しない。']);

begin('同じ末端要素へのR2とW1を結び付ける','代表例2  |  TC209');
text('ram.cの定義 ← deep.hの型・extern → low.c / high.cの参照',.55,1.85,12.2,.52,22);
arrow(2.90,3.20,3.60,3.20);arrow(6.00,3.20,6.67,3.20);arrow(9.10,3.20,9.80,3.20);
node('A[2]','TC209_g[1]',.55,2.60,2.35,1.22);
node('B[3]','.b[2]',3.60,2.60,2.40,1.22);
node('C[4]','.c[3]',6.67,2.60,2.43,1.22);
node('int[2]','.values[1]',9.80,2.60,2.98,1.22);
text(`Clangの型・宣言ID・添字を独自処理で連結。${d.TC209.tu} TU、${d.TC209.elements}要素を区別。`,.55,4.13,12.2,.53,22,{bold:true});
text('内部  TC209_g[1].b[2].c[3].values[1]\n表示  TC209_g[].b[].c[].values[]',.55,4.92,8.9,.85,22,{fontFace:'Noto Sans Mono CJK JP'});
text('条件2\nFALSE',10.20,4.88,2.5,.86,26,{bold:true,color:red});
text('AIの確認：[]表示で別要素を混同していない。Evaは元Cとモデルを別々に確認。',.55,6.02,12.2,.44,20);
links('TC209',[['ビルド対象','build/compile_commands.json'],['型 → RAM','stage01/inventory.json'],['元CのEva','frama/original_low.log'],['モデルのEva','model/eva.log']]);
note(['元コード: ../../examples/TC209/include/deep.h と src/ram.c, low.c, high.c','2×3×4×2=48個の整数要素。正規RAM表示は1行。グループはなし。','同一具体要素にR2/W1を抽出し、条件2の反例をEva/C/Pythonで照合。']);

begin('EnterからExitまでを保護として評価する','代表例3  |  TC306');
text('AIが a と b の連続ペア更新からグループ1を提案。テストでは人手確認を省略。',.55,1.82,12.2,.57,21);
rect(2.65,2.83,7.05,1.25,'E7EEE9');
arrow(1.92,3.68,11.8,3.68);arrow(10.15,4.60,11.55,3.68,green);
text('下位',.55,3.11,1.1,.44,24,{bold:true});
for(const [label,x] of [['Enter',2.82],['W a',4.55],['W b',6.33],['Exit',8.31]])text(label,x,3.08,1.30,.51,24,{bold:true,align:'center'});
text('指定保護区間：この間へ上位を入れない',2.9,2.46,6.7,.35,19,{color:green});
text('上位 W a → W b',8.20,4.71,4.10,.45,24,{color:green});
text('Clang抽出：両タスクのWは消えない',.55,4.62,7.00,.49,22);
text('保護前  条件1・6 FALSE',.55,5.31,7.1,.48,25,{bold:true,color:red});
text('保護後  条件1〜6 TRUE',.55,5.92,7.1,.48,25,{bold:true,color:green});
text(`${d.TC306.scenarios}配置・${d.TC306.checks} check\nEva：invalid 0 / unknown 0`,8.14,5.56,4.65,.77,20);
links('TC306',[['AI候補','stage01/group_proposals.json'],['区間とR/W','stage01/inventory.json'],['モデルのEva','model/eva.log'],['raw / final','stage02/results.json']]);
note(['元コード: ../../examples/TC306/src/tasks.c、空SchM定義: src/schm.c、保護キーワード: project.json exclusive_areas','関数本体を解析して実OS排他を証明したわけではなく、ユーザー指定の区間保護をモデル化。','保護前raw=false,true,true,true,true,false。finalは全true。']);

begin('設計意図はAIが推測し、人が確定する','AIがしたこと  |  自動候補をそのまま確定しない');
arrow(4.1,3.06,4.85,3.06);arrow(8.45,3.06,9.15,3.06);
node('自動候補','比較関係・同値の連続W\ngroup_proposals.json',.55,2.35,3.55,1.52);
node('AIのコード読解','目的とアクセス順を確認\n候補を採用／追加／取下げ',4.85,2.35,3.6,1.52);
node('人が確認したCSV','グループ番号を訂正\n02は再推測しない',9.15,2.35,3.6,1.52);
text('TC219では stamp と flag の候補を取下げた',.55,4.35,12.2,.58,26,{bold:true});
text('同じ定数の連続書込みだけでは、一括更新が必要とは言えない。\n比較・一括参照もないため独立アクセスとして扱い、判断理由をJSONに保存。',.55,5.13,12.2,.84,21);
text('実プロジェクトでは設計者が確認。コードから設計意図を完全に復元したとは扱わない。',.55,6.17,12.2,.40,19,{color:muted});
links('TC219',[['元の候補','stage01/group_proposals.json'],['AI判断','stage01/ai_group_decisions.json'],['01のCSV','stage01/RAM一覧.csv']],6.63);
note(['AIの実際の判断: ../../examples/TC219/ai_group_decisions.json','テストデータでは個別整数型のアクセス検証を意図。実設計の確認の代替ではない。','テストの人手省略と本番のHUMAN_REVIEWEDを混同しない。']);

begin('グループの判定をExcelでも1つにする','表示要件  |  TC220の4変数グループ');
s.addImage({path:d.matrix,x:.55,y:1.82,w:7.45,h:3.77});
text('変数名は時計回り90度',8.40,1.91,4.36,.8,24,{bold:true});
text('条件4、5、6の各行を\nグループの4列で結合',8.40,3.11,4.36,1.0,24,{bold:true});
text('重複所属ならグループ別に\n同じRAMの列を再掲する',8.40,4.65,4.36,1.0,21);
text('判定表の近似プレビュー。実ファイルの結合・回転・数式は別途検査済み。',.55,5.94,12.2,.45,20,{color:muted});
text('02_判定結果.xlsx を開く',.55,6.54,9.0,.3,18,{color:blue,hyperlink:{url:'02_判定結果.xlsx'}});
note(['Excel: 02_判定結果.xlsx、excel_layout.json、qa/verification.json','PNGはPillow近似描画。Excel本体はopenpyxl + LibreOfficeで回転・結合・キャッシュ値を検査。']);

begin('低・中・高の入れ子割込みも列挙する','3段階の優先度  |  TC405・TC407');
arrow(2.5,2.8,3.1,2.8);arrow(4.7,2.8,5.3,2.8);arrow(6.9,2.8,7.5,2.8);arrow(9.1,2.8,9.7,2.8);
for(const [head,body,x] of [['低','R g',.55],['中','W other',3.1],['高','W g',5.3],['中','W other',7.5],['低','R g',9.7]])node(head,body,x,2.13,head==='低'&&x>9?3.05:1.95,1.30);
text('実行中より高いタスクだけ開始できる。SchM区間内では新たな割込みを禁止。',.55,3.91,12.2,.58,21);
text('低−中 ／ 低−高 ／ 中−高',.55,4.73,8.5,.51,26,{bold:true,color:blue});
text('全3ペアの結果をAND集約し、Excelに内訳を残す。',.55,5.38,12.2,.53,24);
text('TC407：低だけを保護しても中−高のW/Wは残るため、条件1はFALSE。',.55,6.14,12.2,.40,20,{color:red});
links('TC405',[['3タスクの時系列','stage02/results.json'],['低−高のEva','pairs/low__high/model/eva.log']],6.62);
note(['全3タスクの固定優先度スタックを列挙してから、3ペアへの射影でC監視器/Evaと照合。','TC405では low,middle,high,middle,low のアクセス順を含む。','TC407は低−中、低−高が保護されても中−高の条件1がFALSE。']);

begin(`${d.freeze.tests_passed}件で正常・違反・停止を確かめた`,'試験範囲  |  期待値は解析器から分離');
text(String(d.counts.analyzed),.55,1.81,1.65,.89,50,{bold:true,color:green});text('解析完了',2.44,2.09,3.0,.4,24);
text(String(d.counts.blocked),6.71,1.81,1.65,.89,50,{bold:true,color:blue});text('期待した解析停止',8.57,2.09,4.2,.4,24);
const rows=[['100台 / 8件','最小6条件と正常対照'],['200台 / 20件','マクロ・整数型・構造体配列・最大8 TU'],['300台 / 18件','SchMの全体／部分／分断／誤用'],['400台 / 11件','低・中・高、入れ子、全ペア、空タスク'],['900台 / 18件','呼出し64段、配列4096、上限+1、複合']];
rows.forEach((r,i)=>{const y=2.93+i*.49;rule(.55,y-.08,12.78,y-.08);text(r[0],.55,y,3.3,.33,19,{bold:true});text(r[1],4.12,y,8.62,.33,19);});
text(`${d.freeze.schedules}割込み配置 ／ ${d.freeze.checks}要求check ／ 追加の受渡し試験 ${d.freeze.contract_tests}件`,.55,5.84,12.2,.47,24,{bold:true});
text('未対応や上限超過をTRUEにせず、理由を付けて停止する。',.55,6.43,12.2,.36,20,{color:muted});
note(['outputs/project_suite/test_results.json','outputs/contract_tests/results.json','テスト結果.md、03_テスト結果.xlsx','同時性グループの確認だけはテスト時に省略している。']);

begin('検証した範囲を分けて結果を読む','結論の適用範囲');
text('今回確認したこと',.55,1.93,5.95,.49,26,{bold:true,color:green});
text('元Cの逐次Eva：実行時アラーム0\n抽出モデル：Python / C / Eva一致\n仕様ケース：期待するTRUE/FALSE／停止',.55,2.73,6.0,1.68,21);
text('前提と今後の拡張対象',7.15,1.93,5.63,.49,26,{bold:true,color:blue});
text('単一コア・2〜3タスク・各1回\n整数の個々のアクセスは不可分\nSchM指定区間の保護効果を仮定',7.15,2.73,5.60,1.68,21);
rule(.55,4.69,12.78,4.69);
text('一般C全体、共有値で変わる経路、実機OSの排他は未証明。',.55,5.04,12.2,.64,26,{bold:true});
text('新規プロジェクトでは01で停止理由と推測根拠を確認し、設計者のレビューへ渡す。',.55,6.02,12.2,.56,21);
note(['AI_Instruction_01.md 対応範囲、AI_Instruction_02.md 判定モデルと停止方針','元Cとモデルの完全等価性証明ではないことを明示。']);

begin('Markdownから同じ結果を再生成できる','実行と引継ぎ');
arrow(4.1,3.03,4.85,3.03);arrow(8.45,3.03,9.15,3.03);
node('AI_Instruction_01','設定 → ビルド → RAM抽出\nAI推測 → 人の確認',.55,2.36,3.55,1.43);
node('AI_Instruction_02','確認済みCSV → 6条件\nモデル検証 → Excel',4.85,2.36,3.60,1.43);
node('全試験 → コード固定','code_freeze.jsonを照合\n最後にこのPowerPoint',9.15,2.36,3.60,1.43);
text('Windows  run_all.bat     ／     WSL  bash scripts/run_all.sh',.55,4.39,12.2,.49,24,{bold:true});
text('clean.bat：成果物とビルド生成物を削除\nclean_temp.bat：旧版の既知の残骸を一度整理',.55,5.21,12.2,.87,22);
text('Instruction 01',.55,6.49,3.4,.32,18,{color:blue,hyperlink:{url:'../../AI_Instruction_01.md'}});
text('Instruction 02',4.40,6.49,3.4,.32,18,{color:blue,hyperlink:{url:'../../AI_Instruction_02.md'}});
text('全試験の記録',8.65,6.49,3.4,.32,18,{color:blue,hyperlink:{url:'テスト結果.md'}});
note(['PowerPoint作成開始前のfreeze時刻: '+d.freeze.time_utc,'解析、試験、Excel生成コードのハッシュを検証してから本資料を作成。','依存のartifact-toolが環境に存在しなかったためPptxGenJSでネイティブ図形のPPTXを生成。PDFは生成しない。']);

begin('根拠ファイルへ戻れるように保存する','証拠索引');
const index=[['ビルド条件','TCxxx/build/compile_commands.json'],['展開とAST','TCxxx/clang/tu_NNN/preprocessed.i / ast.json'],['抽出・AI推測','TCxxx/stage01/inventory.json / group_proposals.json'],['元CのEva','TCxxx/frama/original_low.log / original_high.log'],['割込みと判定','TCxxx/stage02/results.json'],['C実行とモデルEva','TCxxx/model/native.log / eva.log / model_map.json']];
index.forEach((r,i)=>{let y=1.86+i*.62;rule(.55,y-.11,12.78,y-.11);text(r[0],.55,y,3.2,.42,20,{bold:true});text(r[1],3.8,y,9.0,.45,18);});
text('基準ディレクトリ：outputs/project_suite/   （TC205・TC209・TC306を参照）',.55,5.88,12.2,.45,20);
text('一次資料  Clang AST ／ Compilation Database ／ Frama-C Eva ／ AUTOSAR RTE',.55,6.48,12.2,.37,17,{color:muted});
note(['https://clang.llvm.org/docs/IntroductionToTheClangAST.html','https://clang.llvm.org/docs/JSONCompilationDatabase.html','https://github.com/rizsotto/Bear','https://frama-c.com/fc-plugins/eva.html','https://www.autosar.org/fileadmin/standards/R24-11/CP/AUTOSAR_CP_SWS_RTE.pdf','PPTX authoring fallback: https://github.com/gitbrent/PptxGenJS','PNG export: https://api.libreoffice.org/docs/idl/ref/servicecom_1_1sun_1_1star_1_1drawing_1_1GraphicExportFilter.html']);
layout.push({slide:n,boxes});
const warnings=[];
for(const page of layout){
 for(const b of page.boxes){if(b.x<0||b.y<0||b.x+b.w>W+.005||b.y+b.h>H+.005)warnings.push({slide:page.slide,type:'out_of_bounds',text:b.text});}
 for(let i=0;i<page.boxes.length;i++)for(let j=i+1;j<page.boxes.length;j++){
   const a=page.boxes[i],b=page.boxes[j];
   const ix=Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x),iy=Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y);
   if(ix>.03&&iy>.03)warnings.push({slide:page.slide,type:'text_overlap',a:a.text,b:b.text});
 }
}
fs.writeFileSync(path.join(d.out,'qa','presentation_layout.json'),JSON.stringify({layout,warnings,sources},null,2));
if(warnings.length)throw Error('Slide layout warnings: '+JSON.stringify(warnings));
await p.writeFile({fileName:path.join(d.out,'04_解析フローと代表例.pptx')});
console.log(`PPTX: ${n} slides; no text-box overlaps or out-of-bounds boxes.`);
'''


def main():
    freeze=read_json(OUT/"code_freeze.json")
    for name,sha in freeze["files"].items():
        if digest(ROOT/name)!=sha:
            raise RuntimeError("Analysis code changed after freeze: "+name)
    data={"freeze":freeze,"out":str(OUT),"matrix":str(OUT/"qa/TC220_matrix.png")}
    suite=read_json(ROOT/"outputs/project_suite/test_results.json")
    data["counts"]={"analyzed":sum(c["actual"]["status"]=="ANALYZED" for c in suite["cases"]),"blocked":sum(c["actual"]["status"]=="BLOCKED" for c in suite["cases"])}
    for cid in ("TC205","TC209","TC306"):
        result=read_json(ROOT/f"outputs/project_suite/{cid}/stage02/results.json")
        original=read_json(ROOT/f"outputs/project_suite/{cid}/stage01/inventory.json")
        data[cid]={"lowR":sum(e["mode"]=="R" for e in original["tasks"][0]["events"]),
                   "highW":sum(e["mode"]=="W" for e in original["tasks"][1]["events"]),
                   "tu":result["metrics"]["translation_units"],"elements":result["metrics"]["storage_elements"],
                   "scenarios":result["verification"]["scenarios"],"checks":result["verification"]["requirement_checks"]}
    assert data["TC205"]["lowR"]==2 and data["TC209"]["elements"]==48
    assert "1:0=2" in (ROOT/"outputs/project_suite/TC205/model/native.log").read_text(encoding="utf-8")
    assert "check 'sc_1_ram_0_rule_2' got status invalid" in (ROOT/"outputs/project_suite/TC205/model/eva.log").read_text(encoding="utf-8")
    dependencies=Path.home()/".local/share/static-analysis-presentation"
    if not (dependencies/"node_modules/pptxgenjs/package.json").exists():
        subprocess.run(["npm","install","--prefix",str(dependencies),"--no-audit","--no-fund","pptxgenjs@4.0.1"],check=True)
    (OUT/"qa").mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="codex-presentations-static-analysis-") as scratch:
        work=Path(scratch)
        os.symlink(dependencies/"node_modules",work/"node_modules",target_is_directory=True)
        (work/"build.mjs").write_text(JS,encoding="utf-8")
        write_json(work/"data.json",data)
        run=subprocess.run(["node",str(work/"build.mjs"),str(work/"data.json")],text=True,capture_output=True)
        (OUT/"qa/presentation_build.log").write_text(run.stdout+run.stderr,encoding="utf-8")
        if run.returncode:raise RuntimeError(run.stdout+run.stderr)
        print(run.stdout)
    write_json(OUT/"qa/presentation_build.json",{"code_freeze_verified":True,"freeze_time":freeze["time_utc"],
        "authoring":"PptxGenJS 4.0.1 (artifact-tool unavailable)","source_hash":digest(Path(__file__)),
        "temporary_workspace":"removed automatically after build; installed dependencies are retained", "pdf_generated":False})


if __name__=="__main__":main()
