"""Import user-edited RAM membership from an exported workbook; do not invent approval."""
import argparse
import csv
from pathlib import Path
from openpyxl import load_workbook
from project_analysis.common import load_project, read_json, digest, write_json
from project_analysis.rules import read_ram


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--config",type=Path,required=True)
    p.add_argument("--workbook",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    args=p.parse_args()
    config=load_project(args.config)
    data=read_json(config["_out"]/"stage01/inventory.json")
    book=load_workbook(args.workbook,data_only=False)
    ws=book["RAM一覧"]
    rows=[]
    for row in ws.iter_rows(min_row=2,values_only=True):
        if row[0]!=config["project_id"]:
            continue
        group=row[3]
        if isinstance(group,(int,float)) and int(group)==group:
            group=str(int(group))
        if not isinstance(group,str) or group.startswith("="):
            raise ValueError("Group must be a literal number, comma-separated numbers, or '-'")
        rows.append([row[1],row[2],group])
    args.output.parent.mkdir(parents=True,exist_ok=True)
    temporary=args.output.with_name(args.output.name+".tmp")
    with temporary.open("w",encoding="utf-8-sig",newline="") as handle:
        writer=csv.writer(handle)
        writer.writerow(["ファイル名","RAM名","同時性グループ"])
        writer.writerows(rows)
    read_ram(temporary,data["inventory"])
    temporary.replace(args.output)
    print("RAM CSV:",args.output)
    print("ram_csv_sha256:",digest(args.output))
    print("inventory_sha256:",digest(config["_out"]/"stage01/inventory.json"))
    print("Human approval has not been set. Complete the review JSON after actual review.")


if __name__=="__main__":
    main()
