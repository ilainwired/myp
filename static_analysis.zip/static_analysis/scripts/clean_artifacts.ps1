param(
    [ValidateSet('Normal','Temp')][string]$Mode = 'Normal',
    [switch]$DryRun,
    [string]$Workspace
)
$ErrorActionPreference = 'Stop'
$taskRoot = if ($Workspace) { [IO.Path]::GetFullPath($Workspace) } else { [IO.Path]::GetFullPath((Split-Path $PSScriptRoot -Parent)) }
$taskPrefix = $taskRoot.TrimEnd('\','/') + [IO.Path]::DirectorySeparatorChar
if (-not (Test-Path -LiteralPath (Join-Path $taskRoot 'scripts') -PathType Container)) {
    throw "Not a project workspace: $taskRoot"
}
$targets = [Collections.Generic.List[string]]::new()
if ($Mode -eq 'Normal') {
    $targets.Add((Join-Path $taskRoot 'outputs'))
    $targets.Add((Join-Path $taskRoot 'cleanup_remaining.txt'))
    $exampleRoot = Join-Path $taskRoot 'examples'
    if (Test-Path -LiteralPath $exampleRoot) {
        foreach ($project in Get-ChildItem -LiteralPath $exampleRoot -Directory) {
            if ($project.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
            $targets.Add((Join-Path $project.FullName '.build'))
        }
    }
    foreach ($folder in @('scripts','tests')) {
        $cacheRoot = Join-Path $taskRoot $folder
        if (Test-Path -LiteralPath $cacheRoot) {
            foreach ($cache in Get-ChildItem -LiteralPath $cacheRoot -Directory -Recurse -Filter '__pycache__') {
                $targets.Add($cache.FullName)
            }
        }
    }
} else {
    $legacy = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'cleanup_legacy.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($relative in $legacy.paths) { $targets.Add((Join-Path $taskRoot $relative)) }
}
$failed = [Collections.Generic.List[string]]::new()
foreach ($candidate in ($targets | Select-Object -Unique)) {
    $resolved = [IO.Path]::GetFullPath($candidate)
    if (-not $resolved.StartsWith($taskPrefix,[StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing target outside workspace: $resolved"
    }
    if (-not (Test-Path -LiteralPath $resolved)) { continue }
    # Never traverse a renamed/symlinked directory into another workspace.
    $cursor = Get-Item -LiteralPath $resolved -Force
    $hasLink = $false
    while ($null -ne $cursor -and $cursor.FullName -ne $taskRoot) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { $hasLink = $true; break }
        $cursor = if ($cursor -is [IO.DirectoryInfo]) { $cursor.Parent } else { $cursor.Directory }
    }
    if ($hasLink) { $failed.Add("Reparse point requires manual check: $resolved"); continue }
    if ($DryRun) { Write-Output "WOULD REMOVE: $resolved"; continue }
    try {
        Remove-Item -LiteralPath $resolved -Recurse -Force
        Write-Output "REMOVED: $resolved"
    } catch {
        $failed.Add("$resolved : $($_.Exception.Message)")
    }
}
if ($failed.Count) {
    $report = Join-Path $taskRoot 'cleanup_remaining.txt'
    $failed | Set-Content -LiteralPath $report -Encoding utf8
    $failed | ForEach-Object { Write-Output "NOT REMOVED: $_" }
    Write-Output "Remaining paths: $report"
    exit 1
}
Write-Output "Cleanup $Mode complete. DryRun=$DryRun"
