@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\clean_artifacts.ps1" -Mode Normal %*
exit /b %ERRORLEVEL%
