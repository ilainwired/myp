@echo off
setlocal
wsl.exe --cd "%~dp0." --exec bash scripts/run_all.sh
exit /b %ERRORLEVEL%
