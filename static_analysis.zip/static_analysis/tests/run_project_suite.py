"""Independent expectations. These are never imported by the project analyzer."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from project_analysis.common import load_project, read_json, write_json


def verify(spec, config, status):
    expected, errors = spec["expected"], []
    if status["status"] != expected["status"]:
        errors.append(f"status expected={expected['status']} actual={status}")
    elif status["status"] == "BLOCKED":
        if expected["reason_contains"] not in status.get("reason", ""):
            errors.append("blocking reason mismatch: " + status.get("reason", ""))
        if (config["_out"] / "stage02/results.json").exists():
            errors.append("blocked case left a successful verdict")
    else:
        actual = read_json(config["_out"] / "stage02/results.json")
        for label in ("final", "raw"):
            oracle = expected["violations"] if label == "final" else expected.get("raw_violations")
            if oracle is None:
                continue
            for ram in actual["ram"]:
                failures = [i for i, passed in enumerate(ram[label], 1) if not passed]
                if failures != oracle.get(ram["id"], []):
                    errors.append(f"{label} {ram['id']}: {failures} != {oracle.get(ram['id'], [])}")
            if set(oracle) - {r["id"] for r in actual["ram"]}:
                errors.append("expected RAM absent")
        for key, value in expected["metrics"].items():
            if actual["metrics"].get(key) != value:
                errors.append(f"metric {key}: {actual['metrics'].get(key)} != {value}")
        if expected.get("pair_violations") is not None:
            observed={p["id"]:{r["id"]:[i for i,v in enumerate(r["final"],1) if not v] for r in p["ram"] if not all(r["final"])} for p in actual["pairs"]}
            if observed!=expected["pair_violations"]:
                errors.append(f"pair verdicts: {observed} != {expected['pair_violations']}")
        status.update({"metrics": actual["metrics"], "verification": actual["verification"],
                       "ram_verdicts": {r["id"]: [i for i, p in enumerate(r["final"], 1) if not p] for r in actual["ram"]}})
    return errors


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, default=ROOT / "tests/project_suite.json")
    parser.add_argument("--ids", nargs="*")
    parser.add_argument("--reuse", action="store_true", help="Only verify existing results; do not run tools")
    args = parser.parse_args()
    manifest = read_json(args.manifest)
    selected = [s for s in manifest["cases"] if not args.ids or s["id"] in args.ids]
    report = {"classification": manifest["classification"], "cases": [], "run_mode": "reuse" if args.reuse else "executed"}
    for spec in selected:
        start = time.monotonic()
        path = ROOT / spec["config"]
        config = load_project(path)
        if not args.reuse:
            execution = subprocess.run([sys.executable, str(ROOT / "scripts/analyze_project.py"), "test", "--config", str(path)], text=True, capture_output=True)
            config["_out"].mkdir(parents=True, exist_ok=True)
            (config["_out"] / "runner.log").write_text(execution.stdout + execution.stderr, encoding="utf-8")
        status_path = config["_out"] / "status.json"
        status = read_json(status_path) if status_path.exists() else {"status": "ERROR", "reason": "no status.json; inspect runner.log"}
        errors = verify(spec, config, status)
        record = {**spec, "actual": status, "pass": not errors, "errors": errors,
                  "elapsed_seconds": round(time.monotonic()-start, 3), "output": str(config["_out"].relative_to(ROOT))}
        report["cases"].append(record)
        print(spec["id"], "PASS" if not errors else "FAIL", status["status"], "; ".join(errors), flush=True)
        report["passed"] = sum(c["pass"] for c in report["cases"])
        report["total"] = len(report["cases"])
        write_json(ROOT / "outputs/project_suite" / ("test_results_subset.json" if args.ids else "test_results.json"), report)
    print(f"{report['passed']}/{report['total']} PASS", flush=True)
    return 0 if report["passed"] == report["total"] else 1


if __name__ == "__main__":
    sys.exit(main())
