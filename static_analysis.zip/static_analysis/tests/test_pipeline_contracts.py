"""Integration tests at the AI/human/project boundary; no fake human approval in delivered reports."""
from pathlib import Path
import csv
import shutil
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"scripts"))
from project_analysis.common import AnalysisBlocked,load_project,read_json,write_json,digest
from project_analysis.pipeline import stage01,stage02
from project_analysis.rules import read_ram
from project_analysis.multitask import enumerate_three


class Contracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project=ROOT/"outputs/contract_tests/relocated project"
        cls.project.mkdir(parents=True,exist_ok=True)
        shutil.copytree(ROOT/"examples/TC104",cls.project,dirs_exist_ok=True,ignore=shutil.ignore_patterns(".build"))
        cls.path=cls.project/"project.json"
        cfg=read_json(cls.path)
        cfg["purpose"]="production"
        cfg["output_directory"]="analysis"
        write_json(cls.path,cfg)
        cls.config=load_project(cls.path)
        cls.data=stage01(cls.config)
        cls.ram=cls.config["_out"]/"stage01/RAM一覧.csv"
        cls.inventory=cls.config["_out"]/"stage01/inventory.json"

    def test_01_relocated_project_and_macroless_make(self):
        self.assertEqual(self.data["metrics"]["ram_count"],2)
        self.assertNotIn("examples",str(self.config["_root"]))
        self.assertTrue((self.config["_out"]/"build/compile_commands.json").exists())

    def test_02_production_cannot_skip_human(self):
        with self.assertRaisesRegex(AnalysisBlocked,"purpose=test"):
            stage02(self.config,test_mode=True)

    def test_03_production_requires_review(self):
        with self.assertRaisesRegex(AnalysisBlocked,"human review"):
            stage02(self.config)

    def test_04_reviewed_csv_is_used_without_reinference(self):
        changed=self.project/"reviewed.csv"
        with changed.open("w",encoding="utf-8-sig",newline="") as handle:
            writer=csv.writer(handle)
            writer.writerow(["ファイル名","RAM名","同時性グループ"])
            for r in self.data["inventory"]:
                writer.writerow([r["file"],r["name"],"-"])
        review=self.project/"test_simulated_review.json"
        write_json(review,{"approved":True,"reviewer":"AUTOMATED_TEST_FIXTURE_NOT_A_PERSON","reviewed_at":"TEST_FIXTURE",
                           "ram_csv_sha256":digest(changed),"inventory_sha256":digest(self.inventory)})
        result=stage02(self.config,changed,review)
        self.assertEqual(result["groups"],[])
        self.assertTrue(all(r["final"][3] for r in result["ram"]))
        changed.write_text(changed.read_text(encoding="utf-8-sig")+"\n",encoding="utf-8-sig")
        with self.assertRaisesRegex(AnalysisBlocked,"hashes"):
            stage02(self.config,changed,review)

    def test_05_changed_source_invalidates_stage01(self):
        source=self.project/"src/tasks.c"
        before=source.read_bytes()
        try:
            source.write_bytes(before+b"\n/* changed */\n")
            with self.assertRaisesRegex(AnalysisBlocked,"input changed"):
                stage02(self.config)
        finally:
            source.write_bytes(before)

    def test_06_missing_or_duplicate_ram_rejected(self):
        bad=self.project/"bad.csv"
        lines=self.ram.read_text(encoding="utf-8-sig").splitlines()
        for content in ("\n".join(lines[:2]),"\n".join(lines+[lines[1]])):
            bad.write_text(content+"\n",encoding="utf-8-sig")
            with self.assertRaises(AnalysisBlocked):
                read_ram(bad,self.data["inventory"])

    def test_07_input_groups_format_validated(self):
        bad=self.project/"bad.csv"
        before=self.ram.read_text(encoding="utf-8-sig")
        bad.write_text(before.replace(",1",",0"),encoding="utf-8-sig")
        with self.assertRaisesRegex(AnalysisBlocked,"positive integers"):
            read_ram(bad,self.data["inventory"])

    def test_08_three_task_nested_preemption(self):
        tasks=[{"id":name,"priority":priority,"steps":[{"kind":"access","mode":"R","index":i} for i in range(count)]}
               for name,priority,count in [("low",1,2),("middle",2,2),("high",3,1)]]
        schedules=enumerate_three(tasks,1000)
        self.assertTrue(any([e["task"] for e in s["timeline"]]==["low","middle","high","middle","low"] for s in schedules))
        # Once high has started, it must finish before lower priorities resume.
        for schedule in schedules:
            seq=[e["task"] for e in schedule["timeline"]]
            middle=[i for i,t in enumerate(seq) if t=="middle"]
            self.assertNotIn("low",seq[min(middle):max(middle)+1])

    def test_09_three_task_protected_intervals(self):
        steps=[{"kind":"enter","area":"A"},{"kind":"access","mode":"W"},{"kind":"access","mode":"W"},{"kind":"exit","area":"A"}]
        tasks=[{"id":name,"priority":i+1,"steps":steps} for i,name in enumerate(["low","middle","high"])]
        schedules=enumerate_three(tasks,1000)
        self.assertEqual(len(schedules),6)
        for schedule in schedules:
            owner=None
            for event in schedule["timeline"]:
                if owner is not None:self.assertEqual(event["task"],owner)
                if event["kind"]=="enter":owner=event["task"]
                if event["kind"]=="exit":owner=None

    def test_10_three_task_limit_is_fail_closed(self):
        tasks=[{"id":name,"priority":i+1,"steps":[{"kind":"access"}]} for i,name in enumerate(["low","middle","high"])]
        with self.assertRaisesRegex(AnalysisBlocked,"schedules limit"):
            enumerate_three(tasks,1)


if __name__=="__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Contracts))
    write_json(ROOT/"outputs/contract_tests/results.json",{"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"success":result.wasSuccessful(),
        "note":"Human-review JSON is a clearly named automated fixture, not a real approval. No demo delivery is marked human-reviewed."})
    sys.exit(0 if result.wasSuccessful() else 1)
