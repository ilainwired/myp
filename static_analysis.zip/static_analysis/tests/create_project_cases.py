"""Test-data generator only. The analyzer never imports this file or knows its paths."""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "examples"
CASES = []

SCHM_HEADER = "\n".join(f"void SchM_{op}_Test_{area}(void);" for area in ("A", "B") for op in ("Enter", "Exit")) + "\n"
SCHM_SOURCE = '#include "SchM_Test.h"\n' + "\n".join(f"void SchM_{op}_Test_{area}(void) {{ }}" for area in ("A", "B") for op in ("Enter", "Exit")) + "\n"


def area(name="A"):
    return {"id": name, "enter": f"SchM_Enter_Test_{name}", "exit": f"SchM_Exit_Test_{name}",
            "assumption": "Enter/Exit are designated protection keywords; bodies may be empty"}


def add(number, title, purpose, code=None, *, files=None, expected=None, raw=None, blocked=None,
        areas=None, defines=None, limits=None, metrics=None, dirname=None, makefile="Makefile"):
    cid = f"TC{number}"
    directory = DEST / (dirname or cid)
    directory.mkdir(parents=True, exist_ok=True)
    payload = dict(files or {"src/tasks.c": code})
    if areas or any("SchM_" in text for text in payload.values()):
        payload["include/SchM_Test.h"] = SCHM_HEADER
        payload["src/schm.c"] = SCHM_SOURCE
    transformed = {}
    for name, text in payload.items():
        text = re.sub(r"\bLOW\b", cid + "_low", text)
        text = re.sub(r"\bHIGH\b", cid + "_high", text)
        text = re.sub(r"\bMID\b", cid + "_middle", text)
        text = re.sub(r"\bg(?:_[A-Za-z0-9_]+)?\b", lambda m: cid + "_" + m[0], text)
        transformed[name] = text
    combined = "\n".join(transformed.values())
    ltype = re.search(r"\b(int|void)\s+" + cid + r"_low\s*\(", combined)[1]
    htype = re.search(r"\b(int|void)\s+" + cid + r"_high\s*\(", combined)[1]
    middle = re.search(r"\b(int|void)\s+" + cid + r"_middle\s*\(", combined)
    mid_decl = f"{middle[1]} {cid}_middle(void);\n" if middle else ""
    mid_call = f"{cid}_middle();" if middle else ""
    transformed["src/main.c"] = f"{ltype} {cid}_low(void);\n{htype} {cid}_high(void);\n{mid_decl}int main(void) {{ {cid}_low(); {mid_call} {cid}_high(); return 0; }}\n"
    flags = " ".join("-D" + value for value in (defines or []))
    transformed[makefile] = f"""CC := clang
CFLAGS := -std=c11 -Wall -Wextra -Werror -Iinclude {flags}
SOURCES := $(wildcard src/*.c)
OBJECTS := $(patsubst src/%.c,.build/%.o,$(SOURCES))
.PHONY: all
all: .build/app
.build/app: $(OBJECTS)
\t$(CC) $(OBJECTS) -o $@
.build/%.o: src/%.c
\t@mkdir -p .build
\t$(CC) $(CFLAGS) -c $< -o $@
"""
    for name, text in transformed.items():
        path = directory / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    config = {"schema_version": 2, "project_id": cid, "purpose": "test",
              "repository": {"path": ".", "description": "local project fixture; no source list in analyzer"},
              "build": {"working_directory": ".", "makefile": makefile, "target": "all", "variables": []},
              "tasks": [{"id": "low", "entry": cid + "_low", "priority": 1}, {"id": "high", "entry": cid + "_high", "priority": 2}],
              "exclusive_areas": areas or [], "limits": limits or {},
              "output_directory": "../../outputs/project_suite/" + cid}
    if middle:
        config["tasks"]=[{"id":"low","entry":cid+"_low","priority":1},{"id":"middle","entry":cid+"_middle","priority":2},{"id":"high","entry":cid+"_high","priority":3}]
    (directory / "project.json").write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    def rename(name):
        return re.sub(r"\bg(?:_[A-Za-z0-9_]+)?\b", lambda m: cid + "_" + m[0], name)
    spec = {"id": cid, "category": "最小仕様" if number < 200 else "構成・複合" if number < 300 else "SchM排他" if number < 400 else "3段階優先度" if number < 900 else "境界・解析停止",
            "title": title, "purpose": purpose, "config": str((directory / "project.json").relative_to(ROOT)).replace("\\", "/"),
            "expected": {"status": "BLOCKED" if blocked else "ANALYZED", "reason_contains": blocked,
                         "violations": {rename(k): v for k, v in (expected or {}).items()},
                         "raw_violations": None if raw is None else {rename(k): v for k, v in raw.items()},
                         "metrics": metrics or {}}, "source_files": len([p for p in transformed if p.endswith(".c")])}
    (directory / "test_expectation.json").write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    CASES.append(spec)
    return transformed


def protect(code, low=True, high=True, low_area="A", high_area="A"):
    # Test templates explicitly place markers so no code parser is hidden here.
    for marker, enabled, name in (("L", low, low_area), ("H", high, high_area)):
        code = code.replace(f"{marker}_ENTER", f"SchM_Enter_Test_{name}();" if enabled else "")
        code = code.replace(f"{marker}_EXIT", f"SchM_Exit_Test_{name}();" if enabled else "")
    return '#include "SchM_Test.h"\n' + code


def main():
    simple = {
        101: ("上下の書込み", "条件1の最小違反", "int g;\nvoid LOW(void){g=1;}\nvoid HIGH(void){g=2;}\n", {"g": [1]}),
        102: ("下位2回読出し", "条件2の最小違反", "int g;\nint LOW(void){int a=g;int b=g;return a==b;}\nvoid HIGH(void){g=1;}\n", {"g": [2]}),
        103: ("下位2回書込み", "条件3の最小違反", "int g;\nvoid LOW(void){g=1;g=2;}\nint HIGH(void){return g;}\n", {"g": [3]}),
        104: ("グループ読出し", "各変数1回でも条件4違反", "int g_a,g_b;\nint LOW(void){int a=g_a;int b=g_b;return a==b;}\nvoid HIGH(void){g_a=1;g_b=1;}\n", {"g_a": [4], "g_b": [4]}),
        105: ("グループ書込みと読出し", "各変数1回でも条件5違反", "int g_a,g_b;\nvoid LOW(void){g_a=1;g_b=1;}\nint HIGH(void){int a=g_a;int b=g_b;return a==b;}\n", {"g_a": [5], "g_b": [5]}),
        106: ("グループ双方書込み", "条件1と6の重複違反", "int g_a,g_b;\nvoid LOW(void){g_a=1;g_b=1;}\nvoid HIGH(void){g_a=2;g_b=2;}\n", {"g_a": [1, 6], "g_b": [1, 6]}),
    }
    originals = {}
    for number, (title, purpose, code, expected) in simple.items():
        originals[number] = add(number, title, purpose, code, expected=expected)
    add(107, "読出し同士", "書込みがない正常対照", "int g; int LOW(void){return g;} int HIGH(void){return g;}")
    add(108, "別要素への書込み", "[]表記でも異なる添字は別RAMとして判定", "int g[2]; void LOW(void){g[0]=1;} void HIGH(void){g[1]=2;}")
    add(201, "二重ポインタ", "&p、**q、補助関数呼出し", "int g; static void set(int *p){int **q=&p;**q=1;} void LOW(void){set(&g);} void HIGH(void){g=2;}", expected={"g": [1]})
    add(202, "extern・複数ファイル", "定義と参照をリンクして1 RAMに統合", files={"include/ram.h": "extern int g;\n", "src/ram.c": "int g;\n", "src/low.c": '#include "ram.h"\nint LOW(void){int a=g;int b=g;return a==b;}\n', "src/high.c": '#include "ram.h"\nvoid HIGH(void){g=1;}\n'}, expected={"g": [2]}, metrics={"translation_units": 4})
    add(203, "別TUの同名static", "同名のprivate RAM・関数を混同しない", files={"src/a.c": "static int g; static void helper(void){g=1;} void LOW(void){helper();}\n", "src/b.c": "static int g; static void helper(void){g=2;} void HIGH(void){helper();}\n"}, metrics={"ram_count": 2})
    add(204, "複文マクロ", "do-while(0)と書込み2回", "#define SET2(p) do { *(p)=1; *(p)=2; } while(0)\nint g; void LOW(void){SET2(&g);} int HIGH(void){return g;}\n", expected={"g": [3]})
    add(205, "マクロ引数の二重評価", "見た目1回でも実際のRは2回", "#define TWICE(x) ((x)+(x))\nint g; int LOW(void){return TWICE(g);} void HIGH(void){g=1;}\n", expected={"g": [2]})
    switch = "int g,g_other; void LOW(void){g=1;} void HIGH(void){\n#if MODE\ng=2;\n#else\ng_other=2;\n#endif\n}\n"
    add(206, "ビルドdefine ON", "Makefileの-DMODE=1を捕捉", switch, expected={"g": [1]}, defines=["MODE=1"])
    add(207, "ビルドdefine OFF", "同じソースでもコンパイル条件で判定が変わる", switch, defines=["MODE=0"])
    add(208, "配列長・添字マクロ", "定数式による配列長16と末尾添字15", "#define N (1u<<4)\n#define LAST (N-1)\nint g[N]; void LOW(void){g[LAST]=1;} void HIGH(void){g[15]=2;}\n", expected={"g[]": [1]}, metrics={"storage_elements": 16})
    deep_header = "struct C {int values[2];}; struct B {struct C c[4];}; struct A {struct B b[3];}; extern struct A g[2];\n"
    add(209, "A配列→B配列→C配列", "2×3×4×2の48要素、末端メンバーを同定", files={"include/deep.h": deep_header,
        "src/ram.c": '#include "deep.h"\nstruct A g[2];\n', "src/low.c": '#include "deep.h"\nint LOW(void){int a=g[1].b[2].c[3].values[1];int b=g[1].b[2].c[3].values[1];return a==b;}\n',
        "src/high.c": '#include "deep.h"\nvoid HIGH(void){g[1].b[2].c[3].values[1]=3;}\n'}, expected={"g[].b[].c[].values[]": [2]}, metrics={"storage_elements": 48})
    add(210, "別要素を1回ずつ読出し", "R合計2を同一要素R2に誤分類しない", "int g[2]; int LOW(void){int a=g[0];int b=g[1];return a==b;} void HIGH(void){g[0]=1;}\n")
    add(211, "重複同時性グループ", "{a,b}と{b,c}を独立に保持", "int g_a,g_b,g_c; void LOW(void){int a=g_a;int b=g_b;int c=g_c;(void)(a==b);(void)(b==c);} void HIGH(void){g_a=1;g_b=1;g_c=1;}\n", expected={"g_a": [4], "g_b": [4], "g_c": [4]}, metrics={"group_count": 2})
    add(212, "空白パス・別Makefile", "設定の相対起点とMakefileを使用", "int g; void LOW(void){g=1;} void HIGH(void){g=2;}\n", expected={"g": [1]}, dirname="TC212 project space", makefile="build/Project.mk")
    files = {f"src/minimal_{n}.c": originals[n]["src/tasks.c"] for n in simple}
    declarations = []
    for n in simple:
        for priority in ("low", "high"):
            typ = "int" if (n, priority) in {(102, "low"), (103, "high"), (104, "low"), (105, "high")} else "void"
            declarations.append(f"{typ} TC{n}_{priority}(void);")
    files["src/tasks.c"] = "\n".join(declarations) + "\nvoid LOW(void){" + "".join(f"TC{n}_low();" for n in simple) + "}\nvoid HIGH(void){" + "".join(f"TC{n}_high();" for n in simple) + "}\n"
    expected = {f"TC{n}_" + ram: rules for n, (_, _, _, ex) in simple.items() for ram, rules in ex.items()}
    add(213, "最小6件の複数TU統合", "個別と同じ9 RAM・判定を維持", files=files, expected=expected, metrics={"translation_units": 8, "ram_count": 9})
    add(214, "ローカル変数の同名隠蔽", "同名ローカルをグローバルWと数えない", "int g; int LOW(void){int g=1;return g;} void HIGH(void){g=2;}\n")
    add(215, "同値を書いてもアクセスあり", "値の一致で条件2の違反を隠さない", "int g; int LOW(void){int a=g;int b=g;return a==b;} void HIGH(void){g=0;}\n", expected={"g": [2]})
    add(216, "Read-Modify-Write", "+=のRとWを分けて抽出", "int g; void LOW(void){g+=1;} void HIGH(void){g=2;}\n", expected={"g": [1]})
    add(217, "未アクセスRAM", "使用されないRAMも一覧に残す", "int g,g_unused; void LOW(void){g=1;} void HIGH(void){g=2;}\n", expected={"g": [1]}, metrics={"ram_count": 2})
    add(218, "定数条件の到達不能コード", "if(0)のWを実行回数へ加算しない", "int g; void LOW(void){if(0){g=1;}} void HIGH(void){g=2;}\n")
    add(219, "整数型・typedef・メンバ配列", "unsigned short/unsigned char/long long/volatileとネスト配列", 
        "typedef unsigned short U16;struct Child {U16 values[3];unsigned char flag;};struct Root {struct Child children[2];long long count;volatile int stamp;};struct Root g;\nvoid LOW(void){g.children[1].values[2]=7;g.count=3;g.stamp=1;g.children[0].flag=1;}void HIGH(void){g.children[1].values[2]=9;g.count=4;g.stamp=2;g.children[0].flag=2;}\n",
        expected={"g.children[].values[]": [1], "g.children[].flag": [1], "g.count": [1], "g.stamp": [1]}, metrics={"ram_count": 4, "storage_elements": 10})
    add(220, "4変数同一グループ", "Excel条件4〜6で4列をそれぞれ結合", 
        "int g_a,g_b,g_c,g_d;void LOW(void){g_a=1;g_b=1;g_c=1;g_d=1;}void HIGH(void){g_a=2;g_b=2;g_c=2;g_d=2;}\n",
        expected={"g_a": [1,6], "g_b": [1,6], "g_c": [1,6], "g_d": [1,6]}, metrics={"group_count": 1})
    decision_path = DEST / "TC219/ai_group_decisions.json"
    decision_path.write_text(json.dumps({"author": "AI", "groups": [], "reason": "整数型の独立アクセスを試すコード。stampとflagは異なる目的の値で、同じ定数の連続書込みだけでは同時更新の根拠が弱い。比較・一括参照もないため候補を取り下げる。実プロジェクトでは設計者が確認する。"}, ensure_ascii=False, indent=2), encoding="utf-8")
    configuration = DEST / "TC219/project.json"
    data = json.loads(configuration.read_text(encoding="utf-8"))
    data["ai_group_decisions"] = "ai_group_decisions.json"
    configuration.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    protected = {
        301: "int g; void LOW(void){L_ENTER g=1; L_EXIT} void HIGH(void){H_ENTER g=2; H_EXIT}",
        302: "int g; int LOW(void){L_ENTER int a=g;int b=g; L_EXIT return a==b;} void HIGH(void){H_ENTER g=1; H_EXIT}",
        303: "int g; void LOW(void){L_ENTER g=1;g=2; L_EXIT} int HIGH(void){H_ENTER int a=g; H_EXIT return a;}",
        304: "int g_a,g_b; int LOW(void){L_ENTER int a=g_a;int b=g_b; L_EXIT return a==b;} void HIGH(void){H_ENTER g_a=1;g_b=1; H_EXIT}",
        305: "int g_a,g_b; void LOW(void){L_ENTER g_a=1;g_b=1; L_EXIT} int HIGH(void){H_ENTER int a=g_a;int b=g_b; H_EXIT return a==b;}",
        306: "int g_a,g_b; void LOW(void){L_ENTER g_a=1;g_b=1; L_EXIT} void HIGH(void){H_ENTER g_a=2;g_b=2; H_EXIT}",
    }
    for n, code in protected.items():
        raw = simple[101 + n - 301][3]
        add(n, f"条件{n-300}をSchMで保護", "アクセスパターンは残るが最終判定はTRUE", protect(code), areas=[area()], raw=raw)
    add(307, "下位のみ保護キーワード", "指定区間は上位のAPI利用によらず保護", protect(protected[302], high=False), areas=[area()])
    add(308, "異なる保護キーワード", "各指定区間はArea名が違っても保護", protect(protected[304], high_area="B"), areas=[area(), area("B")])
    partial = "int g_a,g_b; int LOW(void){int a=g_a;SchM_Enter_Test_A();int b=g_b;SchM_Exit_Test_A();return a==b;} void HIGH(void){H_ENTER g_a=1;g_b=1;H_EXIT}"
    add(309, "保護区間の開始が遅い", "最初のRがArea外なら読出し全体を保護できない", protect(partial), areas=[area()], expected={"g_a": [4], "g_b": [4]})
    split = "int g_a,g_b; int LOW(void){L_ENTER int a=g_a;L_EXIT L_ENTER int b=g_b;L_EXIT return a==b;} void HIGH(void){H_ENTER g_a=1;g_b=1;H_EXIT}"
    add(310, "同じAreaの入り直し", "同じArea名でも別インスタンス間の隙間に割込み可能", protect(split), areas=[area()], expected={"g_a": [4], "g_b": [4]})
    nested = protected[302].replace("L_ENTER", "L_ENTER SchM_Enter_Test_B();").replace("L_EXIT", "SchM_Exit_Test_B(); L_EXIT")
    add(311, "異なるAreaのネスト", "A→B→Exit B→Exit Aの正常な入れ子", protect(nested), areas=[area(), area("B")])
    helper = "int g; static int read_ram(void){return g;} int LOW(void){L_ENTER int a=read_ram();int b=read_ram();L_EXIT return a==b;} void HIGH(void){H_ENTER g=1;H_EXIT}"
    add(312, "呼出し先までArea継承", "同じ補助関数を2回呼ぶ場合も全区間を保護", protect(helper), areas=[area()])
    add(313, "Exitの順序不正", "A→B→Exit Aを安全扱いしない", '#include "SchM_Test.h"\nint g;void LOW(void){SchM_Enter_Test_A();SchM_Enter_Test_B();g=1;SchM_Exit_Test_A();SchM_Exit_Test_B();} void HIGH(void){g=2;}\n', areas=[area(), area("B")], blocked="SchM_Exit")
    add(314, "Exit欠落", "タスク終了時にAreaが残ったら停止", '#include "SchM_Test.h"\nint g;void LOW(void){SchM_Enter_Test_A();g=1;} void HIGH(void){g=2;}\n', areas=[area()], blocked="without matching Exit")
    add(315, "同一Areaの再帰Enter", "同一Areaの二重Enterは契約外", '#include "SchM_Test.h"\nint g;void LOW(void){SchM_Enter_Test_A();SchM_Enter_Test_A();g=1;SchM_Exit_Test_A();SchM_Exit_Test_A();} void HIGH(void){g=2;}\n', areas=[area()], blocked="recursively")
    add(316, "上下書込み・下位だけ保護", "条件1にも保護を適用", protect(protected[301], high=False), areas=[area()])
    add(317, "上位だけ保護", "下位の2回読出し間への割込みは残る", protect(protected[302], low=False), areas=[area()], expected={"g": [2]})
    macro = protect(protected[306]).replace("SchM_Enter_Test_A();", "ENTER();").replace("SchM_Exit_Test_A();", "EXIT();")
    add(318, "SchMのマクロラッパー", "do-while(0)経由のEnter/Exitを認識", '#define ENTER() do { SchM_Enter_Test_A(); } while(0)\n#define EXIT() do { SchM_Exit_Test_A(); } while(0)\n' + macro, areas=[area()])

    add(401,"低・中・高の全ペアW","3組合せすべてで条件1", "int g;void LOW(void){g=1;}void MID(void){g=2;}void HIGH(void){g=3;}",expected={"g":[1]},metrics={"priority_levels":3})
    add(402,"低R2・中W","低−中のみ条件2", "int g,g_other;int LOW(void){int a=g;int b=g;return a==b;}void MID(void){g=1;}void HIGH(void){g_other=2;}",expected={"g":[2]})
    add(403,"中R2・高W","中−高のみ条件2", "int g,g_other;void LOW(void){g_other=1;}int MID(void){int a=g;int b=g;return a==b;}void HIGH(void){g=2;}",expected={"g":[2]})
    add(404,"低R2・高W","低−高のみ条件2", "int g,g_other;int LOW(void){int a=g;int b=g;return a==b;}void MID(void){g_other=1;}void HIGH(void){g=2;}",expected={"g":[2]})
    add(405,"中への高の入れ子割込み","低→中→高→中→低の実行順を列挙", "int g,g_other;int LOW(void){int a=g;int b=g;return a==b;}void MID(void){g_other=1;g_other=2;}void HIGH(void){g=3;}",expected={"g":[2]})
    triple = '#include "SchM_Test.h"\nint g_a,g_b;'+''.join(f"void {name}(void){{SchM_Enter_Test_A();g_a={value};g_b={value};SchM_Exit_Test_A();}}" for name,value in [("LOW",1),("MID",2),("HIGH",3)])
    add(406,"3段階すべてグループ保護","条件1・6を全ペアで保護",triple,areas=[area()],metrics={"priority_levels":3,"group_count":1})
    add(407,"低だけ保護・中高は競合","低の保護を中−高に誤適用しない",'#include "SchM_Test.h"\nint g;int LOW(void){SchM_Enter_Test_A();int a=g;int b=g;SchM_Exit_Test_A();return a==b;}void MID(void){g=1;}void HIGH(void){g=2;}',areas=[area()],expected={"g":[1]})
    add(408,"低と中の区間を保護","高にEnterがなくても全ペア保護",'#include "SchM_Test.h"\nint g;void LOW(void){SchM_Enter_Test_A();g=1;SchM_Exit_Test_A();}void MID(void){SchM_Enter_Test_A();g=2;SchM_Exit_Test_A();}void HIGH(void){g=3;}',areas=[area()])
    add(409,"グループ条件をペア別集約","低−中の条件4と中−高の条件5を集約",'int g_a,g_b;int LOW(void){int a=g_a;int b=g_b;return a==b;}void MID(void){g_a=1;g_b=1;}int HIGH(void){int a=g_a;int b=g_b;return a==b;}',expected={"g_a":[4,5],"g_b":[4,5]},metrics={"group_count":1})
    add(410,"3段階の列挙上限","配置数上限を超えたら停止",'int g;void LOW(void){g=1;}void MID(void){g=2;}void HIGH(void){g=3;}',limits={"schedules":1},blocked="schedules limit")
    add(411,"アクセスしない上位タスク","空タスクを含む3段階でも他ペアを判定",'int g;void LOW(void){g=1;}void MID(void){g=2;}void HIGH(void){}',expected={"g":[1]})
    for number,pairs in [(402,{"low__middle":{"g":[2]}}),(403,{"middle__high":{"g":[2]}}),(404,{"low__high":{"g":[2]}}),
                         (407,{"middle__high":{"g":[1]}}),(409,{"low__middle":{"g_a":[4],"g_b":[4]},"middle__high":{"g_a":[5],"g_b":[5]}})]:
        spec=next(s for s in CASES if s["id"]==f"TC{number}")
        spec["expected"]["pair_violations"]={pair:{f"TC{number}_"+ram:rules for ram,rules in pairs.get(pair,{}).items()} for pair in ("low__middle","low__high","middle__high")}
        (DEST/f"TC{number}"/"test_expectation.json").write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding="utf-8")

    def chain(depth):
        functions = ["int g;", f"static void f{depth}(void){{g=1;}}"]
        functions += [f"static void f{i}(void){{f{i+1}();}}" for i in range(depth-1, 0, -1)]
        return "\n".join(functions) + "\nvoid LOW(void){f1();} void HIGH(void){g=2;}\n"
    add(901, "関数ネスト32回", "起点から32本の呼出辺を追跡", chain(32), expected={"g": [1]}, metrics={"max_call_depth": 32})
    add(902, "関数ネスト64回", "設定上限64で正常解析", chain(64), expected={"g": [1]}, metrics={"max_call_depth": 64})
    add(903, "関数ネスト65回", "設定上限を1超えたら明示停止", chain(65), blocked="call_depth")
    add(904, "配列長4096", "設定上限4096の最終要素", "int g[4096]; void LOW(void){g[4095]=1;} void HIGH(void){g[4095]=2;}\n", expected={"g[]": [1]}, metrics={"storage_elements": 4096})
    add(905, "配列長4097", "設定上限を1超えたら停止", "int g[4097]; void LOW(void){g[4096]=1;} void HIGH(void){g[0]=2;}\n", blocked="limit")
    add(906, "多次元展開量の上限", "配列各次元が小さくても総記憶場所数を制限", "int g[32][32][32]; void LOW(void){g[0][0][0]=1;} void HIGH(void){g[0][0][0]=2;}\n", limits={"storage_locations": 256}, blocked="limit")
    for n, count in ((907, 64), (908, 65)):
        code = "int g; void LOW(void){" + "(void)g;" * count + "} void HIGH(void){g=1;}\n"
        add(n, f"下位アクセス{count}回", "イベント数64の境界試験", code, limits={"events_per_task": 64}, expected={"g": [2]} if count == 64 else None,
            blocked="events_per_task" if count == 65 else None, metrics={"low_accesses": 64} if count == 64 else None)
    add(909, "共有値による未知添字", "初期値0を根拠に添字を決め打ちしない", "int g[2],g_index; void LOW(void){g[g_index]=1;} void HIGH(void){g[0]=2;}\n", blocked="array index")
    add(910, "境界外添字", "コンパイラ診断が出たら解析結果を発行しない", "int g[2]; void LOW(void){g[2]=1;} void HIGH(void){g[0]=2;}\n", blocked="command failed")
    add(911, "未解決extern", "リンク失敗を安全扱いしない", "extern int g; void LOW(void){g=1;} void HIGH(void){g=2;}\n", blocked="command failed")
    add(912, "未登録SchM", "空の関数名だけで保護契約を仮定しない", '#include "SchM_Test.h"\nint g; void LOW(void){SchM_Enter_Test_A();g=1;SchM_Exit_Test_A();} void HIGH(void){g=2;}\n', blocked="no declared contract")
    add(913, "共有状態による分岐", "経路未解析をTRUEにしない", "int g,g_flag;void LOW(void){if(g_flag){g=1;}} void HIGH(void){g=2;}\n", blocked="path-sensitive")
    add(914, "通常のforループ", "未対応構文を明示的に停止", "int g;void LOW(void){for(int i=0;i<3;i++){g=i;}} void HIGH(void){g=2;}\n", blocked="ForStmt")
    add(915, "EnterなしExit", "不正なArea終了を検出", '#include "SchM_Test.h"\nint g;void LOW(void){g=1;SchM_Exit_Test_A();} void HIGH(void){g=2;}\n', areas=[area()], blocked="SchM_Exit")
    macros = "#define M0 g\n" + "".join(f"#define M{i} M{i-1}\n" for i in range(1, 65))
    add(916, "マクロ連鎖64段", "ソース位置を保持して展開後のgへ到達", macros + "int g;void LOW(void){M64=1;} void HIGH(void){g=2;}\n", expected={"g": [1]})
    struct = "struct S16 {int value[2];};\n" + "".join(f"struct S{i} {{struct S{i+1} child;}};\n" for i in range(15, 0, -1))
    member = "g." + "child." * 15 + "value[1]"
    add(917, "構造体16段", "16段の入れ子の末端配列へ到達", struct + f"struct S1 g;void LOW(void){{{member}=1;}} void HIGH(void){{{member}=2;}}\n", expected={"g." + "child." * 15 + "value[]": [1]})
    composite_header = "struct C {int a,b;}; struct B {struct C c[4];}; struct A {struct B b[3];}; extern struct A g[2];\n"
    deep = "g[1].b[2].c[3]"
    leaf = f"static void f32(void){{SchM_Enter_Test_A();int a={deep}.a;int b={deep}.b;(void)(a==b);SchM_Exit_Test_A();}}\n"
    chain_code = leaf + "".join(f"static void f{i}(void){{f{i+1}();}}\n" for i in range(31, 0, -1)) + "void LOW(void){f1();}\n"
    add(918, "複合限界プロジェクト", "32段呼出し＋A/B/C配列＋define＋SchM＋5 TU", files={"include/deep.h": composite_header,
         "src/ram.c": '#include "deep.h"\nstruct A g[2];\n',
         "src/low.c": '#include "deep.h"\n#include "SchM_Test.h"\n' + chain_code,
         "src/high.c": '#include "deep.h"\n#include "SchM_Test.h"\n#define SET(x) do{(x).a=1;(x).b=1;}while(0)\n' + f"void HIGH(void){{SchM_Enter_Test_A();SET({deep});SchM_Exit_Test_A();}}\n"},
         areas=[area()], metrics={"max_call_depth": 32, "translation_units": 5, "storage_elements": 48, "group_count": 1})
    manifest = {"schema_version": 1, "classification": {"100": "最小仕様と正常対照", "200": "実プロジェクトの構成・複合", "300": "SchMの有効性・誤用", "400":"低・中・高の3段階", "900": "境界・上限・解析不能"}, "cases": CASES}
    (ROOT / "tests/project_suite.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"generated {len(CASES)} independent projects")


if __name__ == "__main__":
    main()
